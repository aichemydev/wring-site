var rrwebRecord = (function () {
  "use strict";
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */ var e,
    t = function () {
      return (t =
        Object.assign ||
        function (e) {
          for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in (t = arguments[n])) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
          return e;
        }).apply(this, arguments);
    };
  function n(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
      n = t && e[t],
      r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length)
      return {
        next: function () {
          return e && r >= e.length && (e = void 0), { value: e && e[r++], done: !e };
        },
      };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function r(e, t) {
    var n = "function" == typeof Symbol && e[Symbol.iterator];
    if (!n) return e;
    var r,
      o,
      a = n.call(e),
      i = [];
    try {
      for (; (void 0 === t || t-- > 0) && !(r = a.next()).done; ) i.push(r.value);
    } catch (e) {
      o = { error: e };
    } finally {
      try {
        r && !r.done && (n = a.return) && n.call(a);
      } finally {
        if (o) throw o.error;
      }
    }
    return i;
  }
  function o(e, t, n) {
    if (n || 2 === arguments.length) for (var r, o = 0, a = t.length; o < a; o++) (!r && o in t) || (r || (r = Array.prototype.slice.call(t, 0, o)), (r[o] = t[o]));
    return e.concat(r || Array.prototype.slice.call(t));
  }
  function a(e) {
    var t,
      n = null === (t = e) || void 0 === t ? void 0 : t.host;
    return Boolean(n && n.shadowRoot && n.shadowRoot === e);
  }
  function i(e) {
    var t = e.maskInputOptions,
      n = e.tagName,
      r = e.type,
      o = e.value,
      a = e.maskInputFn,
      i = o || "";
    return (t[n.toLowerCase()] || t[r]) && (i = a ? a(i) : "*".repeat(i.length)), i;
  }
  !(function (e) {
    (e[(e.Document = 0)] = "Document"), (e[(e.DocumentType = 1)] = "DocumentType"), (e[(e.Element = 2)] = "Element"), (e[(e.Text = 3)] = "Text"), (e[(e.CDATA = 4)] = "CDATA"), (e[(e.Comment = 5)] = "Comment");
  })(e || (e = {}));
  var s = "__rrweb_original__";
  var u,
    l,
    c = 1,
    d = new RegExp("[^a-z0-9-_:]");
  function p(e) {
    try {
      var t = e.rules || e.cssRules;
      return t ? Array.from(t).map(f).join("") : null;
    } catch (e) {
      return null;
    }
  }
  function f(e) {
    var t = e.cssText;
    if (
      (function (e) {
        return "styleSheet" in e;
      })(e)
    )
      try {
        t = p(e.styleSheet) || t;
      } catch (e) {}
    return t;
  }
  var m = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
    h = /^(?!www\.|(?:http|ftp)s?:\/\/|[A-Za-z]:\\|\/\/|#).*/,
    v = /^(data:)([^,]*),(.*)/i;
  function y(e, t) {
    return (e || "").replace(m, function (e, n, r, o, a, i) {
      var s,
        u = r || a || i,
        l = n || o || "";
      if (!u) return e;
      if (!h.test(u)) return "url(" + l + u + l + ")";
      if (v.test(u)) return "url(" + l + u + l + ")";
      if ("/" === u[0]) return "url(" + l + (((s = t).indexOf("//") > -1 ? s.split("/").slice(0, 3).join("/") : s.split("/")[0]).split("?")[0] + u) + l + ")";
      var c = t.split("/"),
        d = u.split("/");
      c.pop();
      for (var p = 0, f = d; p < f.length; p++) {
        var m = f[p];
        "." !== m && (".." === m ? c.pop() : c.push(m));
      }
      return "url(" + l + c.join("/") + l + ")";
    });
  }
  var g,
    b,
    S,
    C,
    k,
    w,
    I = /^[^ \t\n\r\u000c]+/,
    x = /^[, \t\n\r\u000c]+/;
  function M(e, t) {
    if (!t || "" === t.trim()) return t;
    var n = e.createElement("a");
    return (n.href = t), n.href;
  }
  function T() {
    var e = document.createElement("a");
    return (e.href = ""), e.href;
  }
  function E(e, t, n, r) {
    return "src" === n || ("href" === n && r) || ("xlink:href" === n && r && "#" !== r[0])
      ? M(e, r)
      : "background" !== n || !r || ("table" !== t && "td" !== t && "th" !== t)
        ? "srcset" === n && r
          ? (function (e, t) {
            if ("" === t.trim()) return t;
            var n = 0;
            function r(e) {
              var r,
                o = e.exec(t.substring(n));
              return o ? ((r = o[0]), (n += r.length), r) : "";
            }
            for (var o = []; r(x), !(n >= t.length); ) {
              var a = r(I);
              if ("," === a.slice(-1)) (a = M(e, a.substring(0, a.length - 1))), o.push(a);
              else {
                var i = "";
                a = M(e, a);
                for (var s = !1; ; ) {
                  var u = t.charAt(n);
                  if ("" === u) {
                    o.push((a + i).trim());
                    break;
                  }
                  if (s) ")" === u && (s = !1);
                  else {
                    if ("," === u) {
                      (n += 1), o.push((a + i).trim());
                      break;
                    }
                    "(" === u && (s = !0);
                  }
                  (i += u), (n += 1);
                }
              }
            }
            return o.join(", ");
          })(e, r)
          : "style" === n && r
            ? y(r, T())
            : "object" === t && "data" === n && r
              ? M(e, r)
              : r
        : M(e, r);
  }
  function O(e, t, n) {
    if (!e) return !1;
    if (e.nodeType === e.ELEMENT_NODE) {
      if ("string" == typeof t) {
        if (e.classList.contains(t)) return !0;
      } else
        for (var r = 0; r < e.classList.length; r++) {
          var o = e.classList[r];
          if (t.test(o)) return !0;
        }
      return !(!n || !e.matches(n)) || O(e.parentNode, t, n);
    }
    return e.nodeType, e.TEXT_NODE, O(e.parentNode, t, n);
  }
  function R(t, n) {
    var r,
      o,
      a,
      c,
      f = n.doc,
      m = n.blockClass,
      h = n.blockSelector,
      v = n.maskTextClass,
      g = n.maskTextSelector,
      b = n.inlineStylesheet,
      S = n.maskInputOptions,
      C = void 0 === S ? {} : S,
      k = n.maskTextFn,
      w = n.maskInputFn,
      I = n.dataURLOptions,
      x = void 0 === I ? {} : I,
      M = n.inlineImages,
      R = n.recordCanvas,
      N = n.keepIframeSrcFn;
    if (f.__sn) {
      var _ = f.__sn.id;
      o = 1 === _ ? void 0 : _;
    }
    switch (t.nodeType) {
      case t.DOCUMENT_NODE:
        return "CSS1Compat" !== t.compatMode ? { type: e.Document, childNodes: [], compatMode: t.compatMode, rootId: o } : { type: e.Document, childNodes: [], rootId: o };
      case t.DOCUMENT_TYPE_NODE:
        return { type: e.DocumentType, name: t.name, publicId: t.publicId, systemId: t.systemId, rootId: o };
      case t.ELEMENT_NODE:
        for (
          var L = (function (e, t, n) {
              if ("string" == typeof t) {
                if (e.classList.contains(t)) return !0;
              } else
                for (var r = 0; r < e.classList.length; r++) {
                  var o = e.classList[r];
                  if (t.test(o)) return !0;
                }
              return !!n && e.matches(n);
            })(t, m, h),
            D = (function (e) {
              if (e instanceof HTMLFormElement) return "form";
              var t = e.tagName.toLowerCase().trim();
              return d.test(t) ? "div" : t;
            })(t),
            F = {},
            A = 0,
            P = Array.from(t.attributes);
          A < P.length;
          A++
        ) {
          var z = P[A],
            W = z.name,
            U = z.value;
          F[W] = E(f, D, W, U);
        }
        if ("link" === D && b) {
          var j = Array.from(f.styleSheets).find(function (e) {
              return e.href === t.href;
            }),
            G = null;
          j && (G = p(j)), G && (delete F.rel, delete F.href, (F._cssText = y(G, j.href)));
        }
        if ("style" === D && t.sheet && !(t.innerText || t.textContent || "").trim().length) (G = p(t.sheet)) && (F._cssText = y(G, T()));
        if ("input" === D || "textarea" === D || "select" === D) {
          U = t.value;
          "radio" !== F.type && "checkbox" !== F.type && "submit" !== F.type && "button" !== F.type && U
            ? (F.value = i({ type: F.type, tagName: D, value: U, maskInputOptions: C, maskInputFn: w }))
            : t.checked && (F.checked = t.checked);
        }
        if (("option" === D && (t.selected && !C.select ? (F.selected = !0) : delete F.selected), "canvas" === D && R))
          if ("2d" === t.__context)
            (function (e) {
              var t = e.getContext("2d");
              if (!t) return !0;
              for (var n = 0; n < e.width; n += 50)
                for (var r = 0; r < e.height; r += 50) {
                  var o = t.getImageData,
                    a = s in o ? o.__rrweb_original__ : o;
                  if (
                    new Uint32Array(a.call(t, n, r, Math.min(50, e.width - n), Math.min(50, e.height - r)).data.buffer).some(function (e) {
                      return 0 !== e;
                    })
                  )
                    return !1;
                }
              return !0;
            })(t) || (F.rr_dataURL = t.toDataURL(x.type, x.quality));
          else if (!("__context" in t)) {
            var V = t.toDataURL(x.type, x.quality),
              H = document.createElement("canvas");
            (H.width = t.width), (H.height = t.height), V !== H.toDataURL(x.type, x.quality) && (F.rr_dataURL = V);
          }
        if ("img" === D && M) {
          u || ((u = f.createElement("canvas")), (l = u.getContext("2d")));
          var q = t,
            B = q.crossOrigin;
          q.crossOrigin = "anonymous";
          var X = function () {
            try {
              (u.width = q.naturalWidth), (u.height = q.naturalHeight), l.drawImage(q, 0, 0), (F.rr_dataURL = u.toDataURL(x.type, x.quality));
            } catch (e) {
              console.warn("Cannot inline img src=" + q.currentSrc + "! Error: " + e);
            }
            B ? (F.crossOrigin = B) : delete F.crossOrigin;
          };
          q.complete && 0 !== q.naturalWidth ? X() : (q.onload = X);
        }
        if (
          (("audio" !== D && "video" !== D) || ((F.rr_mediaState = t.paused ? "paused" : "played"), (F.rr_mediaCurrentTime = t.currentTime)),
          t.scrollLeft && (F.rr_scrollLeft = t.scrollLeft),
          t.scrollTop && (F.rr_scrollTop = t.scrollTop),
            L)
        ) {
          var Y = t.getBoundingClientRect(),
            K = Y.width,
            J = Y.height;
          F = { class: F.class, rr_width: K + "px", rr_height: J + "px" };
        }
        return (
          "iframe" !== D || N(F.src) || (t.contentDocument || (F.rr_src = F.src), delete F.src),
            { type: e.Element, tagName: D, attributes: F, childNodes: [], isSVG: ((c = t), Boolean("svg" === c.tagName || c.ownerSVGElement) || void 0), needBlock: L, rootId: o }
        );
      case t.TEXT_NODE:
        var Z = t.parentNode && t.parentNode.tagName,
          $ = t.textContent,
          Q = "STYLE" === Z || void 0,
          ee = "SCRIPT" === Z || void 0;
        if (Q && $) {
          try {
            t.nextSibling ||
            t.previousSibling ||
            ((null === (r = t.parentNode.sheet) || void 0 === r ? void 0 : r.cssRules) &&
              ($ = (a = t.parentNode.sheet).cssRules
                ? Array.from(a.cssRules)
                  .map(function (e) {
                    return e.cssText || "";
                  })
                  .join("")
                : ""));
          } catch (e) {
            console.warn("Cannot get CSS styles from text's parentNode. Error: " + e, t);
          }
          $ = y($, T());
        }
        return ee && ($ = "SCRIPT_PLACEHOLDER"), !Q && !ee && O(t, v, g) && $ && ($ = k ? k($) : $.replace(/[\S]/g, "*")), { type: e.Text, textContent: $ || "", isStyle: Q, rootId: o };
      case t.CDATA_SECTION_NODE:
        return { type: e.CDATA, textContent: "", rootId: o };
      case t.COMMENT_NODE:
        return { type: e.Comment, textContent: t.textContent || "", rootId: o };
      default:
        return !1;
    }
  }
  function N(e) {
    return void 0 === e ? "" : e.toLowerCase();
  }
  function _(t, n) {
    var r,
      o = n.doc,
      i = n.map,
      s = n.blockClass,
      u = n.blockSelector,
      l = n.maskTextClass,
      d = n.maskTextSelector,
      p = n.skipChild,
      f = void 0 !== p && p,
      m = n.inlineStylesheet,
      h = void 0 === m || m,
      v = n.maskInputOptions,
      y = void 0 === v ? {} : v,
      g = n.maskTextFn,
      b = n.maskInputFn,
      S = n.slimDOMOptions,
      C = n.dataURLOptions,
      k = void 0 === C ? {} : C,
      w = n.inlineImages,
      I = void 0 !== w && w,
      x = n.recordCanvas,
      M = void 0 !== x && x,
      T = n.onSerialize,
      E = n.onIframeLoad,
      O = n.iframeLoadTimeout,
      L = void 0 === O ? 5e3 : O,
      D = n.keepIframeSrcFn,
      F =
        void 0 === D
          ? function () {
            return !1;
          }
          : D,
      A = n.preserveWhiteSpace,
      P = void 0 === A || A,
      z = R(t, {
        doc: o,
        blockClass: s,
        blockSelector: u,
        maskTextClass: l,
        maskTextSelector: d,
        inlineStylesheet: h,
        maskInputOptions: y,
        maskTextFn: g,
        maskInputFn: b,
        dataURLOptions: k,
        inlineImages: I,
        recordCanvas: M,
        keepIframeSrcFn: F,
      });
    if (!z) return console.warn(t, "not serialized"), null;
    r =
      "__sn" in t
        ? t.__sn.id
        : !(function (t, n) {
          if (n.comment && t.type === e.Comment) return !0;
          if (t.type === e.Element) {
            if (
              n.script &&
              ("script" === t.tagName ||
                ("link" === t.tagName && "preload" === t.attributes.rel && "script" === t.attributes.as) ||
                ("link" === t.tagName && "prefetch" === t.attributes.rel && "string" == typeof t.attributes.href && t.attributes.href.endsWith(".js")))
            )
              return !0;
            if (
              n.headFavicon &&
              (("link" === t.tagName && "shortcut icon" === t.attributes.rel) ||
                ("meta" === t.tagName &&
                  (N(t.attributes.name).match(/^msapplication-tile(image|color)$/) ||
                    "application-name" === N(t.attributes.name) ||
                    "icon" === N(t.attributes.rel) ||
                    "apple-touch-icon" === N(t.attributes.rel) ||
                    "shortcut icon" === N(t.attributes.rel))))
            )
              return !0;
            if ("meta" === t.tagName) {
              if (n.headMetaDescKeywords && N(t.attributes.name).match(/^description|keywords$/)) return !0;
              if (n.headMetaSocial && (N(t.attributes.property).match(/^(og|twitter|fb):/) || N(t.attributes.name).match(/^(og|twitter):/) || "pinterest" === N(t.attributes.name))) return !0;
              if (n.headMetaRobots && ("robots" === N(t.attributes.name) || "googlebot" === N(t.attributes.name) || "bingbot" === N(t.attributes.name))) return !0;
              if (n.headMetaHttpEquiv && void 0 !== t.attributes["http-equiv"]) return !0;
              if (
                n.headMetaAuthorship &&
                ("author" === N(t.attributes.name) ||
                  "generator" === N(t.attributes.name) ||
                  "framework" === N(t.attributes.name) ||
                  "publisher" === N(t.attributes.name) ||
                  "progid" === N(t.attributes.name) ||
                  N(t.attributes.property).match(/^article:/) ||
                  N(t.attributes.property).match(/^product:/))
              )
                return !0;
              if (
                n.headMetaVerification &&
                ("google-site-verification" === N(t.attributes.name) ||
                  "yandex-verification" === N(t.attributes.name) ||
                  "csrf-token" === N(t.attributes.name) ||
                  "p:domain_verify" === N(t.attributes.name) ||
                  "verify-v1" === N(t.attributes.name) ||
                  "verification" === N(t.attributes.name) ||
                  "shopify-checkout-api-token" === N(t.attributes.name))
              )
                return !0;
            }
          }
          return !1;
        })(z, S) &&
        (P || z.type !== e.Text || z.isStyle || z.textContent.replace(/^\s+|\s+$/gm, "").length)
        ? c++
        : -2;
    var W = Object.assign(z, { id: r });
    if (((t.__sn = W), -2 === r)) return null;
    (i[r] = t), T && T(t);
    var U = !f;
    if ((W.type === e.Element && ((U = U && !W.needBlock), delete W.needBlock, t.shadowRoot && (W.isShadowHost = !0)), (W.type === e.Document || W.type === e.Element) && U)) {
      S.headWhitespace && z.type === e.Element && "head" === z.tagName && (P = !1);
      for (
        var j = {
            doc: o,
            map: i,
            blockClass: s,
            blockSelector: u,
            maskTextClass: l,
            maskTextSelector: d,
            skipChild: f,
            inlineStylesheet: h,
            maskInputOptions: y,
            maskTextFn: g,
            maskInputFn: b,
            slimDOMOptions: S,
            dataURLOptions: k,
            inlineImages: I,
            recordCanvas: M,
            preserveWhiteSpace: P,
            onSerialize: T,
            onIframeLoad: E,
            iframeLoadTimeout: L,
            keepIframeSrcFn: F,
          },
          G = 0,
          V = Array.from(t.childNodes);
        G < V.length;
        G++
      ) {
        (B = _(V[G], j)) && W.childNodes.push(B);
      }
      if (
        (function (e) {
          return e.nodeType === e.ELEMENT_NODE;
        })(t) &&
        t.shadowRoot
      )
        for (var H = 0, q = Array.from(t.shadowRoot.childNodes); H < q.length; H++) {
          var B;
          (B = _(q[H], j)) && ((B.isShadow = !0), W.childNodes.push(B));
        }
    }
    return (
      t.parentNode && a(t.parentNode) && (W.isShadow = !0),
      W.type === e.Element &&
      "iframe" === W.tagName &&
      (function (e, t, n) {
        var r = e.contentWindow;
        if (r) {
          var o,
            a = !1;
          try {
            o = r.document.readyState;
          } catch (e) {
            return;
          }
          if ("complete" === o) {
            var i = "about:blank";
            r.location.href === i && e.src !== i && "" !== e.src ? e.addEventListener("load", t) : setTimeout(t, 0);
          } else {
            var s = setTimeout(function () {
              a || (t(), (a = !0));
            }, n);
            e.addEventListener("load", function () {
              clearTimeout(s), (a = !0), t();
            });
          }
        }
      })(
        t,
        function () {
          var e = t.contentDocument;
          if (e && E) {
            var n = _(e, {
              doc: e,
              map: i,
              blockClass: s,
              blockSelector: u,
              maskTextClass: l,
              maskTextSelector: d,
              skipChild: !1,
              inlineStylesheet: h,
              maskInputOptions: y,
              maskTextFn: g,
              maskInputFn: b,
              slimDOMOptions: S,
              dataURLOptions: k,
              inlineImages: I,
              recordCanvas: M,
              preserveWhiteSpace: P,
              onSerialize: T,
              onIframeLoad: E,
              iframeLoadTimeout: L,
              keepIframeSrcFn: F,
            });
            n && E(t, n);
          }
        },
        L
      ),
        W
    );
  }
  function L(e, t, n) {
    void 0 === n && (n = document);
    var r = { capture: !0, passive: !0 };
    return (
      n.addEventListener(e, t, r),
        function () {
          return n.removeEventListener(e, t, r);
        }
    );
  }
  !(function (e) {
    (e[(e.DomContentLoaded = 0)] = "DomContentLoaded"),
      (e[(e.Load = 1)] = "Load"),
      (e[(e.FullSnapshot = 2)] = "FullSnapshot"),
      (e[(e.IncrementalSnapshot = 3)] = "IncrementalSnapshot"),
      (e[(e.Meta = 4)] = "Meta"),
      (e[(e.Custom = 5)] = "Custom"),
      (e[(e.Plugin = 6)] = "Plugin");
  })(g || (g = {})),
    (function (e) {
      (e[(e.Mutation = 0)] = "Mutation"),
        (e[(e.MouseMove = 1)] = "MouseMove"),
        (e[(e.MouseInteraction = 2)] = "MouseInteraction"),
        (e[(e.Scroll = 3)] = "Scroll"),
        (e[(e.ViewportResize = 4)] = "ViewportResize"),
        (e[(e.Input = 5)] = "Input"),
        (e[(e.TouchMove = 6)] = "TouchMove"),
        (e[(e.MediaInteraction = 7)] = "MediaInteraction"),
        (e[(e.StyleSheetRule = 8)] = "StyleSheetRule"),
        (e[(e.CanvasMutation = 9)] = "CanvasMutation"),
        (e[(e.Font = 10)] = "Font"),
        (e[(e.Log = 11)] = "Log"),
        (e[(e.Drag = 12)] = "Drag"),
        (e[(e.StyleDeclaration = 13)] = "StyleDeclaration");
    })(b || (b = {})),
    (function (e) {
      (e[(e.MouseUp = 0)] = "MouseUp"),
        (e[(e.MouseDown = 1)] = "MouseDown"),
        (e[(e.Click = 2)] = "Click"),
        (e[(e.ContextMenu = 3)] = "ContextMenu"),
        (e[(e.DblClick = 4)] = "DblClick"),
        (e[(e.Focus = 5)] = "Focus"),
        (e[(e.Blur = 6)] = "Blur"),
        (e[(e.TouchStart = 7)] = "TouchStart"),
        (e[(e.TouchMove_Departed = 8)] = "TouchMove_Departed"),
        (e[(e.TouchEnd = 9)] = "TouchEnd"),
        (e[(e.TouchCancel = 10)] = "TouchCancel");
    })(S || (S = {})),
    (function (e) {
      (e[(e["2D"] = 0)] = "2D"), (e[(e.WebGL = 1)] = "WebGL"), (e[(e.WebGL2 = 2)] = "WebGL2");
    })(C || (C = {})),
    (function (e) {
      (e[(e.Play = 0)] = "Play"), (e[(e.Pause = 1)] = "Pause"), (e[(e.Seeked = 2)] = "Seeked"), (e[(e.VolumeChange = 3)] = "VolumeChange");
    })(k || (k = {})),
    (function (e) {
      (e.Start = "start"),
        (e.Pause = "pause"),
        (e.Resume = "resume"),
        (e.Resize = "resize"),
        (e.Finish = "finish"),
        (e.FullsnapshotRebuilded = "fullsnapshot-rebuilded"),
        (e.LoadStylesheetStart = "load-stylesheet-start"),
        (e.LoadStylesheetEnd = "load-stylesheet-end"),
        (e.SkipStart = "skip-start"),
        (e.SkipEnd = "skip-end"),
        (e.MouseInteraction = "mouse-interaction"),
        (e.EventCast = "event-cast"),
        (e.CustomEvent = "custom-event"),
        (e.Flush = "flush"),
        (e.StateChange = "state-change"),
        (e.PlayBack = "play-back");
    })(w || (w = {}));
  var D = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
    F = {
      map: {},
      getId: function () {
        return console.error(D), -1;
      },
      getNode: function () {
        return console.error(D), null;
      },
      removeNodeFromMap: function () {
        console.error(D);
      },
      has: function () {
        return console.error(D), !1;
      },
      reset: function () {
        console.error(D);
      },
    };
  function A(e, t, n) {
    void 0 === n && (n = {});
    var r = null,
      o = 0;
    return function (a) {
      var i = Date.now();
      o || !1 !== n.leading || (o = i);
      var s = t - (i - o),
        u = this,
        l = arguments;
      s <= 0 || s > t
        ? (r && (clearTimeout(r), (r = null)), (o = i), e.apply(u, l))
        : r ||
        !1 === n.trailing ||
        (r = setTimeout(function () {
          (o = !1 === n.leading ? 0 : Date.now()), (r = null), e.apply(u, l);
        }, s));
    };
  }
  function P(e, t, n, r, o) {
    void 0 === o && (o = window);
    var a = o.Object.getOwnPropertyDescriptor(e, t);
    return (
      o.Object.defineProperty(
        e,
        t,
        r
          ? n
          : {
            set: function (e) {
              var t = this;
              setTimeout(function () {
                n.set.call(t, e);
              }, 0),
              a && a.set && a.set.call(this, e);
            },
          }
      ),
        function () {
          return P(e, t, a || {}, !0);
        }
    );
  }
  function z(e, t, n) {
    try {
      if (!(t in e)) return function () {};
      var r = e[t],
        o = n(r);
      return (
        "function" == typeof o && ((o.prototype = o.prototype || {}), Object.defineProperties(o, { __rrweb_original__: { enumerable: !1, value: r } })),
          (e[t] = o),
          function () {
            e[t] = r;
          }
      );
    } catch (e) {
      return function () {};
    }
  }
  function W() {
    return window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || (document.body && document.body.clientHeight);
  }
  function U() {
    return window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || (document.body && document.body.clientWidth);
  }
  function j(e, t) {
    if (!e) return !1;
    if (e.nodeType === e.ELEMENT_NODE) {
      var n = !1;
      if ("string" == typeof t) {
        if (void 0 !== e.closest) return null !== e.closest("." + t);
        n = e.classList.contains(t);
      } else
        e.classList.forEach(function (e) {
          t.test(e) && (n = !0);
        });
      return n || j(e.parentNode, t);
    }
    return e.nodeType, e.TEXT_NODE, j(e.parentNode, t);
  }
  function G(e) {
    return "__sn" in e && -2 === e.__sn.id;
  }
  function V(e, t) {
    if (a(e)) return !1;
    var n = t.getId(e);
    return !t.has(n) || ((!e.parentNode || e.parentNode.nodeType !== e.DOCUMENT_NODE) && (!e.parentNode || V(e.parentNode, t)));
  }
  function H(e) {
    return Boolean(e.changedTouches);
  }
  function q(t) {
    return "__sn" in t && t.__sn.type === e.Element && "iframe" === t.__sn.tagName;
  }
  function B(e) {
    return Boolean(null == e ? void 0 : e.shadowRoot);
  }
  function X(e) {
    return "__ln" in e;
  }
  "undefined" != typeof window &&
  window.Proxy &&
  window.Reflect &&
  (F = new Proxy(F, {
    get: function (e, t, n) {
      return "map" === t && console.error(D), Reflect.get(e, t, n);
    },
  }));
  var Y = (function () {
      function e() {
        (this.length = 0), (this.head = null);
      }
      return (
        (e.prototype.get = function (e) {
          if (e >= this.length) throw new Error("Position outside of list range");
          for (var t = this.head, n = 0; n < e; n++) t = (null == t ? void 0 : t.next) || null;
          return t;
        }),
          (e.prototype.addNode = function (e) {
            var t = { value: e, previous: null, next: null };
            if (((e.__ln = t), e.previousSibling && X(e.previousSibling))) {
              var n = e.previousSibling.__ln.next;
              (t.next = n), (t.previous = e.previousSibling.__ln), (e.previousSibling.__ln.next = t), n && (n.previous = t);
            } else if (e.nextSibling && X(e.nextSibling) && e.nextSibling.__ln.previous) {
              n = e.nextSibling.__ln.previous;
              (t.previous = n), (t.next = e.nextSibling.__ln), (e.nextSibling.__ln.previous = t), n && (n.next = t);
            } else this.head && (this.head.previous = t), (t.next = this.head), (this.head = t);
            this.length++;
          }),
          (e.prototype.removeNode = function (e) {
            var t = e.__ln;
            this.head && (t.previous ? ((t.previous.next = t.next), t.next && (t.next.previous = t.previous)) : ((this.head = t.next), this.head && (this.head.previous = null)), e.__ln && delete e.__ln, this.length--);
          }),
          e
      );
    })(),
    K = function (e, t) {
      return "".concat(e, "@").concat(t);
    };
  function J(e) {
    return "__sn" in e;
  }
  var Z = (function () {
    function e() {
      var e = this;
      (this.frozen = !1),
        (this.locked = !1),
        (this.texts = []),
        (this.attributes = []),
        (this.removes = []),
        (this.mapRemoves = []),
        (this.movedMap = {}),
        (this.addedSet = new Set()),
        (this.movedSet = new Set()),
        (this.droppedSet = new Set()),
        (this.processMutations = function (t) {
          t.forEach(e.processMutation), e.emit();
        }),
        (this.emit = function () {
          var t, r, o, i;
          if (!e.frozen && !e.locked) {
            for (
              var s = [],
                u = new Y(),
                l = function (t) {
                  for (var n = t, r = -2; -2 === r; ) r = (n = n && n.nextSibling) && e.mirror.getId(n);
                  return r;
                },
                c = function (t) {
                  for (
                    var n, r, o, i, c, d = t.getRootNode ? (null === (n = t.getRootNode()) || void 0 === n ? void 0 : n.host) : null, p = d;
                    null === (o = null === (r = null == p ? void 0 : p.getRootNode) || void 0 === r ? void 0 : r.call(p)) || void 0 === o ? void 0 : o.host;

                  )
                    p = (null === (c = null === (i = null == p ? void 0 : p.getRootNode) || void 0 === i ? void 0 : i.call(p)) || void 0 === c ? void 0 : c.host) || null;
                  var f = !(e.doc.contains(t) || (null !== p && e.doc.contains(p)));
                  if (t.parentNode && !f) {
                    var m = a(t.parentNode) ? e.mirror.getId(d) : e.mirror.getId(t.parentNode),
                      h = l(t);
                    if (-1 === m || -1 === h) return u.addNode(t);
                    var v = _(t, {
                      doc: e.doc,
                      map: e.mirror.map,
                      blockClass: e.blockClass,
                      blockSelector: e.blockSelector,
                      maskTextClass: e.maskTextClass,
                      maskTextSelector: e.maskTextSelector,
                      skipChild: !0,
                      inlineStylesheet: e.inlineStylesheet,
                      maskInputOptions: e.maskInputOptions,
                      maskTextFn: e.maskTextFn,
                      maskInputFn: e.maskInputFn,
                      slimDOMOptions: e.slimDOMOptions,
                      recordCanvas: e.recordCanvas,
                      inlineImages: e.inlineImages,
                      onSerialize: function (n) {
                        q(n) && e.iframeManager.addIframe(n), B(t) && e.shadowDomManager.addShadowRoot(t.shadowRoot, document);
                      },
                      onIframeLoad: function (t, n) {
                        e.iframeManager.attachIframe(t, n), e.shadowDomManager.observeAttachShadow(t);
                      },
                    });
                    v && s.push({ parentId: m, nextId: h, node: v });
                  }
                };
              e.mapRemoves.length;

            )
              e.mirror.removeNodeFromMap(e.mapRemoves.shift());
            try {
              for (var d = n(e.movedSet), p = d.next(); !p.done; p = d.next()) {
                var f = p.value;
                (Q(e.removes, f, e.mirror) && !e.movedSet.has(f.parentNode)) || c(f);
              }
            } catch (e) {
              t = { error: e };
            } finally {
              try {
                p && !p.done && (r = d.return) && r.call(d);
              } finally {
                if (t) throw t.error;
              }
            }
            try {
              for (var m = n(e.addedSet), h = m.next(); !h.done; h = m.next()) {
                f = h.value;
                ee(e.droppedSet, f) || Q(e.removes, f, e.mirror) ? (ee(e.movedSet, f) ? c(f) : e.droppedSet.add(f)) : c(f);
              }
            } catch (e) {
              o = { error: e };
            } finally {
              try {
                h && !h.done && (i = m.return) && i.call(m);
              } finally {
                if (o) throw o.error;
              }
            }
            for (var v = null; u.length; ) {
              var y = null;
              if (v) {
                var g = e.mirror.getId(v.value.parentNode),
                  b = l(v.value);
                -1 !== g && -1 !== b && (y = v);
              }
              if (!y)
                for (var S = u.length - 1; S >= 0; S--) {
                  var C = u.get(S);
                  if (C) {
                    (g = e.mirror.getId(C.value.parentNode)), (b = l(C.value));
                    if (-1 !== g && -1 !== b) {
                      y = C;
                      break;
                    }
                  }
                }
              if (!y) {
                for (; u.head; ) u.removeNode(u.head.value);
                break;
              }
              (v = y.previous), u.removeNode(y.value), c(y.value);
            }
            var k = {
              texts: e.texts
                .map(function (t) {
                  return { id: e.mirror.getId(t.node), value: t.value };
                })
                .filter(function (t) {
                  return e.mirror.has(t.id);
                }),
              attributes: e.attributes
                .map(function (t) {
                  return { id: e.mirror.getId(t.node), attributes: t.attributes };
                })
                .filter(function (t) {
                  return e.mirror.has(t.id);
                }),
              removes: e.removes,
              adds: s,
            };
            (k.texts.length || k.attributes.length || k.removes.length || k.adds.length) &&
            ((e.texts = []), (e.attributes = []), (e.removes = []), (e.addedSet = new Set()), (e.movedSet = new Set()), (e.droppedSet = new Set()), (e.movedMap = {}), e.mutationCb(k));
          }
        }),
        (this.processMutation = function (t) {
          var r, o, s, u;
          if (!G(t.target))
            switch (t.type) {
              case "characterData":
                var l = t.target.textContent;
                j(t.target, e.blockClass) ||
                l === t.oldValue ||
                e.texts.push({ value: O(t.target, e.maskTextClass, e.maskTextSelector) && l ? (e.maskTextFn ? e.maskTextFn(l) : l.replace(/[\S]/g, "*")) : l, node: t.target });
                break;
              case "attributes":
                var c = t.target;
                l = t.target.getAttribute(t.attributeName);
                if (
                  ("value" === t.attributeName && (l = i({ maskInputOptions: e.maskInputOptions, tagName: t.target.tagName, type: t.target.getAttribute("type"), value: l, maskInputFn: e.maskInputFn })),
                  j(t.target, e.blockClass) || l === t.oldValue)
                )
                  return;
                var d = e.attributes.find(function (e) {
                  return e.node === t.target;
                });
                if ((d || ((d = { node: t.target, attributes: {} }), e.attributes.push(d)), "style" === t.attributeName)) {
                  var p = e.doc.createElement("span");
                  t.oldValue && p.setAttribute("style", t.oldValue), (void 0 !== d.attributes.style && null !== d.attributes.style) || (d.attributes.style = {});
                  var f = d.attributes.style;
                  try {
                    for (var m = n(Array.from(c.style)), h = m.next(); !h.done; h = m.next()) {
                      var v = h.value,
                        y = c.style.getPropertyValue(v),
                        g = c.style.getPropertyPriority(v);
                      (y === p.style.getPropertyValue(v) && g === p.style.getPropertyPriority(v)) || (f[v] = "" === g ? y : [y, g]);
                    }
                  } catch (e) {
                    r = { error: e };
                  } finally {
                    try {
                      h && !h.done && (o = m.return) && o.call(m);
                    } finally {
                      if (r) throw r.error;
                    }
                  }
                  try {
                    for (var b = n(Array.from(p.style)), S = b.next(); !S.done; S = b.next()) {
                      v = S.value;
                      "" === c.style.getPropertyValue(v) && (f[v] = !1);
                    }
                  } catch (e) {
                    s = { error: e };
                  } finally {
                    try {
                      S && !S.done && (u = b.return) && u.call(b);
                    } finally {
                      if (s) throw s.error;
                    }
                  }
                } else d.attributes[t.attributeName] = E(e.doc, t.target.tagName, t.attributeName, l);
                break;
              case "childList":
                t.addedNodes.forEach(function (n) {
                  return e.genAdds(n, t.target);
                }),
                  t.removedNodes.forEach(function (n) {
                    var r = e.mirror.getId(n),
                      o = a(t.target) ? e.mirror.getId(t.target.host) : e.mirror.getId(t.target);
                    j(t.target, e.blockClass) ||
                    G(n) ||
                    (e.addedSet.has(n)
                      ? ($(e.addedSet, n), e.droppedSet.add(n))
                      : (e.addedSet.has(t.target) && -1 === r) ||
                      V(t.target, e.mirror) ||
                      (e.movedSet.has(n) && e.movedMap[K(r, o)] ? $(e.movedSet, n) : e.removes.push({ parentId: o, id: r, isShadow: !!a(t.target) || void 0 })),
                      e.mapRemoves.push(n));
                  });
            }
        }),
        (this.genAdds = function (t, n) {
          if (!n || !j(n, e.blockClass)) {
            if (J(t)) {
              if (G(t)) return;
              e.movedSet.add(t);
              var r = null;
              n && J(n) && (r = n.__sn.id), r && (e.movedMap[K(t.__sn.id, r)] = !0);
            } else e.addedSet.add(t), e.droppedSet.delete(t);
            j(t, e.blockClass) ||
            t.childNodes.forEach(function (t) {
              return e.genAdds(t);
            });
          }
        });
    }
    return (
      (e.prototype.init = function (e) {
        var t = this;
        [
          "mutationCb",
          "blockClass",
          "blockSelector",
          "maskTextClass",
          "maskTextSelector",
          "inlineStylesheet",
          "maskInputOptions",
          "maskTextFn",
          "maskInputFn",
          "recordCanvas",
          "inlineImages",
          "slimDOMOptions",
          "doc",
          "mirror",
          "iframeManager",
          "shadowDomManager",
          "canvasManager",
        ].forEach(function (n) {
          t[n] = e[n];
        });
      }),
        (e.prototype.freeze = function () {
          (this.frozen = !0), this.canvasManager.freeze();
        }),
        (e.prototype.unfreeze = function () {
          (this.frozen = !1), this.canvasManager.unfreeze(), this.emit();
        }),
        (e.prototype.isFrozen = function () {
          return this.frozen;
        }),
        (e.prototype.lock = function () {
          (this.locked = !0), this.canvasManager.lock();
        }),
        (e.prototype.unlock = function () {
          (this.locked = !1), this.canvasManager.unlock(), this.emit();
        }),
        (e.prototype.reset = function () {
          this.shadowDomManager.reset(), this.canvasManager.reset();
        }),
        e
    );
  })();
  function $(e, t) {
    e.delete(t),
      t.childNodes.forEach(function (t) {
        return $(e, t);
      });
  }
  function Q(e, t, n) {
    var r = t.parentNode;
    if (!r) return !1;
    var o = n.getId(r);
    return (
      !!e.some(function (e) {
        return e.id === o;
      }) || Q(e, r, n)
    );
  }
  function ee(e, t) {
    var n = t.parentNode;
    return !!n && (!!e.has(n) || ee(e, n));
  }
  var te = [],
    ne = "undefined" != typeof CSSGroupingRule,
    re = "undefined" != typeof CSSMediaRule,
    oe = "undefined" != typeof CSSSupportsRule,
    ae = "undefined" != typeof CSSConditionRule;
  function ie(e) {
    try {
      if ("composedPath" in e) {
        var t = e.composedPath();
        if (t.length) return t[0];
      } else if ("path" in e && e.path.length) return e.path[0];
      return e.target;
    } catch (t) {
      return e.target;
    }
  }
  function se(e, t) {
    var n,
      r,
      o = new Z();
    te.push(o), o.init(e);
    var a = window.MutationObserver || window.__rrMutationObserver,
      i = null === (r = null === (n = null === window || void 0 === window ? void 0 : window.Zone) || void 0 === n ? void 0 : n.__symbol__) || void 0 === r ? void 0 : r.call(n, "MutationObserver");
    i && window[i] && (a = window[i]);
    var s = new a(o.processMutations.bind(o));
    return s.observe(t, { attributes: !0, attributeOldValue: !0, characterData: !0, characterDataOldValue: !0, childList: !0, subtree: !0 }), s;
  }
  function ue(e) {
    var t = e.mouseInteractionCb,
      n = e.doc,
      r = e.mirror,
      o = e.blockClass,
      a = e.sampling;
    if (!1 === a.mouseInteraction) return function () {};
    var i = !0 === a.mouseInteraction || void 0 === a.mouseInteraction ? {} : a.mouseInteraction,
      s = [];
    return (
      Object.keys(S)
        .filter(function (e) {
          return Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== i[e];
        })
        .forEach(function (e) {
          var a = e.toLowerCase(),
            i = (function (e) {
              return function (n) {
                var a = ie(n);
                if (!j(a, o)) {
                  var i = H(n) ? n.changedTouches[0] : n;
                  if (i) {
                    var s = r.getId(a),
                      u = i.clientX,
                      l = i.clientY;
                    t({ type: S[e], id: s, x: u, y: l });
                  }
                }
              };
            })(e);
          s.push(L(a, i, n));
        }),
        function () {
          s.forEach(function (e) {
            return e();
          });
        }
    );
  }
  function le(e) {
    var t = e.scrollCb,
      n = e.doc,
      r = e.mirror,
      o = e.blockClass;
    return L(
      "scroll",
      A(function (e) {
        var a = ie(e);
        if (a && !j(a, o)) {
          var i = r.getId(a);
          if (a === n) {
            var s = n.scrollingElement || n.documentElement;
            t({ id: i, x: s.scrollLeft, y: s.scrollTop });
          } else t({ id: i, x: a.scrollLeft, y: a.scrollTop });
        }
      }, e.sampling.scroll || 100),
      n
    );
  }
  function ce(e, n) {
    var r = t({}, e);
    return n || delete r.userTriggered, r;
  }
  var de = ["INPUT", "TEXTAREA", "SELECT"],
    pe = new WeakMap();
  function fe(e) {
    return (function (e, t) {
      if ((ne && e.parentRule instanceof CSSGroupingRule) || (re && e.parentRule instanceof CSSMediaRule) || (oe && e.parentRule instanceof CSSSupportsRule) || (ae && e.parentRule instanceof CSSConditionRule)) {
        var n = Array.from(e.parentRule.cssRules).indexOf(e);
        t.unshift(n);
      } else {
        n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
        t.unshift(n);
      }
      return t;
    })(e, []);
  }
  function me(e, a) {
    var s, u;
    void 0 === a && (a = {});
    var l = e.doc.defaultView;
    if (!l) return function () {};
    !(function (e, t) {
      var n = e.mutationCb,
        a = e.mousemoveCb,
        i = e.mouseInteractionCb,
        s = e.scrollCb,
        u = e.viewportResizeCb,
        l = e.inputCb,
        c = e.mediaInteractionCb,
        d = e.styleSheetRuleCb,
        p = e.styleDeclarationCb,
        f = e.canvasMutationCb,
        m = e.fontCb;
      (e.mutationCb = function () {
        for (var e = [], a = 0; a < arguments.length; a++) e[a] = arguments[a];
        t.mutation && t.mutation.apply(t, o([], r(e), !1)), n.apply(void 0, o([], r(e), !1));
      }),
        (e.mousemoveCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.mousemove && t.mousemove.apply(t, o([], r(e), !1)), a.apply(void 0, o([], r(e), !1));
        }),
        (e.mouseInteractionCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.mouseInteraction && t.mouseInteraction.apply(t, o([], r(e), !1)), i.apply(void 0, o([], r(e), !1));
        }),
        (e.scrollCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.scroll && t.scroll.apply(t, o([], r(e), !1)), s.apply(void 0, o([], r(e), !1));
        }),
        (e.viewportResizeCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.viewportResize && t.viewportResize.apply(t, o([], r(e), !1)), u.apply(void 0, o([], r(e), !1));
        }),
        (e.inputCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.input && t.input.apply(t, o([], r(e), !1)), l.apply(void 0, o([], r(e), !1));
        }),
        (e.mediaInteractionCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.mediaInteaction && t.mediaInteaction.apply(t, o([], r(e), !1)), c.apply(void 0, o([], r(e), !1));
        }),
        (e.styleSheetRuleCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.styleSheetRule && t.styleSheetRule.apply(t, o([], r(e), !1)), d.apply(void 0, o([], r(e), !1));
        }),
        (e.styleDeclarationCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.styleDeclaration && t.styleDeclaration.apply(t, o([], r(e), !1)), p.apply(void 0, o([], r(e), !1));
        }),
        (e.canvasMutationCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.canvasMutation && t.canvasMutation.apply(t, o([], r(e), !1)), f.apply(void 0, o([], r(e), !1));
        }),
        (e.fontCb = function () {
          for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
          t.font && t.font.apply(t, o([], r(e), !1)), m.apply(void 0, o([], r(e), !1));
        });
    })(e, a);
    var c = se(e, e.doc),
      d = (function (e) {
        var t = e.mousemoveCb,
          n = e.sampling,
          r = e.doc,
          o = e.mirror;
        if (!1 === n.mousemove) return function () {};
        var a,
          i = "number" == typeof n.mousemove ? n.mousemove : 50,
          s = "number" == typeof n.mousemoveCallback ? n.mousemoveCallback : 500,
          u = [],
          l = A(function (e) {
            var n = Date.now() - a;
            t(
              u.map(function (e) {
                return (e.timeOffset -= n), e;
              }),
              e
            ),
              (u = []),
              (a = null);
          }, s),
          c = A(
            function (e) {
              var t = ie(e),
                n = H(e) ? e.changedTouches[0] : e,
                r = n.clientX,
                i = n.clientY;
              a || (a = Date.now()),
                u.push({ x: r, y: i, id: o.getId(t), timeOffset: Date.now() - a }),
                l("undefined" != typeof DragEvent && e instanceof DragEvent ? b.Drag : e instanceof MouseEvent ? b.MouseMove : b.TouchMove);
            },
            i,
            { trailing: !1 }
          ),
          d = [L("mousemove", c, r), L("touchmove", c, r), L("drag", c, r)];
        return function () {
          d.forEach(function (e) {
            return e();
          });
        };
      })(e),
      p = ue(e),
      f = le(e),
      m = (function (e) {
        var t = e.viewportResizeCb,
          n = -1,
          r = -1;
        return L(
          "resize",
          A(function () {
            var e = W(),
              o = U();
            (n === e && r === o) || (t({ width: Number(o), height: Number(e) }), (n = e), (r = o));
          }, 200),
          window
        );
      })(e),
      h = (function (e) {
        var n = e.inputCb,
          a = e.doc,
          s = e.mirror,
          u = e.blockClass,
          l = e.ignoreClass,
          c = e.maskInputOptions,
          d = e.maskInputFn,
          p = e.sampling,
          f = e.userTriggeredOnInput;
        function m(e) {
          var t = ie(e),
            n = e.isTrusted;
          if ((t && "OPTION" === t.tagName && (t = t.parentElement), t && t.tagName && !(de.indexOf(t.tagName) < 0) && !j(t, u))) {
            var r = t.type;
            if (!t.classList.contains(l)) {
              var o = t.value,
                s = !1;
              "radio" === r || "checkbox" === r ? (s = t.checked) : (c[t.tagName.toLowerCase()] || c[r]) && (o = i({ maskInputOptions: c, tagName: t.tagName, type: r, value: o, maskInputFn: d })),
                h(t, ce({ text: o, isChecked: s, userTriggered: n }, f));
              var p = t.name;
              "radio" === r &&
              p &&
              s &&
              a.querySelectorAll('input[type="radio"][name="'.concat(p, '"]')).forEach(function (e) {
                e !== t && h(e, ce({ text: e.value, isChecked: !s, userTriggered: !1 }, f));
              });
            }
          }
        }
        function h(e, r) {
          var o = pe.get(e);
          if (!o || o.text !== r.text || o.isChecked !== r.isChecked) {
            pe.set(e, r);
            var a = s.getId(e);
            n(t(t({}, r), { id: a }));
          }
        }
        var v = ("last" === p.input ? ["change"] : ["input", "change"]).map(function (e) {
            return L(e, m, a);
          }),
          y = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value"),
          g = [
            [HTMLInputElement.prototype, "value"],
            [HTMLInputElement.prototype, "checked"],
            [HTMLSelectElement.prototype, "value"],
            [HTMLTextAreaElement.prototype, "value"],
            [HTMLSelectElement.prototype, "selectedIndex"],
            [HTMLOptionElement.prototype, "selected"],
          ];
        return (
          y &&
          y.set &&
          v.push.apply(
            v,
            o(
              [],
              r(
                g.map(function (e) {
                  return P(e[0], e[1], {
                    set: function () {
                      m({ target: this });
                    },
                  });
                })
              ),
              !1
            )
          ),
            function () {
              v.forEach(function (e) {
                return e();
              });
            }
        );
      })(e),
      v = (function (e) {
        var t = e.mediaInteractionCb,
          n = e.blockClass,
          r = e.mirror,
          o = e.sampling,
          a = function (e) {
            return A(function (o) {
              var a = ie(o);
              if (a && !j(a, n)) {
                var i = a,
                  s = i.currentTime,
                  u = i.volume,
                  l = i.muted;
                t({ type: e, id: r.getId(a), currentTime: s, volume: u, muted: l });
              }
            }, o.media || 500);
          },
          i = [L("play", a(0)), L("pause", a(1)), L("seeked", a(2)), L("volumechange", a(3))];
        return function () {
          i.forEach(function (e) {
            return e();
          });
        };
      })(e),
      y = (function (e, t) {
        var n = e.styleSheetRuleCb,
          a = e.mirror,
          i = t.win,
          s = i.CSSStyleSheet.prototype.insertRule;
        i.CSSStyleSheet.prototype.insertRule = function (e, t) {
          var r = a.getId(this.ownerNode);
          return -1 !== r && n({ id: r, adds: [{ rule: e, index: t }] }), s.apply(this, arguments);
        };
        var u = i.CSSStyleSheet.prototype.deleteRule;
        i.CSSStyleSheet.prototype.deleteRule = function (e) {
          var t = a.getId(this.ownerNode);
          return -1 !== t && n({ id: t, removes: [{ index: e }] }), u.apply(this, arguments);
        };
        var l = {};
        ne ? (l.CSSGroupingRule = i.CSSGroupingRule) : (re && (l.CSSMediaRule = i.CSSMediaRule), ae && (l.CSSConditionRule = i.CSSConditionRule), oe && (l.CSSSupportsRule = i.CSSSupportsRule));
        var c = {};
        return (
          Object.entries(l).forEach(function (e) {
            var t = r(e, 2),
              i = t[0],
              s = t[1];
            (c[i] = { insertRule: s.prototype.insertRule, deleteRule: s.prototype.deleteRule }),
              (s.prototype.insertRule = function (e, t) {
                var s = a.getId(this.parentStyleSheet.ownerNode);
                return -1 !== s && n({ id: s, adds: [{ rule: e, index: o(o([], r(fe(this)), !1), [t || 0], !1) }] }), c[i].insertRule.apply(this, arguments);
              }),
              (s.prototype.deleteRule = function (e) {
                var t = a.getId(this.parentStyleSheet.ownerNode);
                return -1 !== t && n({ id: t, removes: [{ index: o(o([], r(fe(this)), !1), [e], !1) }] }), c[i].deleteRule.apply(this, arguments);
              });
          }),
            function () {
              (i.CSSStyleSheet.prototype.insertRule = s),
                (i.CSSStyleSheet.prototype.deleteRule = u),
                Object.entries(l).forEach(function (e) {
                  var t = r(e, 2),
                    n = t[0],
                    o = t[1];
                  (o.prototype.insertRule = c[n].insertRule), (o.prototype.deleteRule = c[n].deleteRule);
                });
            }
        );
      })(e, { win: l }),
      g = (function (e, t) {
        var n = e.styleDeclarationCb,
          r = e.mirror,
          o = t.win,
          a = o.CSSStyleDeclaration.prototype.setProperty;
        o.CSSStyleDeclaration.prototype.setProperty = function (e, t, o) {
          var i,
            s,
            u = r.getId(null === (s = null === (i = this.parentRule) || void 0 === i ? void 0 : i.parentStyleSheet) || void 0 === s ? void 0 : s.ownerNode);
          return -1 !== u && n({ id: u, set: { property: e, value: t, priority: o }, index: fe(this.parentRule) }), a.apply(this, arguments);
        };
        var i = o.CSSStyleDeclaration.prototype.removeProperty;
        return (
          (o.CSSStyleDeclaration.prototype.removeProperty = function (e) {
            var t,
              o,
              a = r.getId(null === (o = null === (t = this.parentRule) || void 0 === t ? void 0 : t.parentStyleSheet) || void 0 === o ? void 0 : o.ownerNode);
            return -1 !== a && n({ id: a, remove: { property: e }, index: fe(this.parentRule) }), i.apply(this, arguments);
          }),
            function () {
              (o.CSSStyleDeclaration.prototype.setProperty = a), (o.CSSStyleDeclaration.prototype.removeProperty = i);
            }
        );
      })(e, { win: l }),
      S = e.collectFonts
        ? (function (e) {
          var t = e.fontCb,
            n = e.doc,
            r = n.defaultView;
          if (!r) return function () {};
          var o = [],
            a = new WeakMap(),
            i = r.FontFace;
          r.FontFace = function (e, t, n) {
            var r = new i(e, t, n);
            return a.set(r, { family: e, buffer: "string" != typeof t, descriptors: n, fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t))) }), r;
          };
          var s = z(n.fonts, "add", function (e) {
            return function (n) {
              return (
                setTimeout(function () {
                  var e = a.get(n);
                  e && (t(e), a.delete(n));
                }, 0),
                  e.apply(this, [n])
              );
            };
          });
          return (
            o.push(function () {
              r.FontFace = i;
            }),
              o.push(s),
              function () {
                o.forEach(function (e) {
                  return e();
                });
              }
          );
        })(e)
        : function () {},
      C = [];
    try {
      for (var k = n(e.plugins), w = k.next(); !w.done; w = k.next()) {
        var I = w.value;
        C.push(I.observer(I.callback, l, I.options));
      }
    } catch (e) {
      s = { error: e };
    } finally {
      try {
        w && !w.done && (u = k.return) && u.call(k);
      } finally {
        if (s) throw s.error;
      }
    }
    return function () {
      te.forEach(function (e) {
        return e.reset();
      }),
        c.disconnect(),
        d(),
        p(),
        f(),
        m(),
        h(),
        v(),
        y(),
        g(),
        S(),
        C.forEach(function (e) {
          return e();
        });
    };
  }
  var he = (function () {
      function e(e) {
        (this.iframes = new WeakMap()), (this.mutationCb = e.mutationCb);
      }
      return (
        (e.prototype.addIframe = function (e) {
          this.iframes.set(e, !0);
        }),
          (e.prototype.addLoadListener = function (e) {
            this.loadListener = e;
          }),
          (e.prototype.attachIframe = function (e, t) {
            var n;
            this.mutationCb({ adds: [{ parentId: e.__sn.id, nextId: null, node: t }], removes: [], texts: [], attributes: [], isAttachIframe: !0 }), null === (n = this.loadListener) || void 0 === n || n.call(this, e);
          }),
          e
      );
    })(),
    ve = (function () {
      function e(e) {
        (this.restorePatches = []), (this.mutationCb = e.mutationCb), (this.scrollCb = e.scrollCb), (this.bypassOptions = e.bypassOptions), (this.mirror = e.mirror);
        var t = this;
        this.restorePatches.push(
          z(HTMLElement.prototype, "attachShadow", function (e) {
            return function () {
              var n = e.apply(this, arguments);
              return this.shadowRoot && t.addShadowRoot(this.shadowRoot, this.ownerDocument), n;
            };
          })
        );
      }
      return (
        (e.prototype.addShadowRoot = function (e, n) {
          se(t(t({}, this.bypassOptions), { doc: n, mutationCb: this.mutationCb, mirror: this.mirror, shadowDomManager: this }), e), le(t(t({}, this.bypassOptions), { scrollCb: this.scrollCb, doc: e, mirror: this.mirror }));
        }),
          (e.prototype.observeAttachShadow = function (e) {
            if (e.contentWindow) {
              var t = this;
              this.restorePatches.push(
                z(e.contentWindow.HTMLElement.prototype, "attachShadow", function (n) {
                  return function () {
                    var r = n.apply(this, arguments);
                    return this.shadowRoot && t.addShadowRoot(this.shadowRoot, e.contentDocument), r;
                  };
                })
              );
            }
          }),
          (e.prototype.reset = function () {
            this.restorePatches.forEach(function (e) {
              return e();
            });
          }),
          e
      );
    })();
  for (var ye = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ge = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256), be = 0; be < ye.length; be++) ge[ye.charCodeAt(be)] = be;
  var Se = new Map();
  var Ce = function (e, t, n) {
    if (e && (Ie(e, t) || "object" == typeof e)) {
      var r = (function (e, t) {
          var n = Se.get(e);
          return n || ((n = new Map()), Se.set(e, n)), n.has(t) || n.set(t, []), n.get(t);
        })(n, e.constructor.name),
        o = r.indexOf(e);
      return -1 === o && ((o = r.length), r.push(e)), o;
    }
  };
  function ke(e, t, n) {
    return e instanceof Array
      ? e.map(function (e) {
        return ke(e, t, n);
      })
      : null === e
        ? e
        : e instanceof Float32Array ||
        e instanceof Float64Array ||
        e instanceof Int32Array ||
        e instanceof Uint32Array ||
        e instanceof Uint8Array ||
        e instanceof Uint16Array ||
        e instanceof Int16Array ||
        e instanceof Int8Array ||
        e instanceof Uint8ClampedArray
          ? { rr_type: e.constructor.name, args: [Object.values(e)] }
          : e instanceof ArrayBuffer
            ? {
              rr_type: e.constructor.name,
              base64: (function (e) {
                var t,
                  n = new Uint8Array(e),
                  r = n.length,
                  o = "";
                for (t = 0; t < r; t += 3) (o += ye[n[t] >> 2]), (o += ye[((3 & n[t]) << 4) | (n[t + 1] >> 4)]), (o += ye[((15 & n[t + 1]) << 2) | (n[t + 2] >> 6)]), (o += ye[63 & n[t + 2]]);
                return r % 3 == 2 ? (o = o.substring(0, o.length - 1) + "=") : r % 3 == 1 && (o = o.substring(0, o.length - 2) + "=="), o;
              })(e),
            }
            : e instanceof DataView
              ? { rr_type: e.constructor.name, args: [ke(e.buffer, t, n), e.byteOffset, e.byteLength] }
              : e instanceof HTMLImageElement
                ? { rr_type: e.constructor.name, src: e.src }
                : e instanceof ImageData
                  ? { rr_type: e.constructor.name, args: [ke(e.data, t, n), e.width, e.height] }
                  : Ie(e, t) || "object" == typeof e
                    ? { rr_type: e.constructor.name, index: Ce(e, t, n) }
                    : e;
  }
  var we = function (e, t, n) {
      return o([], r(e), !1).map(function (e) {
        return ke(e, t, n);
      });
    },
    Ie = function (e, t) {
      var n = [
        "WebGLActiveInfo",
        "WebGLBuffer",
        "WebGLFramebuffer",
        "WebGLProgram",
        "WebGLRenderbuffer",
        "WebGLShader",
        "WebGLShaderPrecisionFormat",
        "WebGLTexture",
        "WebGLUniformLocation",
        "WebGLVertexArrayObject",
        "WebGLVertexArrayObjectOES",
      ].filter(function (e) {
        return "function" == typeof t[e];
      });
      return Boolean(
        n.find(function (n) {
          return e instanceof t[n];
        })
      );
    };
  function xe(e, t, a, i, s, u) {
    var l,
      c,
      d = [],
      p = Object.getOwnPropertyNames(e),
      f = function (n) {
        try {
          if ("function" != typeof e[n]) return "continue";
          var l = z(e, n, function (l) {
            return function () {
              for (var c = [], d = 0; d < arguments.length; d++) c[d] = arguments[d];
              var p = l.apply(this, c);
              if ((Ce(p, u, e), !j(this.canvas, i))) {
                s.getId(this.canvas);
                var f = we(o([], r(c), !1), u, e),
                  m = { type: t, property: n, args: f };
                a(this.canvas, m);
              }
              return p;
            };
          });
          d.push(l);
        } catch (r) {
          var c = P(e, n, {
            set: function (e) {
              a(this.canvas, { type: t, property: n, args: [e], setter: !0 });
            },
          });
          d.push(c);
        }
      };
    try {
      for (var m = n(p), h = m.next(); !h.done; h = m.next()) {
        f(h.value);
      }
    } catch (e) {
      l = { error: e };
    } finally {
      try {
        h && !h.done && (c = m.return) && c.call(m);
      } finally {
        if (l) throw l.error;
      }
    }
    return d;
  }
  var Me,
    Te,
    Ee = (function () {
      function e(e) {
        (this.pendingCanvasMutations = new Map()),
          (this.rafStamps = { latestId: 0, invokeId: null }),
          (this.frozen = !1),
          (this.locked = !1),
          (this.processMutation = function (e, t) {
            (!(this.rafStamps.invokeId && this.rafStamps.latestId !== this.rafStamps.invokeId) && this.rafStamps.invokeId) || (this.rafStamps.invokeId = this.rafStamps.latestId),
            this.pendingCanvasMutations.has(e) || this.pendingCanvasMutations.set(e, []),
              this.pendingCanvasMutations.get(e).push(t);
          }),
          (this.mutationCb = e.mutationCb),
          (this.mirror = e.mirror),
        !0 === e.recordCanvas && this.initCanvasMutationObserver(e.win, e.blockClass);
      }
      return (
        (e.prototype.reset = function () {
          this.pendingCanvasMutations.clear(), this.resetObservers && this.resetObservers();
        }),
          (e.prototype.freeze = function () {
            this.frozen = !0;
          }),
          (e.prototype.unfreeze = function () {
            this.frozen = !1;
          }),
          (e.prototype.lock = function () {
            this.locked = !0;
          }),
          (e.prototype.unlock = function () {
            this.locked = !1;
          }),
          (e.prototype.initCanvasMutationObserver = function (e, t) {
            this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher();
            var a = (function (e, t) {
                var n = [];
                try {
                  var a = z(e.HTMLCanvasElement.prototype, "getContext", function (e) {
                    return function (n) {
                      for (var a = [], i = 1; i < arguments.length; i++) a[i - 1] = arguments[i];
                      return j(this, t) || "__context" in this || (this.__context = n), e.apply(this, o([n], r(a), !1));
                    };
                  });
                  n.push(a);
                } catch (e) {
                  console.error("failed to patch HTMLCanvasElement.prototype.getContext");
                }
                return function () {
                  n.forEach(function (e) {
                    return e();
                  });
                };
              })(e, t),
              i = (function (e, t, a, i) {
                var s,
                  u,
                  l = [],
                  c = Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype),
                  d = function (n) {
                    try {
                      if ("function" != typeof t.CanvasRenderingContext2D.prototype[n]) return "continue";
                      var i = z(t.CanvasRenderingContext2D.prototype, n, function (t) {
                        return function () {
                          for (var i = this, s = [], u = 0; u < arguments.length; u++) s[u] = arguments[u];
                          return (
                            j(this.canvas, a) ||
                            setTimeout(function () {
                              var t = o([], r(s), !1);
                              if ("drawImage" === n && t[0] && t[0] instanceof HTMLCanvasElement) {
                                var a = t[0],
                                  u = a.getContext("2d"),
                                  l = null == u ? void 0 : u.getImageData(0, 0, a.width, a.height),
                                  c = null == l ? void 0 : l.data;
                                t[0] = JSON.stringify(c);
                              }
                              e(i.canvas, { type: C["2D"], property: n, args: t });
                            }, 0),
                              t.apply(this, s)
                          );
                        };
                      });
                      l.push(i);
                    } catch (r) {
                      var s = P(t.CanvasRenderingContext2D.prototype, n, {
                        set: function (t) {
                          e(this.canvas, { type: C["2D"], property: n, args: [t], setter: !0 });
                        },
                      });
                      l.push(s);
                    }
                  };
                try {
                  for (var p = n(c), f = p.next(); !f.done; f = p.next()) d(f.value);
                } catch (e) {
                  s = { error: e };
                } finally {
                  try {
                    f && !f.done && (u = p.return) && u.call(p);
                  } finally {
                    if (s) throw s.error;
                  }
                }
                return function () {
                  l.forEach(function (e) {
                    return e();
                  });
                };
              })(this.processMutation.bind(this), e, t, this.mirror),
              s = (function (e, t, n, a) {
                var i = [];
                return (
                  i.push.apply(i, o([], r(xe(t.WebGLRenderingContext.prototype, C.WebGL, e, n, a, t)), !1)),
                  void 0 !== t.WebGL2RenderingContext && i.push.apply(i, o([], r(xe(t.WebGL2RenderingContext.prototype, C.WebGL2, e, n, a, t)), !1)),
                    function () {
                      i.forEach(function (e) {
                        return e();
                      });
                    }
                );
              })(this.processMutation.bind(this), e, t, this.mirror);
            this.resetObservers = function () {
              a(), i(), s();
            };
          }),
          (e.prototype.startPendingCanvasMutationFlusher = function () {
            var e = this;
            requestAnimationFrame(function () {
              return e.flushPendingCanvasMutations();
            });
          }),
          (e.prototype.startRAFTimestamping = function () {
            var e = this,
              t = function (n) {
                (e.rafStamps.latestId = n), requestAnimationFrame(t);
              };
            requestAnimationFrame(t);
          }),
          (e.prototype.flushPendingCanvasMutations = function () {
            var e = this;
            this.pendingCanvasMutations.forEach(function (t, n) {
              var r = e.mirror.getId(n);
              e.flushPendingCanvasMutationFor(n, r);
            }),
              requestAnimationFrame(function () {
                return e.flushPendingCanvasMutations();
              });
          }),
          (e.prototype.flushPendingCanvasMutationFor = function (e, t) {
            if (!this.frozen && !this.locked) {
              var n = this.pendingCanvasMutations.get(e);
              if (n && -1 !== t) {
                var r = n.map(function (e) {
                    return (
                      e.type,
                        (function (e, t) {
                          var n = {};
                          for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
                          if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                            var o = 0;
                            for (r = Object.getOwnPropertySymbols(e); o < r.length; o++) t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
                          }
                          return n;
                        })(e, ["type"])
                    );
                  }),
                  o = n[0].type;
                this.mutationCb({ id: t, type: o, commands: r }), this.pendingCanvasMutations.delete(e);
              }
            }
          }),
          e
      );
    })();
  function Oe(e) {
    return t(t({}, e), { timestamp: Date.now() });
  }
  var Re = {
    map: {},
    getId: function (e) {
      return e && e.__sn ? e.__sn.id : -1;
    },
    getNode: function (e) {
      return this.map[e] || null;
    },
    removeNodeFromMap: function (e) {
      var t = this,
        n = e.__sn && e.__sn.id;
      delete this.map[n],
      e.childNodes &&
      e.childNodes.forEach(function (e) {
        return t.removeNodeFromMap(e);
      });
    },
    has: function (e) {
      return this.map.hasOwnProperty(e);
    },
    reset: function () {
      this.map = {};
    },
  };
  function Ne(e) {
    void 0 === e && (e = {});
    var o = e.emit,
      a = e.checkoutEveryNms,
      i = e.checkoutEveryNth,
      s = e.blockClass,
      u = void 0 === s ? "rr-block" : s,
      l = e.blockSelector,
      c = void 0 === l ? null : l,
      d = e.ignoreClass,
      p = void 0 === d ? "rr-ignore" : d,
      f = e.maskTextClass,
      m = void 0 === f ? "rr-mask" : f,
      h = e.maskTextSelector,
      v = void 0 === h ? null : h,
      y = e.inlineStylesheet,
      S = void 0 === y || y,
      C = e.maskAllInputs,
      k = e.maskInputOptions,
      w = e.slimDOMOptions,
      I = e.maskInputFn,
      x = e.maskTextFn,
      M = e.hooks,
      T = e.packFn,
      E = e.sampling,
      O = void 0 === E ? {} : E,
      R = e.mousemoveWait,
      N = e.recordCanvas,
      D = void 0 !== N && N,
      F = e.userTriggeredOnInput,
      A = void 0 !== F && F,
      P = e.collectFonts,
      z = void 0 !== P && P,
      j = e.inlineImages,
      G = void 0 !== j && j,
      V = e.plugins,
      H = e.keepIframeSrcFn,
      X =
        void 0 === H
          ? function () {
            return !1;
          }
          : H;
    if (!o) throw new Error("emit function is required");
    void 0 !== R && void 0 === O.mousemove && (O.mousemove = R);
    var Y,
      K,
      J =
        !0 === C
          ? { color: !0, date: !0, "datetime-local": !0, email: !0, month: !0, number: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0, textarea: !0, select: !0, password: !0 }
          : void 0 !== k
          ? k
          : { password: !0 },
      Z =
        !0 === w || "all" === w
          ? {
            script: !0,
            comment: !0,
            headFavicon: !0,
            headWhitespace: !0,
            headMetaSocial: !0,
            headMetaRobots: !0,
            headMetaHttpEquiv: !0,
            headMetaVerification: !0,
            headMetaAuthorship: "all" === w,
            headMetaDescKeywords: "all" === w,
          }
          : w || {};
    void 0 === Y && (Y = window),
    "NodeList" in Y && !Y.NodeList.prototype.forEach && (Y.NodeList.prototype.forEach = Array.prototype.forEach),
    "DOMTokenList" in Y && !Y.DOMTokenList.prototype.forEach && (Y.DOMTokenList.prototype.forEach = Array.prototype.forEach),
    Node.prototype.contains ||
    (Node.prototype.contains = function (e) {
      if (!(0 in arguments)) throw new TypeError("1 argument is required");
      do {
        if (this === e) return !0;
      } while ((e = e && e.parentNode));
      return !1;
    });
    var $ = 0;
    Me = function (e, t) {
      var r;
      if (
        (!(null === (r = te[0]) || void 0 === r ? void 0 : r.isFrozen()) ||
        e.type === g.FullSnapshot ||
        (e.type === g.IncrementalSnapshot && e.data.source === b.Mutation) ||
        te.forEach(function (e) {
          return e.unfreeze();
        }),
          o(
            (function (e) {
              var t, r;
              try {
                for (var o = n(V || []), a = o.next(); !a.done; a = o.next()) {
                  var i = a.value;
                  i.eventProcessor && (e = i.eventProcessor(e));
                }
              } catch (e) {
                t = { error: e };
              } finally {
                try {
                  a && !a.done && (r = o.return) && r.call(o);
                } finally {
                  if (t) throw t.error;
                }
              }
              return T && (e = T(e)), e;
            })(e),
            t
          ),
        e.type === g.FullSnapshot)
      )
        (K = e), ($ = 0);
      else if (e.type === g.IncrementalSnapshot) {
        if (e.data.source === b.Mutation && e.data.isAttachIframe) return;
        $++;
        var s = i && $ >= i,
          u = a && e.timestamp - K.timestamp > a;
        (s || u) && Te(!0);
      }
    };
    var Q = function (e) {
        Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.Mutation }, e) }));
      },
      ee = function (e) {
        return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.Scroll }, e) }));
      },
      ne = function (e) {
        return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.CanvasMutation }, e) }));
      },
      re = new he({ mutationCb: Q }),
      oe = new Ee({ recordCanvas: D, mutationCb: ne, win: window, blockClass: u, mirror: Re }),
      ae = new ve({
        mutationCb: Q,
        scrollCb: ee,
        bypassOptions: {
          blockClass: u,
          blockSelector: c,
          maskTextClass: m,
          maskTextSelector: v,
          inlineStylesheet: S,
          maskInputOptions: J,
          maskTextFn: x,
          maskInputFn: I,
          recordCanvas: D,
          inlineImages: G,
          sampling: O,
          slimDOMOptions: Z,
          iframeManager: re,
          canvasManager: oe,
        },
        mirror: Re,
      });
    Te = function (e) {
      var t, n, o, a;
      void 0 === e && (e = !1),
        Me(Oe({ type: g.Meta, data: { href: window.location.href, width: U(), height: W() } }), e),
        te.forEach(function (e) {
          return e.lock();
        });
      var i = r(
        (function (e, t) {
          var n = t || {},
            r = n.blockClass,
            o = void 0 === r ? "rr-block" : r,
            a = n.blockSelector,
            i = void 0 === a ? null : a,
            s = n.maskTextClass,
            u = void 0 === s ? "rr-mask" : s,
            l = n.maskTextSelector,
            c = void 0 === l ? null : l,
            d = n.inlineStylesheet,
            p = void 0 === d || d,
            f = n.inlineImages,
            m = void 0 !== f && f,
            h = n.recordCanvas,
            v = void 0 !== h && h,
            y = n.maskAllInputs,
            g = void 0 !== y && y,
            b = n.maskTextFn,
            S = n.maskInputFn,
            C = n.slimDOM,
            k = void 0 !== C && C,
            w = n.dataURLOptions,
            I = n.preserveWhiteSpace,
            x = n.onSerialize,
            M = n.onIframeLoad,
            T = n.iframeLoadTimeout,
            E = n.keepIframeSrcFn,
            O = {};
          return [
            _(e, {
              doc: e,
              map: O,
              blockClass: o,
              blockSelector: i,
              maskTextClass: u,
              maskTextSelector: c,
              skipChild: !1,
              inlineStylesheet: p,
              maskInputOptions:
                !0 === g
                  ? { color: !0, date: !0, "datetime-local": !0, email: !0, month: !0, number: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0, textarea: !0, select: !0, password: !0 }
                  : !1 === g
                  ? { password: !0 }
                  : g,
              maskTextFn: b,
              maskInputFn: S,
              slimDOMOptions:
                !0 === k || "all" === k
                  ? {
                    script: !0,
                    comment: !0,
                    headFavicon: !0,
                    headWhitespace: !0,
                    headMetaDescKeywords: "all" === k,
                    headMetaSocial: !0,
                    headMetaRobots: !0,
                    headMetaHttpEquiv: !0,
                    headMetaAuthorship: !0,
                    headMetaVerification: !0,
                  }
                  : !1 === k
                  ? {}
                  : k,
              dataURLOptions: w,
              inlineImages: m,
              recordCanvas: v,
              preserveWhiteSpace: I,
              onSerialize: x,
              onIframeLoad: M,
              iframeLoadTimeout: T,
              keepIframeSrcFn:
                void 0 === E
                  ? function () {
                    return !1;
                  }
                  : E,
            }),
            O,
          ];
        })(document, {
          blockClass: u,
          blockSelector: c,
          maskTextClass: m,
          maskTextSelector: v,
          inlineStylesheet: S,
          maskAllInputs: J,
          maskTextFn: x,
          slimDOM: Z,
          recordCanvas: D,
          inlineImages: G,
          onSerialize: function (e) {
            q(e) && re.addIframe(e), B(e) && ae.addShadowRoot(e.shadowRoot, document);
          },
          onIframeLoad: function (e, t) {
            re.attachIframe(e, t), ae.observeAttachShadow(e);
          },
          keepIframeSrcFn: X,
        }),
        2
        ),
        s = i[0],
        l = i[1];
      if (!s) return console.warn("Failed to snapshot the document");
      (Re.map = l),
        Me(
          Oe({
            type: g.FullSnapshot,
            data: {
              node: s,
              initialOffset: {
                left:
                  void 0 !== window.pageXOffset
                    ? window.pageXOffset
                    : (null === document || void 0 === document ? void 0 : document.documentElement.scrollLeft) ||
                    (null === (n = null === (t = null === document || void 0 === document ? void 0 : document.body) || void 0 === t ? void 0 : t.parentElement) || void 0 === n ? void 0 : n.scrollLeft) ||
                    (null === document || void 0 === document ? void 0 : document.body.scrollLeft) ||
                    0,
                top:
                  void 0 !== window.pageYOffset
                    ? window.pageYOffset
                    : (null === document || void 0 === document ? void 0 : document.documentElement.scrollTop) ||
                    (null === (a = null === (o = null === document || void 0 === document ? void 0 : document.body) || void 0 === o ? void 0 : o.parentElement) || void 0 === a ? void 0 : a.scrollTop) ||
                    (null === document || void 0 === document ? void 0 : document.body.scrollTop) ||
                    0,
              },
            },
          })
        ),
        te.forEach(function (e) {
          return e.unlock();
        });
    };
    try {
      var ie = [];
      ie.push(
        L("DOMContentLoaded", function () {
          Me(Oe({ type: g.DomContentLoaded, data: {} }));
        })
      );
      var se = function (e) {
        var n;
        return me(
          {
            mutationCb: Q,
            mousemoveCb: function (e, t) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: { source: t, positions: e } }));
            },
            mouseInteractionCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.MouseInteraction }, e) }));
            },
            scrollCb: ee,
            viewportResizeCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.ViewportResize }, e) }));
            },
            inputCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.Input }, e) }));
            },
            mediaInteractionCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.MediaInteraction }, e) }));
            },
            styleSheetRuleCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.StyleSheetRule }, e) }));
            },
            styleDeclarationCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.StyleDeclaration }, e) }));
            },
            canvasMutationCb: ne,
            fontCb: function (e) {
              return Me(Oe({ type: g.IncrementalSnapshot, data: t({ source: b.Font }, e) }));
            },
            blockClass: u,
            ignoreClass: p,
            maskTextClass: m,
            maskTextSelector: v,
            maskInputOptions: J,
            inlineStylesheet: S,
            sampling: O,
            recordCanvas: D,
            inlineImages: G,
            userTriggeredOnInput: A,
            collectFonts: z,
            doc: e,
            maskInputFn: I,
            maskTextFn: x,
            blockSelector: c,
            slimDOMOptions: Z,
            mirror: Re,
            iframeManager: re,
            shadowDomManager: ae,
            canvasManager: oe,
            plugins:
              (null ===
              (n =
                null == V
                  ? void 0
                  : V.filter(function (e) {
                    return e.observer;
                  })) || void 0 === n
                ? void 0
                : n.map(function (e) {
                  return {
                    observer: e.observer,
                    options: e.options,
                    callback: function (t) {
                      return Me(Oe({ type: g.Plugin, data: { plugin: e.name, payload: t } }));
                    },
                  };
                })) || [],
          },
          M
        );
      };
      re.addLoadListener(function (e) {
        ie.push(se(e.contentDocument));
      });
      var ue = function () {
        Te(), ie.push(se(document));
      };
      return (
        "interactive" === document.readyState || "complete" === document.readyState
          ? ue()
          : ie.push(
          L(
            "load",
            function () {
              Me(Oe({ type: g.Load, data: {} })), ue();
            },
            window
          )
          ),
          function () {
            ie.forEach(function (e) {
              return e();
            });
          }
      );
    } catch (e) {
      console.warn(e);
    }
  }
  return (
    (Ne.addCustomEvent = function (e, t) {
      if (!Me) throw new Error("please add custom event after start recording");
      Me(Oe({ type: g.Custom, data: { tag: e, payload: t } }));
    }),
      (Ne.freezePage = function () {
        te.forEach(function (e) {
          return e.freeze();
        });
      }),
      (Ne.takeFullSnapshot = function (e) {
        if (!Te) throw new Error("please take full snapshot after start recording");
        Te(e);
      }),
      (Ne.mirror = Re),
      Ne
  );
})();
window.rrweb = { record: rrwebRecord };
//# sourceMappingURL=recorder.js.map
var rrwebConsoleRecord = (function (e) {
  "use strict";
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */ function r(
    e
  ) {
    var r = "function" == typeof Symbol && Symbol.iterator,
      t = r && e[r],
      n = 0;
    if (t) return t.call(e);
    if (e && "number" == typeof e.length)
      return {
        next: function () {
          return e && n >= e.length && (e = void 0), { value: e && e[n++], done: !e };
        },
      };
    throw new TypeError(r ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function t(e, r) {
    var t = "function" == typeof Symbol && e[Symbol.iterator];
    if (!t) return e;
    var n,
      o,
      i = t.call(e),
      a = [];
    try {
      for (; (void 0 === r || r-- > 0) && !(n = i.next()).done; ) a.push(n.value);
    } catch (e) {
      o = { error: e };
    } finally {
      try {
        n && !n.done && (t = i.return) && t.call(i);
      } finally {
        if (o) throw o.error;
      }
    }
    return a;
  }
  function n(e, r, t) {
    if (t || 2 === arguments.length) for (var n, o = 0, i = r.length; o < i; o++) (!n && o in r) || (n || (n = Array.prototype.slice.call(r, 0, o)), (n[o] = r[o]));
    return e.concat(n || Array.prototype.slice.call(r));
  }
  var o, i, a, c, u, l, s;
  !(function (e) {
    (e[(e.DomContentLoaded = 0)] = "DomContentLoaded"),
      (e[(e.Load = 1)] = "Load"),
      (e[(e.FullSnapshot = 2)] = "FullSnapshot"),
      (e[(e.IncrementalSnapshot = 3)] = "IncrementalSnapshot"),
      (e[(e.Meta = 4)] = "Meta"),
      (e[(e.Custom = 5)] = "Custom"),
      (e[(e.Plugin = 6)] = "Plugin");
  })(o || (o = {})),
    (function (e) {
      (e[(e.Mutation = 0)] = "Mutation"),
        (e[(e.MouseMove = 1)] = "MouseMove"),
        (e[(e.MouseInteraction = 2)] = "MouseInteraction"),
        (e[(e.Scroll = 3)] = "Scroll"),
        (e[(e.ViewportResize = 4)] = "ViewportResize"),
        (e[(e.Input = 5)] = "Input"),
        (e[(e.TouchMove = 6)] = "TouchMove"),
        (e[(e.MediaInteraction = 7)] = "MediaInteraction"),
        (e[(e.StyleSheetRule = 8)] = "StyleSheetRule"),
        (e[(e.CanvasMutation = 9)] = "CanvasMutation"),
        (e[(e.Font = 10)] = "Font"),
        (e[(e.Log = 11)] = "Log"),
        (e[(e.Drag = 12)] = "Drag"),
        (e[(e.StyleDeclaration = 13)] = "StyleDeclaration");
    })(i || (i = {})),
    (function (e) {
      (e[(e.MouseUp = 0)] = "MouseUp"),
        (e[(e.MouseDown = 1)] = "MouseDown"),
        (e[(e.Click = 2)] = "Click"),
        (e[(e.ContextMenu = 3)] = "ContextMenu"),
        (e[(e.DblClick = 4)] = "DblClick"),
        (e[(e.Focus = 5)] = "Focus"),
        (e[(e.Blur = 6)] = "Blur"),
        (e[(e.TouchStart = 7)] = "TouchStart"),
        (e[(e.TouchMove_Departed = 8)] = "TouchMove_Departed"),
        (e[(e.TouchEnd = 9)] = "TouchEnd"),
        (e[(e.TouchCancel = 10)] = "TouchCancel");
    })(a || (a = {})),
    (function (e) {
      (e[(e["2D"] = 0)] = "2D"), (e[(e.WebGL = 1)] = "WebGL"), (e[(e.WebGL2 = 2)] = "WebGL2");
    })(c || (c = {})),
    (function (e) {
      (e[(e.Play = 0)] = "Play"), (e[(e.Pause = 1)] = "Pause"), (e[(e.Seeked = 2)] = "Seeked"), (e[(e.VolumeChange = 3)] = "VolumeChange");
    })(u || (u = {})),
    (function (e) {
      (e.Start = "start"),
        (e.Pause = "pause"),
        (e.Resume = "resume"),
        (e.Resize = "resize"),
        (e.Finish = "finish"),
        (e.FullsnapshotRebuilded = "fullsnapshot-rebuilded"),
        (e.LoadStylesheetStart = "load-stylesheet-start"),
        (e.LoadStylesheetEnd = "load-stylesheet-end"),
        (e.SkipStart = "skip-start"),
        (e.SkipEnd = "skip-end"),
        (e.MouseInteraction = "mouse-interaction"),
        (e.EventCast = "event-cast"),
        (e.CustomEvent = "custom-event"),
        (e.Flush = "flush"),
        (e.StateChange = "state-change"),
        (e.PlayBack = "play-back");
    })(l || (l = {})),
    (function (e) {
      (e[(e.Document = 0)] = "Document"), (e[(e.DocumentType = 1)] = "DocumentType"), (e[(e.Element = 2)] = "Element"), (e[(e.Text = 3)] = "Text"), (e[(e.CDATA = 4)] = "CDATA"), (e[(e.Comment = 5)] = "Comment");
    })(s || (s = {}));
  var f = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
    p = {
      map: {},
      getId: function () {
        return console.error(f), -1;
      },
      getNode: function () {
        return console.error(f), null;
      },
      removeNodeFromMap: function () {
        console.error(f);
      },
      has: function () {
        return console.error(f), !1;
      },
      reset: function () {
        console.error(f);
      },
    };
  "undefined" != typeof window &&
  window.Proxy &&
  window.Reflect &&
  (p = new Proxy(p, {
    get: function (e, r, t) {
      return "map" === r && console.error(f), Reflect.get(e, r, t);
    },
  }));
  var h = (function () {
      function e(e) {
        (this.fileName = e.fileName || ""), (this.functionName = e.functionName || ""), (this.lineNumber = e.lineNumber), (this.columnNumber = e.columnNumber);
      }
      return (
        (e.prototype.toString = function () {
          var e = this.lineNumber || "",
            r = this.columnNumber || "";
          return this.functionName ? this.functionName + " (" + this.fileName + ":" + e + ":" + r + ")" : this.fileName + ":" + e + ":" + r;
        }),
          e
      );
    })(),
    d = /(^|@)\S+:\d+/,
    m = /^\s*at .*(\S+:\d+|\(native\))/m,
    v = /^(eval@)?(\[native code])?$/,
    g = {
      parse: function (e) {
        if (!e) return [];
        if (void 0 !== e.stacktrace || void 0 !== e["opera#sourceloc"]) return this.parseOpera(e);
        if (e.stack && e.stack.match(m)) return this.parseV8OrIE(e);
        if (e.stack) return this.parseFFOrSafari(e);
        throw new Error("Cannot parse given Error object");
      },
      extractLocation: function (e) {
        if (-1 === e.indexOf(":")) return [e];
        var r = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g, ""));
        if (!r) throw new Error("Cannot parse given url: ".concat(e));
        return [r[1], r[2] || void 0, r[3] || void 0];
      },
      parseV8OrIE: function (e) {
        return e.stack
          .split("\n")
          .filter(function (e) {
            return !!e.match(m);
          }, this)
          .map(function (e) {
            e.indexOf("(eval ") > -1 && (e = e.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(\),.*$)/g, ""));
            var r = e.replace(/^\s+/, "").replace(/\(eval code/g, "("),
              t = r.match(/ (\((.+):(\d+):(\d+)\)$)/),
              n = (r = t ? r.replace(t[0], "") : r).split(/\s+/).slice(1),
              o = this.extractLocation(t ? t[1] : n.pop()),
              i = n.join(" ") || void 0,
              a = ["eval", "<anonymous>"].indexOf(o[0]) > -1 ? void 0 : o[0];
            return new h({ functionName: i, fileName: a, lineNumber: o[1], columnNumber: o[2] });
          }, this);
      },
      parseFFOrSafari: function (e) {
        return e.stack
          .split("\n")
          .filter(function (e) {
            return !e.match(v);
          }, this)
          .map(function (e) {
            if ((e.indexOf(" > eval") > -1 && (e = e.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), -1 === e.indexOf("@") && -1 === e.indexOf(":"))) return new h({ functionName: e });
            var r = /((.*".+"[^@]*)?[^@]*)(?:@)/,
              t = e.match(r),
              n = t && t[1] ? t[1] : void 0,
              o = this.extractLocation(e.replace(r, ""));
            return new h({ functionName: n, fileName: o[0], lineNumber: o[1], columnNumber: o[2] });
          }, this);
      },
      parseOpera: function (e) {
        return !e.stacktrace || (e.message.indexOf("\n") > -1 && e.message.split("\n").length > e.stacktrace.split("\n").length) ? this.parseOpera9(e) : e.stack ? this.parseOpera11(e) : this.parseOpera10(e);
      },
      parseOpera9: function (e) {
        for (var r = /Line (\d+).*script (?:in )?(\S+)/i, t = e.message.split("\n"), n = [], o = 2, i = t.length; o < i; o += 2) {
          var a = r.exec(t[o]);
          a && n.push(new h({ fileName: a[2], lineNumber: parseFloat(a[1]) }));
        }
        return n;
      },
      parseOpera10: function (e) {
        for (var r = /Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i, t = e.stacktrace.split("\n"), n = [], o = 0, i = t.length; o < i; o += 2) {
          var a = r.exec(t[o]);
          a && n.push(new h({ functionName: a[3] || void 0, fileName: a[2], lineNumber: parseFloat(a[1]) }));
        }
        return n;
      },
      parseOpera11: function (e) {
        return e.stack
          .split("\n")
          .filter(function (e) {
            return !!e.match(d) && !e.match(/^Error created at/);
          }, this)
          .map(function (e) {
            var r = e.split("@"),
              t = this.extractLocation(r.pop()),
              n = (r.shift() || "").replace(/<anonymous function(: (\w+))?>/, "$2").replace(/\([^)]*\)/g, "") || void 0;
            return new h({ functionName: n, fileName: t[0], lineNumber: t[1], columnNumber: t[2] });
          }, this);
      },
    };
  function y(e) {
    if (!e || !e.outerHTML) return "";
    for (var r = ""; e.parentElement; ) {
      var t = e.localName;
      if (!t) break;
      t = t.toLowerCase();
      var n = e.parentElement,
        o = [];
      if (n.children && n.children.length > 0)
        for (var i = 0; i < n.children.length; i++) {
          var a = n.children[i];
          a.localName && a.localName.toLowerCase && a.localName.toLowerCase() === t && o.push(a);
        }
      o.length > 1 && (t += ":eq(" + o.indexOf(e) + ")"), (r = t + (r ? ">" + r : "")), (e = n);
    }
    return r;
  }
  function b(e) {
    return "[object Object]" === Object.prototype.toString.call(e);
  }
  function w(e, t) {
    var n, o;
    if (0 === t) return !0;
    var i = Object.keys(e);
    try {
      for (var a = r(i), c = a.next(); !c.done; c = a.next()) {
        var u = c.value;
        if (b(e[u]) && w(e[u], t - 1)) return !0;
      }
    } catch (e) {
      n = { error: e };
    } finally {
      try {
        c && !c.done && (o = a.return) && o.call(a);
      } finally {
        if (n) throw n.error;
      }
    }
    return !1;
  }
  function N(e, r) {
    var t = { numOfKeysLimit: 50, depthOfLimit: 4 };
    Object.assign(t, r);
    var n = [],
      o = [];
    return JSON.stringify(e, function (e, r) {
      if (n.length > 0) {
        var i = n.indexOf(this);
        ~i ? n.splice(i + 1) : n.push(this), ~i ? o.splice(i, 1 / 0, e) : o.push(e), ~n.indexOf(r) && (r = n[0] === r ? "[Circular ~]" : "[Circular ~." + o.slice(0, n.indexOf(r)).join(".") + "]");
      } else n.push(r);
      if (null == r) return r;
      if (
        (function (e) {
          if (b(e) && Object.keys(e).length > t.numOfKeysLimit) return !0;
          if ("function" == typeof e) return !0;
          if (b(e) && w(e, t.depthOfLimit)) return !0;
          return !1;
        })(r)
      )
        return (function (e) {
          var r = e.toString();
          t.stringLengthLimit && r.length > t.stringLengthLimit && (r = "".concat(r.slice(0, t.stringLengthLimit), "..."));
          return r;
        })(r);
      if (r instanceof Event) {
        var a = {};
        for (var c in r) {
          var u = r[c];
          Array.isArray(u) ? (a[c] = y(u.length ? u[0] : null)) : (a[c] = u);
        }
        return a;
      }
      return r instanceof Node ? (r instanceof HTMLElement ? (r ? r.outerHTML : "") : r.nodeName) : r instanceof Error ? (r.stack ? r.stack + "\nEnd of stack for Error object" : r.name + ": " + r.message) : r;
    });
  }
  var S = {
    level: ["assert", "clear", "count", "countReset", "debug", "dir", "dirxml", "error", "group", "groupCollapsed", "groupEnd", "info", "log", "table", "time", "timeEnd", "timeLog", "trace", "warn"],
    lengthThreshold: 1e3,
    logger: "console",
  };
  function O(e, o, i) {
    var a,
      c,
      u,
      l = i.logger;
    if (!l) return function () {};
    u = "string" == typeof l ? o[l] : l;
    var s = 0,
      f = [];
    if (i.level.includes("error") && window) {
      var p = function (r) {
        var t = r.message,
          n = r.error,
          o = g.parse(n).map(function (e) {
            return e.toString();
          }),
          a = [N(t, i.stringifyOptions)];
        e({ level: "error", trace: o, payload: a });
      };
      window.addEventListener("error", p),
        f.push(function () {
          window && window.removeEventListener("error", p);
        });
    }
    try {
      for (var h = r(i.level), d = h.next(); !d.done; d = h.next()) {
        var m = d.value;
        f.push(v(u, m));
      }
    } catch (e) {
      a = { error: e };
    } finally {
      try {
        d && !d.done && (c = h.return) && c.call(h);
      } finally {
        if (a) throw a.error;
      }
    }
    return function () {
      f.forEach(function (e) {
        return e();
      });
    };
    function v(r, o) {
      var a = this;
      return r[o]
        ? (function (e, r, t) {
          try {
            if (!(r in e)) return function () {};
            var n = e[r],
              o = t(n);
            return (
              "function" == typeof o && ((o.prototype = o.prototype || {}), Object.defineProperties(o, { __rrweb_original__: { enumerable: !1, value: n } })),
                (e[r] = o),
                function () {
                  e[r] = n;
                }
            );
          } catch (e) {
            return function () {};
          }
        })(r, o, function (r) {
          return function () {
            for (var c = [], u = 0; u < arguments.length; u++) c[u] = arguments[u];
            r.apply(a, c);
            try {
              var l = g
                  .parse(new Error())
                  .map(function (e) {
                    return e.toString();
                  })
                  .splice(1),
                f = c.map(function (e) {
                  return N(e, i.stringifyOptions);
                });
              ++s < i.lengthThreshold ? e({ level: o, trace: l, payload: f }) : s === i.lengthThreshold && e({ level: "warn", trace: [], payload: [N("The number of log records reached the threshold.")] });
            } catch (e) {
              r.apply(void 0, n(["rrweb logger error:", e], t(c), !1));
            }
          };
        })
        : function () {};
    }
  }
  var L = "rrweb/console@1";
  return (
    (e.PLUGIN_NAME = L),
      (e.getRecordConsolePlugin = function (e) {
        return { name: L, observer: O, options: e ? Object.assign({}, S, e) : S };
      }),
      Object.defineProperty(e, "__esModule", { value: !0 }),
      e
  );
})({});
//# sourceMappingURL=console-record.min.js.map
