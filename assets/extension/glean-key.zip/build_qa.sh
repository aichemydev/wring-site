#!/usr/bin/env bash

./switch_to_qa.sh
cd ..
zip -r miniext-qa.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-qa.zip wring-site/assets/extension
rm miniext-qa.zip