const GOLDEN_PATH_CLASSNAME = "crx_golden_path"; // Unique ID for the className.
let prevDOM = null; // Previous dom, that we want to track, so we can remove the previous styling.
let qlyIndicatorContainer = document.createElement("DIV"); // The indicator container
// let golden_paths = [];

//#region document events
document.addEventListener("keyup", function (e) {
  // var e = e || window.event; //! for IE to cover IEs window event-object
  if (e.ctrlKey && e.key === "k") {
    hideShowRecorderPanel();
    return false;
  }
});

document.addEventListener(
  "click",
  function (e) {
    // Do what you want with click event
    // console.log("We got a click event: ", e);
    // e.stopPropagation();

    chrome.storage.local.get("funnel", (data) => {
      if (data["funnel"]) {
        // let golden_paths = sessionStorage.getItem("funnels");
        // console.log("golden_paths: ", golden_paths);
        // if (golden_paths) {
        // }
        // else {
        //   golden_paths = JSON.parse(golden_paths);
        // }
        
        console.log("In funnel mode, we can DRAW the funnels now");
        // let funnel_storage = sessionStorage.getItem("funnels");
        // console.log("funnel_storage: ", funnel_storage);
        let golden_paths = JSON5.parse(sessionStorage.getItem("funnels"));
        console.log("golden_paths: ", golden_paths);
        if (!golden_paths) {
          golden_paths = [];
        }
        // if (
        //   golden_paths && !golden_paths.length ||
        //   (golden_paths && golden_paths.length && golden_paths.at(-1) !== e.srcElement)
        // ) {
          if (!e.srcElement.classList.contains("ph-no-capture")) {
            let abs_xpath = createXPathFromElement(e.srcElement);
            console.log("abs_xpath: ", abs_xpath);
            // console.log("Abs Xpath of element is: ", createXPathFromElement(e.srcElement));
            // golden_paths.push(e.srcElement);
            golden_paths.push({"url": window.location.href, "xpath": abs_xpath, "human_label": getComputedLabel(e.srcElement)});
            // golden_paths.push(e.srcElement.outerHTML);
            // golden_paths.push(e.srcElement.outerHTML);
            console.log("golden_paths: ", golden_paths);
            sessionStorage.setItem("funnels", JSON5.stringify(golden_paths));
            e.srcElement.classList.add(GOLDEN_PATH_CLASSNAME);
            e.srcElement.classList.add("qly_funnel_element");
          }
          
        // }

        let funnels = JSON5.parse(sessionStorage.getItem("funnels"));
        console.log("Stored funnels: ", funnels);

        // Draw funnel paths
        if (funnels && funnels.length) {
          //  clear all golden paths first
          clearGoldenPaths();
          let last_element = '';
          
          for (const [i, value] of funnels.entries()) {
            console.log("last_element: ", last_element);
            console.log("value: ", value);
            if (last_element) {
              console.log("Drawing leader line from "+last_element+" to "+value);
              new LeaderLine(getElementByXPath(last_element["xpath"]), getElementByXPath(value["xpath"]), {
                dash: {animation: true},
                opacity: 0.75,
                color: "#ffd700",
                // size = 10 * norm(l["percent"], min_arrow_pct, max_arrow_pct)
              });
            }
            
            last_element = value;
          }
          
        }
        // draw arrow from previous element if it exists
      }
    });
  },
  false
);

//#endregion

// const range = [20, 40];
// const value = 23;
// const normal = norm(value, range[0], range[1]); // Return 0.15

function norm(value, min, max) {
  return (value - min) / (max - min);
}

//#region functions
const dragElt = (dom, domChild) => {
  let pos1 = 0;
  let pos2 = 0;
  let pos3 = 0;
  let pos4 = 0;

  const eltDrag = (e) => {
    e.preventDefault();

    const _domHeight = dom.getBoundingClientRect().height;

    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    dom.style.top = `${dom.offsetTop - pos2}px`;
    dom.style.left = `${dom.offsetLeft - pos1}px`;
  };

  const closeDragElt = () => {
    document.removeEventListener("mousemove", eltDrag);
    document.removeEventListener("mouseup", closeDragElt);
  };

  const dragMouseDown = (e) => {
    e.preventDefault();

    pos3 = e.clientX;
    pos4 = e.clientY;

    document.addEventListener("mouseup", closeDragElt);
    document.addEventListener("mousemove", eltDrag);
  };

  domChild.addEventListener("mousedown", dragMouseDown);
};

function renderIndicator(rec) {
  chrome.storage.local.get("recording", (data) => {
    if (typeof rec === undefined) {
      sessionStorage.setItem("current-rec-value", data["recording"]);
    }
  });

  let recVal = rec ? rec : sessionStorage.getItem("current-rec-value");
  let icon = recVal
    ? chrome.runtime.getURL("/images/qly_pause.svg")
    : chrome.runtime.getURL("/images/qly_record.svg");
  let heatmap_icon = chrome.runtime.getURL("/images/qly_heatmap.svg");
  let funnel_icon = chrome.runtime.getURL("/images/qly_funnel.svg");
  let screenshot_icon = chrome.runtime.getURL("/images/qly_screenshot_icon.svg");

  let _height = recVal ? "82px" : "55px";
  let _header = recVal
    ? `<header class="qly--indicator_head ph-no-capture">
        <div class="qly--ring_container ph-no-capture">
          <div class="qly--ring_elt ph-no-capture"></div>
          <div class="qly--ring_circle ph-no-capture"></div>
        </div>
        <span class="qly--indicator_head_txt ph-no-capture">Recording ...</span>
      </header>`
    : ``;

  qlyIndicatorContainer.innerHTML = `<div id="headless-recorder-overlay" class="qly--indicator_container ph-no-capture" data-v-app="" style="display: none; height: ${_height}">
    <div id="qly-indicator-content" class="qly--indicator_content ph-no-capture">
      <span class="qly--indicator_close ph-no-capture" id="qly-indicator-closer">x</span>
      ${_header}
      <main class="qly--indicator_main ph-no-capture">
        <span id="action_btn" class="qly--indicator_btn ph-no-capture">
          <img alt="Record" class="ph-no-capture" title="Toggle Recording" src="${icon}" />
        </span>
        <span id="heatmap_view" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture">
          <img alt="Heatmap" class="ph-no-capture" title="Heatmap" src="${heatmap_icon}" />
        </span>
        <span id="funnel_view" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture">
        <img alt="Funnel" class="ph-no-capture" title="Funnel" src="${funnel_icon}" />
        </span>
        <span class="qly--indicator_v_divider ph-no-capture"></span>
        <span id="screenshot_btn" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture ">
          <img alt="Screenshot" class="ph-no-capture" title="Screenshot" src="${screenshot_icon}" />
        </span>
        <ul style="display:none" id="qly--funnel_list" class="qly--funnel_list_container">
            <li class="qly--funnel_list_elt"></li>
        </ul>
        
        <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
        
        <div class="qly--indicator_extra ph-no-capture"></div>

      </main>
    </div>
  </div>`;

  if (
    sessionStorage.getItem("qly-indicator-pos-b") &&
    sessionStorage.getItem("qly-indicator-pos-l")
  ) {
    qlyIndicatorContainer.firstChild.style.top =
      sessionStorage.getItem("qly-indicator-pos-b") + "px";
    qlyIndicatorContainer.firstChild.style.left =
      sessionStorage.getItem("qly-indicator-pos-l") + "px";
  }

  //#region indicator handlers
  if (!document.getElementById("headless-recorder-overlay")) {
    document.querySelector("body").appendChild(qlyIndicatorContainer);
    }
    const _indicatorContainer = document.getElementById(
      "headless-recorder-overlay"
    );
    const _indicatorContent = document.getElementById("qly-indicator-content");

    if (_indicatorContainer && _indicatorContent) {
      dragElt(_indicatorContainer, _indicatorContent);
    }
  // }
  if (document.getElementById("qly-indicator-closer")) {
    document
      .getElementById("qly-indicator-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("headless-recorder-overlay");

        if (elt && elt.style.display === "block") {
          clearHeatMap();
          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
          elt.style.display = "none";
        }
      });
  }
  if (document.getElementById("funnel_view")) {
    document
      .getElementById("funnel_view")
      .addEventListener("click", function (e) {
        showFunnel();
      });
  }
  
  if (document.getElementById("heatmap_view")) {
    document
      .getElementById("heatmap_view")
      .addEventListener("click", function (e) {
        showHeatMap();
      });
  }
  if (document.getElementById("action_btn")) {
    document
      .getElementById("action_btn")
      .addEventListener("click", function (e) {
        let elt = document.getElementById("headless-recorder-overlay");
        let _l = elt.getBoundingClientRect().left;
        let _b = elt.getBoundingClientRect().bottom - 70;

        sessionStorage.setItem("qly-indicator-pos-b", _b);
        sessionStorage.setItem("qly-indicator-pos-l", _l);

        chrome.storage.local.get("recording", (data) => {
          chrome.storage.local.set({ recording: !data["recording"] });
          clearGoldenPaths();
          document.querySelector("body").removeChild(qlyIndicatorContainer);
          renderIndicator(!data["recording"]);
        });
      });
  }
  if (document.getElementById("screenshot_btn")) {
    document
      .getElementById("screenshot_btn")
      .addEventListener("click", function (e) {
        screenshot();
      });
  }
  //#endregion

  showRecorderPanel();
  sessionStorage.removeItem("current-rec-value");
}

function clearGoldenPaths(reset= false) {
  let boxes = document.querySelectorAll("." + GOLDEN_PATH_CLASSNAME);
  boxes.forEach((box) => {
    box.classList.remove(GOLDEN_PATH_CLASSNAME);
    box.classList.remove("qly_funnel_element");
  });
  clearHeatMap();
  if (reset) {
    // golden_paths = [];
    sessionStorage.removeItem("funnels");
  }
}

function clearHeatMap() {
  let displayed = false;
  console.log("Calling clearHeatMap");

  let boxes = document.querySelectorAll(".qly_heatmap_element_hover");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element_hover");
  });

  document.querySelectorAll('.qly--elt_circle_bg').forEach(box => {
    box.remove();
  });
  
  boxes = document.querySelectorAll(".qly_heatmap_element");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element");
  });

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  // chrome.storage.local.set({ heatmap: false });
  return displayed;
}

function showFunnel() {
  console.log("In show funnel");
  
  if (document.getElementById("funnel_view").classList.contains("qly--heatmap_button_off")) {
    // Show funnel
    chrome.storage.local.set({ funnel: true });

    document
      .getElementById("funnel_view")
      .classList.remove("qly--heatmap_button_off");
  }
  else {
    // Turn off funnel
    chrome.storage.local.set({ funnel: false });
    document
      .getElementById("funnel_view").classList.add("qly--heatmap_button_off");
    clearGoldenPaths(true);
  }

}

function showHeatMap() {
  console.log("In show heatmap");
  toggleIndicatorLoader();
  let displayed = clearHeatMap();
  if (displayed) {
    toggleIndicatorLoader();
    document
      .getElementById("heatmap_view")
      .classList.add("qly--heatmap_button_off");
    chrome.storage.local.set({ heatmap: false });
    return;
  }

  console.log("Getting heatmap");
//
//   // minimal heatmap instance configuration
//   let heatmapInstance = h337.create({
//     // only container is required, the rest will be defaults
//     container: document.querySelector('.col')
//   });
//
// // now generate some random data
//   var points = [];
//   var max = 0;
//   var width = 840;
//   var height = 400;
//   var len = 200;
//
//   while (len--) {
//     var val = Math.floor(Math.random()*100);
//     max = Math.max(max, val);
//     var point = {
//       x: Math.floor(Math.random()*width),
//       y: Math.floor(Math.random()*height),
//       value: val
//     };
//     points.push(point);
//   }
// // heatmap data format
//   var data = {
//     max: max,
//     data: points
//   };
// // if you have a set of datapoints always use setData instead of addData
// // for data initialization
//   heatmapInstance.setData(data);

  chrome.runtime.sendMessage(
    { message: "command", payload: "heatmap", url: window.location.href },
    function (response) {
      // console.log(response.farewell);
      console.log("Got heatmap response: ", response);
      // console.log("elements: ", response.payload.info.data.elements_covering_heatmap);
      const els = response.payload.response;

      let filtered = [];
      let xpath_index = {};

      // console.log("typeelse: ", typeof(els));
      for (const e of els) {
        // console.log("element: ", e);
        // console.log("e.element.url: ", e.element.url);
        if (e.element.url === window.location.href) {
          filtered.push(e);
        }
      }

      console.log("Filtered elements: ", filtered);

      let flagged_elements = [];
      let summary_stats = {};

      for (const e of filtered) {
        let xpath = e.element.xpath;
        // console.log("xpath: ", xpath);
        if (xpath === "/") {
          // print out summary stats
          console.log("Capturing Summary stats: ", e);
          summary_stats["num_sessions"] = e["num_sessions"];
          summary_stats["num_paths_to_element"] = e["num_paths_to_element"];
          summary_stats["num_unique_paths_to_element"] =
            e["num_unique_paths_to_element"];
          // continue;
          xpath = "/body";
        }
        const _elt = document.evaluate(
          xpath,
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        if (_elt) {
          if (
            !_elt.classList.contains("qly") &&
            !_elt.classList.contains("ph-no-capture")
          ) {
            flagged_elements.push({ elt: _elt, details: e });
            xpath_index[xpath] = _elt;
          }
        }
      }

      console.log("flagged_elements: ", flagged_elements);

      const checkChild = (parent, items) => {
        if (parent.children.length > 0) {
          let ret =
            Array.from(parent.children).filter((t) => items.includes(t))
              .length > 0;

          if (!ret) {
            for (newParent of Array.from(parent.children)) {
              if (checkChild(newParent, items)) {
                return true;
              }
            }
          } else {
            return ret;
          }
        } else {
          return false;
        }
      };

      let all_flagged_elements = flagged_elements.map((val) => val["elt"]);
      let real_flagged_elements = [];

      all_flagged_elements.forEach((fl) => {
        let toDel = checkChild(
          fl,
          all_flagged_elements.filter((e) => e !== fl)
        );

        !toDel && real_flagged_elements.push(fl);
      });

      real_flagged_elements.forEach((elt) => {
        elt.classList.add("qly_heatmap_element_hover");
        // elt.classList.add.add("qly_zoom");
        // elt.classList.add("qly--highlight");

      });

      console.log("real_flagged_elements: ", real_flagged_elements);
      // window.endpoints = [];
      // window.jsplumb_elements = [];
      let arrows = [];
      let anchors = [];

      for (const e of flagged_elements) {
        console.log("element: ", e["elt"]);

        if (e["elt"]) {
          let _elt = e["elt"];

          // ADD here
          _elt.classList.add("qly_heatmap_element");
          // _elt.classList.add("qly--highlight");

          for (const nel of e.details.next_elements) {
            // console.log("nel: ", nel);

            let target_el = xpath_index[nel.xpath];

            if (target_el) {
              console.log("nel_pct: ", nel.percent);
              // let one bezier represent 10 percent
              const beziers = Math.floor(nel.percent / 10);
              // console.log("Beziers: ", beziers);

              // console.log("New line: ", _elt, target_el);
              if (_elt !== target_el) {
                arrows.push({
                  src: _elt,
                  target: target_el,
                  percent: nel.percent,
                });
              }
            }
          }
        }
      }

      let max_arrow_pct = 0;
      let min_arrow_pct = 100;
      for (const l of arrows) {
        if (l["percent"] < min_arrow_pct) {
          min_arrow_pct = l["percent"];
        }

        if (l["percent"] > max_arrow_pct) {
          max_arrow_pct = l["percent"];
        }
      }

      function enter(event, props) {
        let props_element = props.element;
        // props.element.classList.add("qly--highlight");
        for (const a of anchors) {
          
          // Multiple arrows from the same source
          if (a.element === props_element)
          {
            a.showArrows();
            
          }
          else if (a.targetElement === props_element)
          {
            a.showArrows();
          }
          else {
            a.hideArrows();
          }

        }
      }

      function leave(event, props) {
        // props.element.classList.remove("qly--highlight");

        for (const a of anchors) {
          // if (a._id !== props_id)
          // {
          a.showArrows();
          // }
        }
      }

      function init(props) {
        // console.log("init props: ", props);
        anchors.push(props);
      }
      
      for (const l of arrows) {
        const _w = l["target"].clientWidth;
        const _h = l["target"].clientHeight;

        let _dot = document.createElement("span");
        _dot.classList.add("qly--elt_circle_bg");

        l["src"].style.position = "relative";
        // l["src"].classList.add("qly--highlight");
        // l["src"].classList.add("qly_zoom");
        
        let mhAnchor = LeaderLine.mouseHoverAnchor({
            element: l["src"],
            showEffectName: "draw",
          // target Element stored for hover effects
            targetElement: l["target"],
            style: {
            },
            mouseEnterCallBack: enter,
            mouseLeaveCallBack: leave,
            initCallback: init
          });

        let line = new LeaderLine(
          mhAnchor,
          l["target"],
          {
            dash: { animation: true },
            animOptions: {
              duration: 5000,
              timing: "ease-in",
            },
            opacity: 1,
            color: "lightblue",
            size: 2,
            endPlug: "arrow3",
            path: "arc",
          }
        );

        line.size = 7 * norm(l["percent"], 0, max_arrow_pct);
        console.log("line size: ", line.size);
        console.log("line: ", line);
      }

      chrome.storage.local.set({ heatmap: true });
      toggleIndicatorLoader();
      document
        .getElementById("heatmap_view")
        .classList.remove("qly--heatmap_button_off");
    }
  );

}

function hideShowRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    showRecorderPanel();
  } else {
    hideRecorderPanel();
  }
}

function showRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    headlessRecorderOverlay.style.display = "block";
  }
}

function hideRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "block") {
    headlessRecorderOverlay.style.display = "none";
  }
}

function toggleIndicatorLoader() {
  let elt = document.getElementById("qly-indicator-loader");
  elt.style.display = elt.style.display === "none" ? "flex" : "none";
  console.log("elt: ", elt.style.display);
}
async function screenshot() {
  toggleIndicatorLoader();
  // window.scrollTo(0,0);

  html2canvas( document.body, {
    logging: true, 
    letterRendering: 1, 
    allowTaint: true, 
    useCORS: true,
    // scrollX: 0,
    // scrollY: 0,
    // scrollY: -window.scrollY,
    // scrollX: -window.scrollX,
    // scrollY: -window.scrollY,
    // windowWidth: document.body.offsetWidth,
    // windowHeight: document.body.scrollHeight,
  }).then(canvas => {
      let link = document.createElement("a");
      document.body.appendChild(link);
      link.download = "wring_screenshot.png";
      link.href = canvas.toDataURL("image/png");
      link.target = '_blank';
      link.click();
      // document.body.appendChild(img);
  })
  // window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
  
  // html2canvas(document.body, ).then(function(canvas) {
  //   // document.body.appendChild(canvas);
  //   console.log("canvas: ", canvas);
  //
  //   // var link = document.getElementById('link');
  //   // link.setAttribute('download', 'MintyPaper.png');
  //   // link.setAttribute('href', canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"));
  //   // link.click();
  //   let link = document.createElement("a");
  //   document.body.appendChild(link);
  //   link.download = "wring_screenshot.png";
  //   link.href = canvas.toDataURL("image/png");
  //   link.target = '_blank';
  //   link.click();
  //   document.body.appendChild(img);
  //  
  // });
  
  // const node = document.body;
  // let s = new XMLSerializer();

  // await htmlToImage.toPng(node)
  //   .then(function (dataUrl) {
  //     // let img = new Image();
  //     // img.src = dataUrl;
  //     let link = document.createElement("a");
  //     document.body.appendChild(link);
  //     link.download = "wring_screenshot.png";
  //     link.href = dataUrl;
  //     link.target = '_blank';
  //     link.click();
  //     document.body.appendChild(img);
  //   })
  //   .catch(function (error) {
  //     console.error('oops, something went wrong!', error);
  //   });

  // await chrome.runtime.sendMessage(
  //   { message: "command", payload: "screenshot", item: s.serializeToString(node) },
  //   function (response) {
  //     console.log("Got response: ", response);
  //     toggleIndicatorLoader();
  //   });
  
  toggleIndicatorLoader();

}
//#endregion

//#region chrome events
chrome.storage.local.get("activated", (data) => {
  if (data["activated"]) {
    chrome.storage.local.get("recording", (data) => {
      renderIndicator(data["recording"]);
    });
    // showRecorderPanel();
  }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Got request: ", request);
  if (request.message === "command") {
    // toggleRecord();
    console.log("message is command");
    if (request.payload === "activate") {
      chrome.storage.local.get("activated", (data) => {
        if (data["activated"]) {
          console.log("Showing recorder panel");
          // location.reload();
          // console.log("Reloaded page")

          chrome.runtime.sendMessage(
            { message: "command", payload: "activate" },
            function (response) {
              console.log("Got response: ", response);
              showRecorderPanel();
            }
          );
        } else {
          hideRecorderPanel();
        }
        sendResponse({ message: "success" });
      });
    }
  }
  return true;
});
//#endregion
