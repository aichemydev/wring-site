

1. Go to "chrome://extensions"
1. Select developer mode
1. Load extension unpacked
1. Point to this folder (miniext root folder)
1. That should be enough to get the extension started
1. Go to https://demo2.testgold.dev and you can see heatmap working
