cd ..
zip -r miniext.zip miniext -x "*.git*" -x "*.idea*"
cp miniext.zip wring-site/assets/extension
rm miniext.zip
