cd ..
zip -r miniext.zip miniext
cp miniext.zip wring-site/assets/extension
rm miniext.zip
