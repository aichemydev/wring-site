// This file can be imported inside the service worker,
// which means all of its functions and variables will be accessible
// inside the service worker.
// The importation is done in the file `service-worker.js`.

let js_injected = ["./html-to-image.js","./cleanup_markers.js", "./heatmap.js", "./json5.min.js", "./foreground.js", "./heatmap_compute.js", "./leader-line.min.js", "./getElementOuterHtml.js"];
let pageviews_injected = ["./recorder.js", "./pageviews.js", "./array.js"];
console.log("External file is also loaded!");
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    activated: false,
  });
});

function injectScript(tabId) {
  chrome.scripting
    .insertCSS({
      target: {tabId: tabId},
      files: ["./foreground_styles.css"],
    })
    .then(() => {
      console.log("INJECTED THE FOREGROUND STYLES.");
      
      let files_to_inject = js_injected;
      
      fetch('./config.json')
        .then(response => response.json())
        .then(obj => {
          console.log("Inject pageviews: ", obj["PAGEVIEWS"]);
          if (obj["PAGEVIEWS"] === "true") {
            console.log("Injecting pageviews to script");
            files_to_inject = js_injected.concat(pageviews_injected)
          }
          else {
            console.log("Not injecting pageviews");
          }
          chrome.scripting
            .executeScript({
              target: {tabId: tabId},
              // To turn off recording, remove ./pageviews.js
              // files: ["./foreground.js", "./pageviews.js", "./recorder.js", "./array.js"]
              // code: "recording=false",

              // files: ["./cleanup_markers.js", "./foreground.js", "./heatmap_compute.js", "./recorder.js", "./array.js", "./pageviews.js", "./leader-line.min.js"],
              files: files_to_inject
            })
            .then(() => {
              console.log("INJECTED THE FOREGROUND SCRIPT.");
            });
        
        })
      
    })
    .catch((err) => console.log(err));
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  chrome.storage.local.get('activated', data => {
    if (data["activated"]) {
      if (changeInfo.status === "complete" && /^http/.test(tab.url)) {
        injectScript(tabId);
      }
    }
  });
});

chrome.runtime.onMessage.addListener( (request, sender, sendResponse) => {
  console.log("Got request to service-worker: ", request);
  if (request.message === "command") {
    console.log("Command received: ", request.message);
    console.log("Request.payload: ", request.payload);

    if (request.url && request.payload === "heatmap") {
      // call heatmap api
      const headers = {
        authorization:
        // "Bearer eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJhdWQiOiJkZXYud3JpbmcuZGV2IiwiYXV0aF9yb2xlIjoiYXV0aGVudGljYXRlZCIsImVtYWlsIjoic2hhcmVkX2FjY291bnRAd3JpbmcuZGV2IiwiZXhwIjoxNjcxMzk0NzExLCJpYXQiOjE2Njg4MDI3MTEsImlzcyI6ImRldi53cmluZy5kZXYiLCJqdGkiOiIxNWY4MGU4OC05MGU5LTQ0ZTEtYWQyYi0zNWFhNmVkZTk2NzgiLCJuYW1lIjoiU2hhcmVkIHdpdGggSWx5YSIsIm9yZ2FuaXphdGlvbnMiOnt9LCJwcm9kdWN0X3R5cGUiOiJlbnRlcnByaXNlIiwic2NvcGVzIjpbInVpIl0sInN1YiI6IjliZWM4MGU1LTc3MjMtNDJiNC04ZmQ3LWM1ZjU3YmE2MjEzMSIsInRlYW1zIjp7fSwidmVyIjoyfQ.civkiObmqDWdYli43cGVK7l8mHyhY_oRR1KdR28jvKU"
        "Bearer eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJhdWQiOiJkZXYud3JpbmcuZGV2IiwiYXV0aF9yb2xlIjoiYXV0aGVudGljYXRlZCIsImVtYWlsIjoiYWljaGVteWRldmluY0BnbWFpbC5jb20iLCJleHAiOjE2NzIwMzU1NjIsImlhdCI6MTY2OTQ0MzU2MiwiaXNzIjoiZGV2LndyaW5nLmRldiIsImp0aSI6ImRkZGE4YWJlLTZlYTctNDhiNy05Y2Y2LWYyOWY1NjA3YjZhNiIsIm5hbWUiOiJBSWNoZW15Iiwib3JnYW5pemF0aW9ucyI6e30sInByb2R1Y3RfdHlwZSI6ImVudGVycHJpc2UiLCJzY29wZXMiOlsidWkiXSwic3ViIjoiOTY4YWYxN2UtMWNmZC00NDBlLTkyNGUtNzliNWVlYjJhOWZlIiwidGVhbXMiOnt9LCJ2ZXIiOjJ9.5h-Oh0m_emPvJUybnXonDIOHZnZvgWpypYyr4vUKj4E"
      };

      fetch(
        // "https://dev.wring.dev/interceptor/pageviews/paths?project_id=138&url="+          
        "https://dev.wring.dev/interceptor/pageviews/paths?project_id=120&url="+          
        request.url,
        { headers }
      )
        .then(function (response) {
          return response.json();
        })
        .then(function (result) {
          console.log("response_json: ", result);
          sendResponse({
            message: "success",
            command: request.message,
            payload: result,
            url: request.url,
          });
        });
    }

    else if (request.payload === "activate") {

      console.log("Got activate request");
      let queryOptions = { active: true, currentWindow: true };

      let tabs = chrome.tabs.query(queryOptions, function (tabs) {
        // var url = tabs[0].url;
        // console.log("URL from main.js", url);
        injectScript(tabs[0].id);
      });


      // return true;
    }
    
    return true;
  } 
});
