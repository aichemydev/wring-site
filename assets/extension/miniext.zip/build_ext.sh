zip -r miniext.zip *
cp miniext.zip ../wring-site/assets/extension
rm miniext.zip
