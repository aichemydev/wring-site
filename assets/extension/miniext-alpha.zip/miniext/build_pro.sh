#!/usr/bin/env bash

./switch_to_pro.sh
cd ..
zip -r miniext-alpha.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-alpha.zip wring-site/assets/extension
rm miniext-alpha.zip
