chrome.storage.local.get("recording", (data) => {
  if (!data["recording"]) {

    document.querySelectorAll('.qly-line').forEach(box => {
      box.remove();
    });
    
    document.querySelectorAll('.qly--elt_circle_bg').forEach(box => {
      box.remove();
    });

    document.querySelectorAll('.qly_heatmap_element_hover').forEach(box => {
      box.classList.remove('qly_heatmap_element_hover');
    });

    document.querySelectorAll('.qly_heatmap_element').forEach(box => {
      box.classList.remove('qly_heatmap_element');
    });
  }

});
