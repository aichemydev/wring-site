cd ..
zip -r miniext-full.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-full.zip wring-site/assets/extension
rm miniext-full.zip
