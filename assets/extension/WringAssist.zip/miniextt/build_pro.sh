#!/usr/bin/env bash

./switch_to_pro.sh
cd ..
zip -r miniext-pro.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-pro.zip wring-site/assets/extension
rm miniext-pro.zip
