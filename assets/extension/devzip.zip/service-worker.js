// This is the service worker script, which executes in its own context
// when the extension is installed or refreshed (or when you access its console).
// It would correspond to the background script in chrome extensions v2.

console.log("This prints to the console of the service worker (background script)")

// importScripts('html-to-image.js')
import './html-to-image.js';
// importScripts('linkedom.js')
// import {JSDOM} from './jsdom.js';
// let dom = new JSDOM(`<!DOCTYPE html><p>Hello world</p>`);
// console.log(dom, dom.window.document.querySelector("p").textContent); // "Hello world"
// Importing and using functionality from external files is also possible.


// importScripts('service-worker-utils.js')
import './service-worker-utils.js';

// console.log("Improted scripts");

// let dom = new JSDOM(`<!DOCTYPE html><p>Hello world</p>`);
// console.log(dom, dom.window.document.querySelector("p").textContent); // "Hello world"



