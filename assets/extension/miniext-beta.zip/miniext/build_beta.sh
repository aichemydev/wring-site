#!/usr/bin/env bash

./switch_to_pro.sh
cd ..
zip -r miniext-beta.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-beta.zip wring-site/assets/extension
