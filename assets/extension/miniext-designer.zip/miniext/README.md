

1. Go to "chrome://extensions"
1. Select developer mode
1. Load extension unpacked
1. Point to this folder (miniext root folder)
1. That should be enough to get the extension started
1. Go to https://demo2.testgold.dev and you can see heatmap working

To build it:

1. Git clone wring-site to the same level as miniext on your local machine.
1. ./build_designer.sh to build the designer version with only screenshots
1. ./build_pro.sh to build the pro version, all features enabled.
1. The build scripts build and automatically copy to the wring-site folder if its in the same hierarchy as the miniext folder.
1. You can then commit on the wring-site repo as well.


To switch local version:
1. ./switch_to_pro.sh to switch to the pro version locally.
1. ./switch_to_designer.sh to switch to the designer version locally.
