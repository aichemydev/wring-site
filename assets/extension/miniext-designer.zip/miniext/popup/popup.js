const isLogged = () => sessionStorage.getItem("qly-user") !== null;
const render = () => {
  const _parent = document.getElementById("qly-app");
  // Commented this out until Biya is ready with the login
  // const _logged = isLogged();
  const _logged = true;
  const _error = sessionStorage.getItem("qly-login-error")
    ? `<div class="qly--alert_danger">
      An error has occurred while login, please check credentials
      or network!
    </div>`
    : ``;

  _logged && sessionStorage.removeItem("qly-user");
  _error.length > 3 && sessionStorage.removeItem("qly-login-error");
  _parent.innerHTML = !_logged
    ? `<form id="login-form" class="qly--app_login">
      <p class="qly-para">Sign in with</p>
      <div class="qly--other_auth">
        <div class="ico--btn secondary">
          <span class="ico-btn">
            <i class="lab la-github"></i>
          </span>
          <span class="text-btn">Github</span>
        </div>
        <div class="ico--btn danger">
          <span class="ico-btn">
            <i class="lab la-google"></i>
          </span>
          <span class="text-btn">Google</span>
        </div>
      </div>
      <div class="qly--ipt_container">
        <p class="qly-para">Or sign in with credentials</p>
        ${_error}
        <div class="qly--ipt_group">
          <span class="ipt--append">
            <i class="las la-envelope"></i>
          </span>
          <input type="email" placeholder="Enter Email" required />
        </div>
        <div class="qly--ipt_group">
          <span class="ipt--append">
            <i class="las la-lock"></i>
          </span>
          <input type="password" placeholder="Enter Password" required />
        </div>
        <div class="qly--ipt_group_remember f--center">
          <input title="remember-check" type="checkbox" />
          <span>Remember me ?</span>
        </div>
  
        <button type="submit" class="ico--btn info">
          <span class="ico-btn">
            <i class="las la-sign-in-alt"></i>
          </span>
          <span class="text-btn">Sign In</span>
        </button>
      </div>
    </form>
    <div class="create-forgot">
      <div class="after--link">
        Forgot password?
      </div>
      <div class="after--link">
        <a target="_blank" rel="noreferrer" href="#">
          Create new account »
        </a>
      </div>
    </div>`
    : `<header class="qly--header">
      <h2>PM Assist</h2>
      <h4 class="qly--small_txt">Powerful product assistant</h4>
    </header>
    <main class="qly--main">
      <input class="qly--elt_btn" alt="start" type="image" id="start" width="25%" src="/logo/logo-16.png"></input>
      
<!--      chrome.runtime.getURL("/logo/logo-16.png");-->
    </main>`;
};

render(); // render the popup content

if (document.getElementById("start")) {
  
  document.getElementById("start").addEventListener("load", async () => {
  // chrome.webNavigation.onCompleted.addListener(async () => {
    let queryOptions = { active: true, currentWindow: true };

    let tabs =  await chrome.tabs.query(queryOptions);
    chrome.storage.local.set({ activated: true });

    chrome.runtime.sendMessage(
      { message: "command", payload: "activate" },
      function (response) {
        console.log("Got response: ", response);
      }
    );
  });
}

if (document.getElementById("login-form")) {
  const form = document.getElementById("login-form");
  console.log("form: ", form);
}
