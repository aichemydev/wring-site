const GOLDEN_PATH_CLASSNAME = "crx_golden_path"; // Unique ID for the className.
let prevDOM = null; // Previous dom, that we want to track, so we can remove the previous styling.
let qlyIndicatorContainer = document.createElement("DIV"); // The indicator container
// let golden_paths = [];
console.log("PRODUCT VERSION: ", window.wring_version);

// console.log("Jquery: " , $().jquery);

//#region document events
document.addEventListener("keyup", function (e) {
  // var e = e || window.event; //! for IE to cover IEs window event-object
  if (e.ctrlKey && e.key === "k") {
    hideShowRecorderPanel();
    return false;
  }
});

document.addEventListener(
  "click",
  function (e) {
    // Do what you want with click event
    // console.log("We got a click event: ", e);
    // e.stopPropagation();

    chrome.storage.local.get("funnel", (data) => {
      if (data["funnel"]) {
        // let golden_paths = sessionStorage.getItem("funnels");
        // console.log("golden_paths: ", golden_paths);
        // if (golden_paths) {
        // }
        // else {
        //   golden_paths = JSON.parse(golden_paths);
        // }

        console.log("In funnel mode, we can DRAW the funnels now");
        // let funnel_storage = sessionStorage.getItem("funnels");
        // console.log("funnel_storage: ", funnel_storage);
        let golden_paths = JSON5.parse(sessionStorage.getItem("funnels"));
        console.log("golden_paths: ", golden_paths);
        if (!golden_paths) {
          golden_paths = [];
        }
        // if (
        //   golden_paths && !golden_paths.length ||
        //   (golden_paths && golden_paths.length && golden_paths.at(-1) !== e.srcElement)
        // ) {
        if (!e.srcElement.classList.contains("ph-no-capture")) {
          let abs_xpath = xpath(e.srcElement);
          let outer_html = e.srcElement.outerHTML;
          // console.log("abs_xpath: ", abs_xpath);
          // console.log("outer_html: ", outer_html);
          // console.log("Abs Xpath of element is: ", createXPathFromElement(e.srcElement));
          // golden_paths.push(e.srcElement);
          golden_paths.push({
            url: window.location.href,
            // xpath: abs_xpath,
            abs_xpath: abs_xpath,
            // human_label: getDeepComputedLabel(e.srcElement),
            human_label: getComputedLabel(e.srcElement),
            // outer_html: outer_html
          });
          // golden_paths.push(e.srcElement.outerHTML);
          // golden_paths.push(e.srcElement.outerHTML);
          console.log("golden_paths: ", golden_paths);
          sessionStorage.setItem("funnels", JSON5.stringify(golden_paths));
          // e.srcElement.classList.add(GOLDEN_PATH_CLASSNAME);
          e.srcElement.classList.add("qly_funnel_element");
        }

        // }

        let funnels = JSON5.parse(sessionStorage.getItem("funnels"));
        console.log("Stored funnels: ", funnels);

        // Draw funnel paths
        if (funnels && funnels.length) {
          //  clear all golden paths first
          clearGoldenPaths();
          let last_element = "";

          // Add all items to list
          $("#qly--funnel_list").show();
          $("#qly--funnel_list tbody").empty();
          if (window.dataTable) {
            window.dataTable.clear().draw();
            console.log("Cleared dataTable");
          } else {
            window.dataTable = $("#qly--funnel_list").DataTable({
              columnDefs: [
                {
                  targets: -1,
                  render: function (data, type, row) {
                    return '<i class="fa fa-trash" aria-hidden="true"></i>';
                  },
                },
              ],
              columns: [{ searchable: false }, null, null, null],
              scrollCollapse: true,
              paging: false,
              searching: false,
              ordering: false,
              info: false,
            });
          }

          for (const [i, value] of funnels.entries()) {
            // console.log("last_element: ", last_element);
            // console.log("value: ", value);
            let human_label = value["human_label"] || "";
            window.dataTable.row
              .add([i + 1, "Click", human_label.slice(0, 10)])
              .draw(false);

            if (last_element) {
              console.log(
                "Drawing leader line from " + last_element["abs_xpath"]
              );
              console.log("To: ", value["abs_xpath"]);
              // console.log("Source element: ", getElementByOuterHTML(last_element["outer_html"]));
              // console.log("Target element: ", getElementByOuterHTML(value["outer_html"]));
              new LeaderLine(
                getElementByXPath(last_element["abs_xpath"]),
                getElementByXPath(value["abs_xpath"]),
                {
                  dash: { animation: true },
                  opacity: 0.75,
                  color: "#ffd700",
                  // size = 10 * norm(l["percent"], min_arrow_pct, max_arrow_pct)
                }
              );
            }

            last_element = value;
          }
        } else {
          $("#qly--funnel_list").hide();
        }
        // draw arrow from previous element if it exists
      }
    });
  },
  false
);
//#endregion

//#region functions
function norm(value, min, max) {
  return (value - min) / (max - min);
}

const dragElt = (dom, domChild) => {
  let pos1 = 0;
  let pos2 = 0;
  let pos3 = 0;
  let pos4 = 0;

  const eltDrag = (e) => {
    e.preventDefault();

    const _domHeight = dom.getBoundingClientRect().height;

    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    dom.style.top = `${dom.offsetTop - pos2}px`;
    dom.style.left = `${dom.offsetLeft - pos1}px`;
  };

  const closeDragElt = () => {
    document.removeEventListener("mousemove", eltDrag);
    document.removeEventListener("mouseup", closeDragElt);
  };

  const dragMouseDown = (e) => {
    e.preventDefault();

    pos3 = e.clientX;
    pos4 = e.clientY;

    document.addEventListener("mouseup", closeDragElt);
    document.addEventListener("mousemove", eltDrag);
  };

  domChild.addEventListener("mousedown", dragMouseDown);
};

function renderIndicator(rec) {
  chrome.storage.local.get("recording", (data) => {
    if (typeof rec === undefined) {
      sessionStorage.setItem("current-rec-value", data["recording"]);
    }
  });

  let recVal = rec ? rec : sessionStorage.getItem("current-rec-value");
  let icon = recVal
    ? chrome.runtime.getURL("/images/qly_pause.svg")
    : chrome.runtime.getURL("/images/qly_record.svg");
  let wring_logo = chrome.runtime.getURL("/logo/logo-16.png");
  let heatmap_icon = chrome.runtime.getURL("/images/qly_heatmap.svg");
  let funnel_icon = chrome.runtime.getURL("/images/qly_funnel.svg");
  let screenshot_icon = chrome.runtime.getURL(
    "/images/qly_screenshot_icon.svg"
  );

  let _extraClass =
    window.wring_version === "designer" ? "qly--need_upgrade" : "";
  let _height = recVal ? "82px" : "55px";
  let _header = recVal
    ? `<header class="qly--indicator_head ph-no-capture">
        <div class="qly--ring_container ph-no-capture">
          <div class="qly--ring_elt ph-no-capture"></div>
          <div class="qly--ring_circle ph-no-capture"></div>
        </div>
        <span class="qly--indicator_head_txt ph-no-capture">Recording ...</span>
      </header>`
    : ``;

  qlyIndicatorContainer.innerHTML = `<div id="headless-recorder-overlay" class="qly--indicator_container ph-no-capture" data-v-app="" style="display: none; height: ${_height}">
    <div id="qly-indicator-content" class="qly--indicator_content ph-no-capture">
      <span class="qly--indicator_close ph-no-capture" id="qly-indicator-closer">x</span>
      ${_header}
      <main class="qly--indicator_main ph-no-capture">
        <span id="action_btn" class="qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Record" class="ph-no-capture" title="Observe" src="${icon}" />
        </span>
        <span id="heatmap_view"  class="qly--heatmap_button_off qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Heatmap"  class="ph-no-capture" title="Session map" src="${heatmap_icon}" />
        </span>
        <span id="funnel_view" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Funnel" class="ph-no-capture" title="Funnels" src="${funnel_icon}" />
        </span>
        <span class="qly--indicator_v_divider ph-no-capture"></span>
        <span id="screenshot_btn" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture">
          <img alt="Screenshot" class="ph-no-capture" title="Screenshot" src="${screenshot_icon}" />
        </span>
        
        <table style="display:none" id="qly--funnel_list" class="qly--funnel_list_container display ph-no-capture">
          <thead>
            <tr>
              <th></th>
              <th>Action</th>
              <th>Element</th>
              <th></th>
            </tr>
          </thead>
        </table>
        <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
        <div class="qly--indicator_extra ph-no-capture"></div>
        <a href="https://wring.dev"> <img alt="Logo" class="ph-no-capture" title="Wring" src="${wring_logo}" width="32" /></a>
      </main>
    </div>
  </div>`;

  if (
    sessionStorage.getItem("qly-indicator-pos-b") &&
    sessionStorage.getItem("qly-indicator-pos-l")
  ) {
    qlyIndicatorContainer.firstChild.style.top =
      sessionStorage.getItem("qly-indicator-pos-b") + "px";
    qlyIndicatorContainer.firstChild.style.left =
      sessionStorage.getItem("qly-indicator-pos-l") + "px";
  }

  //#region indicator handlers
  if (!document.getElementById("headless-recorder-overlay")) {
    document.querySelector("body").appendChild(qlyIndicatorContainer);
  }

  if (document.getElementById("headless-recorder-overlay")) {
    const _indicatorContainer = document.getElementById(
      "headless-recorder-overlay"
    );

    if (document.getElementById("qly-indicator-content")) {
      const _indicatorContent = document.getElementById(
        "qly-indicator-content"
      );
      if (_indicatorContainer && _indicatorContent) {
        dragElt(_indicatorContainer, _indicatorContent);
      }
    }
  }

  if (document.getElementById("qly-indicator-closer")) {
    document
      .getElementById("qly-indicator-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("headless-recorder-overlay");

        if (elt && elt.style.display === "block") {
          clearHeatMap();
          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
          elt.style.display = "none";
        }
      });
  }
  if (document.getElementById("funnel_view")) {
    document
      .getElementById("funnel_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showFunnel();
      });
  }

  if (document.getElementById("heatmap_view")) {
    document
      .getElementById("heatmap_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showHeatMap();
      });
  }

  if (document.getElementById("action_btn")) {
    document
      .getElementById("action_btn")
      .addEventListener("click", function (e) {
        let elt = document.getElementById("headless-recorder-overlay");
        let _l = elt.getBoundingClientRect().left;
        let _b = elt.getBoundingClientRect().bottom - 70;

        sessionStorage.setItem("qly-indicator-pos-b", _b);
        sessionStorage.setItem("qly-indicator-pos-l", _l);

        if (window.wring_version === "pro") {
          chrome.storage.local.get("recording", (data) => {
            chrome.storage.local.set({ recording: !data["recording"] });
            clearGoldenPaths();
            document.querySelector("body").removeChild(qlyIndicatorContainer);
            renderIndicator(!data["recording"]);
          });
        }
      });
  }
  if (document.getElementById("screenshot_btn")) {
    document
      .getElementById("screenshot_btn")
      .addEventListener("click", function (e) {
        fullPageScreenshot();
      });
  }
  //#endregion

  showRecorderPanel();
  sessionStorage.removeItem("current-rec-value");
}

function clearGoldenPaths(reset = false) {
  let boxes = document.querySelectorAll("." + GOLDEN_PATH_CLASSNAME);
  boxes.forEach((box) => {
    box.classList.remove(GOLDEN_PATH_CLASSNAME);
  });

  $("#qly--funnel_list").hide();

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  clearHeatMap();
  if (reset) {
    // golden_paths = [];
    sessionStorage.removeItem("funnels");
    boxes = document.querySelectorAll(".qly_funnel_element");
    boxes.forEach((box) => {
      box.classList.remove("qly_funnel_element");
    });
  }
}

function clearHeatMap() {
  let displayed = false;
  console.log("Calling clearHeatMap");

  let boxes = document.querySelectorAll(".qly_heatmap_element_hover");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element_hover");
  });

  document.querySelectorAll(".qly--elt_circle_bg").forEach((box) => {
    box.remove();
  });

  boxes = document.querySelectorAll(".qly_heatmap_element");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element");
  });

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  // chrome.storage.local.set({ heatmap: false });
  return displayed;
}

function showFunnel() {
  console.log("In show funnel");

  if (
    document
      .getElementById("funnel_view")
      .classList.contains("qly--heatmap_button_off")
  ) {
    // Show funnel
    chrome.storage.local.set({ funnel: true });

    document
      .getElementById("funnel_view")
      .classList.remove("qly--heatmap_button_off");
  } else {
    // Turn off funnel
    chrome.storage.local.set({ funnel: false });
    document
      .getElementById("funnel_view")
      .classList.add("qly--heatmap_button_off");
    clearGoldenPaths(true);
  }
}

function showHeatMap() {
  console.log("In show heatmap");
  toggleIndicatorLoader();
  let displayed = clearHeatMap();
  if (displayed) {
    toggleIndicatorLoader();
    document
      .getElementById("heatmap_view")
      .classList.add("qly--heatmap_button_off");
    chrome.storage.local.set({ heatmap: false });
    return;
  }

  console.log("Getting heatmap");
  //
  //   // minimal heatmap instance configuration
  //   let heatmapInstance = h337.create({
  //     // only container is required, the rest will be defaults
  //     container: document.querySelector('.col')
  //   });
  //
  // // now generate some random data
  //   var points = [];
  //   var max = 0;
  //   var width = 840;
  //   var height = 400;
  //   var len = 200;
  //
  //   while (len--) {
  //     var val = Math.floor(Math.random()*100);
  //     max = Math.max(max, val);
  //     var point = {
  //       x: Math.floor(Math.random()*width),
  //       y: Math.floor(Math.random()*height),
  //       value: val
  //     };
  //     points.push(point);
  //   }
  // // heatmap data format
  //   var data = {
  //     max: max,
  //     data: points
  //   };
  // // if you have a set of datapoints always use setData instead of addData
  // // for data initialization
  //   heatmapInstance.setData(data);

  chrome.runtime.sendMessage(
    { message: "command", payload: "heatmap", url: window.location.href },
    function (response) {
      // console.log(response.farewell);
      console.log("Got heatmap response: ", response);
      // console.log("elements: ", response.payload.info.data.elements_covering_heatmap);
      const els = response.payload.response;

      let filtered = [];
      let xpath_index = {};

      // console.log("typeelse: ", typeof(els));
      for (const e of els) {
        // console.log("element: ", e);
        // console.log("e.element.url: ", e.element.url);
        if (e.element.url === window.location.href) {
          filtered.push(e);
        }
      }

      console.log("Filtered elements: ", filtered);

      let flagged_elements = [];
      let summary_stats = {};

      for (const e of filtered) {
        let xpath = e.element.xpath;
        // console.log("xpath: ", xpath);
        if (xpath === "/") {
          // print out summary stats
          console.log("Capturing Summary stats: ", e);
          summary_stats["num_sessions"] = e["num_sessions"];
          summary_stats["num_paths_to_element"] = e["num_paths_to_element"];
          summary_stats["num_unique_paths_to_element"] =
            e["num_unique_paths_to_element"];
          // continue;
          xpath = "/body";
        }
        const _elt = document.evaluate(
          xpath,
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        if (_elt) {
          if (
            !_elt.classList.contains("qly") &&
            !_elt.classList.contains("ph-no-capture")
          ) {
            flagged_elements.push({ elt: _elt, details: e });
            xpath_index[xpath] = _elt;
          }
        }
      }

      console.log("flagged_elements: ", flagged_elements);

      const checkChild = (parent, items) => {
        if (parent.children.length > 0) {
          let ret =
            Array.from(parent.children).filter((t) => items.includes(t))
              .length > 0;

          if (!ret) {
            for (newParent of Array.from(parent.children)) {
              if (checkChild(newParent, items)) {
                return true;
              }
            }
          } else {
            return ret;
          }
        } else {
          return false;
        }
      };

      let all_flagged_elements = flagged_elements.map((val) => val["elt"]);
      let real_flagged_elements = [];

      all_flagged_elements.forEach((fl) => {
        let toDel = checkChild(
          fl,
          all_flagged_elements.filter((e) => e !== fl)
        );

        !toDel && real_flagged_elements.push(fl);
      });

      real_flagged_elements.forEach((elt) => {
        elt.classList.add("qly_heatmap_element_hover");
        // elt.classList.add.add("qly_zoom");
        // elt.classList.add("qly--highlight");
      });

      console.log("real_flagged_elements: ", real_flagged_elements);
      // window.endpoints = [];
      // window.jsplumb_elements = [];
      let arrows = [];
      let anchors = [];

      for (const e of flagged_elements) {
        console.log("element: ", e["elt"]);

        if (e["elt"]) {
          let _elt = e["elt"];

          // ADD here
          _elt.classList.add("qly_heatmap_element");
          // _elt.classList.add("qly--highlight");

          for (const nel of e.details.next_elements) {
            // console.log("nel: ", nel);

            let target_el = xpath_index[nel.xpath];

            if (target_el) {
              console.log("nel_pct: ", nel.percent);
              // let one bezier represent 10 percent
              const beziers = Math.floor(nel.percent / 10);
              // console.log("Beziers: ", beziers);

              // console.log("New line: ", _elt, target_el);
              if (_elt !== target_el) {
                arrows.push({
                  src: _elt,
                  target: target_el,
                  percent: nel.percent,
                });
              }
            }
          }
        }
      }

      let max_arrow_pct = 0;
      let min_arrow_pct = 100;
      for (const l of arrows) {
        if (l["percent"] < min_arrow_pct) {
          min_arrow_pct = l["percent"];
        }

        if (l["percent"] > max_arrow_pct) {
          max_arrow_pct = l["percent"];
        }
      }

      function enter(event, props) {
        let props_element = props.element;
        // props.element.classList.add("qly--highlight");
        for (const a of anchors) {
          // Multiple arrows from the same source
          if (a.element === props_element) {
            a.showArrows();
          } else if (a.targetElement === props_element) {
            a.showArrows();
          } else {
            a.hideArrows();
          }
        }
      }

      function leave(event, props) {
        // props.element.classList.remove("qly--highlight");

        for (const a of anchors) {
          // if (a._id !== props_id)
          // {
          a.showArrows();
          // }
        }
      }

      function init(props) {
        // console.log("init props: ", props);
        anchors.push(props);
      }

      for (const l of arrows) {
        const _w = l["target"].clientWidth;
        const _h = l["target"].clientHeight;

        let _dot = document.createElement("span");
        _dot.classList.add("qly--elt_circle_bg");

        l["src"].style.position = "relative";
        // l["src"].classList.add("qly--highlight");
        // l["src"].classList.add("qly_zoom");

        let mhAnchor = LeaderLine.mouseHoverAnchor({
          element: l["src"],
          showEffectName: "draw",
          // target Element stored for hover effects
          targetElement: l["target"],
          style: {},
          mouseEnterCallBack: enter,
          mouseLeaveCallBack: leave,
          initCallback: init,
        });

        let line = new LeaderLine(mhAnchor, l["target"], {
          dash: { animation: true },
          animOptions: {
            duration: 5000,
            timing: "ease-in",
          },
          opacity: 1,
          color: "lightblue",
          size: 2,
          endPlug: "arrow3",
          path: "arc",
        });

        line.size = 7 * norm(l["percent"], 0, max_arrow_pct);
        console.log("line size: ", line.size);
        console.log("line: ", line);
      }

      chrome.storage.local.set({ heatmap: true });
      toggleIndicatorLoader();
      document
        .getElementById("heatmap_view")
        .classList.remove("qly--heatmap_button_off");
    }
  );
}

function hideShowRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    showRecorderPanel();
  } else {
    hideRecorderPanel();
  }
}

function showRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    headlessRecorderOverlay.style.display = "block";
  }
}

function hideRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "block") {
    headlessRecorderOverlay.style.display = "none";
  }
}

function toggleIndicatorLoader() {
  let elt = document.getElementById("qly-indicator-loader");
  elt.style.display = elt.style.display === "none" ? "flex" : "none";
  console.log("elt: ", elt.style.display);
}
async function screenshot() {
  toggleIndicatorLoader();
  window.scrollTo(0, 0);
  let canvas = await html2canvas(document.body, {
    logging: true,
    letterRendering: 1,
    allowTaint: true,
    useCORS: true,
    height: document.body.getBoundingClientRect().height,
    width: document.body.getBoundingClientRect().width,
    // scrollX: 0,
    // scrollY: 0,
    // scrollY: -window.scrollY,
    // scrollX: -window.scrollX,
    // scrollY: -window.scrollY,
    // windowWidth: document.body.offsetWidth,
    // windowHeight: document.body.scrollHeight,
  });

  function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeString });
    return blob;
  }

  try {
    const handle = await showSaveFilePicker({
      suggestedName: window.location.hostname + ".png",
      types: [
        {
          description: "Screenshot",
          accept: { "image/png": [".png"] },
        },
      ],
    });

    const writableStream = await handle.createWritable();
    await writableStream.write(dataURItoBlob(canvas.toDataURL("image/png")));
    await writableStream.close();
  } catch (err) {
    console.error(err.name, err.message);
  } finally {
    toggleIndicatorLoader();
  }

  // const blob = new Blob(['Some text']);

  // canvas.toBlob(function(blob){
  //   let link = document.createElement("a");
  //   link.href = URL.createObjectURL(blob);
  //   console.log(blob);
  //   console.log(link.href); // this line should be here
  // },'image/png');

  // window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
}
//#endregion

//
// full page screenshot
//
/**
 * Function to call setTimeout with await.
 *
 * @param ms milliseconds to wait
 * @returns {Promise<unknown>}
 */
async function awaitableTimeout(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * This is required to make items with CSS fixed/sticky positions not repeat on the screenshot.
 */
function unStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "fixed"
  );
  stickyElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "sticky"
  );
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "absolute"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "relative"));
}

/**
 * This restores any elems that were unattached by unStickElems()
 */
function reStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "fixed"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "sticky"));
}

/**
 * Function to execute a full page screenshot
 * @returns {Promise<void>}
 */
async function fullPageScreenshot() {
  // indicate we're processing
  toggleIndicatorLoader();

  // this stores refs to elements that will be detached for screenshot purposes
  let fixedElements = [];
  let stickyElements = [];

  // save the images in this array
  let screenshotArray = [];
  const imageFilename = window.location.hostname + "-screenshot.png";

  const startingScrollY = window.scrollY;

  // scroll to the top
  window.scroll(0, 0);

  // get the full height of the page
  const pageHeight = Math.max(
    document.body.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.clientHeight,
    document.documentElement.scrollHeight,
    document.documentElement.offsetHeight
  );
  const viewportHeight =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight;

  // not using window.innerWidth because we want to ignore scrollbars
  const viewportWidth =
    document.documentElement.clientWidth || document.body.clientWidth;

  // scroll down by 1 x viewport height each time
  let scrollMaxCount = Math.ceil(pageHeight / viewportHeight);
  console.log(
    `Full page screenshot will scroll the page ${scrollMaxCount} times.`
  );
  // if (scrollMaxCount > 60) {
  //   alert(
  //     "Sorry, this page is too long to be captured in a full page screenshot."
  //   );
  //   window.scroll(0, startingScrollY);
  //   return;
  // }

  try {
    // save current position
    let currentScrollValue = window.scrollY || 0;
    let currentScrollCount = 0;

    // hide the recorder div
    hideShowRecorderPanel();

    // detach fixed-pos and sticky-pos elements
    unStickyElems(fixedElements, stickyElements);

    while (currentScrollCount <= scrollMaxCount) {
      let response = await chrome.runtime.sendMessage({
        message: "command",
        payload: "fullPageScreenshot",
        url: window.location.href,
      });

      console.log("Got response from background script with image.");
      // save the image to the array
      screenshotArray.push([
        response.image,
        currentScrollCount,
        currentScrollValue,
      ]);
      console.log(
        `saved image at scrollY value: ${currentScrollValue}, ` +
          `pageHeight: ${pageHeight}, viewPortHeight: ${viewportHeight}, ` +
          `currentScrollCount: ${currentScrollCount}, ` +
          `scrollMaxCount: ${scrollMaxCount}`
      );

      // scroll down by one viewport height each time
      window.scroll(0, currentScrollCount * viewportHeight);
      currentScrollCount += 1;
      currentScrollValue = window.scrollY;
      // wait 250 msec because:
      // https://developer.chrome.com/docs/extensions/reference/tabs/#property-MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND
      await awaitableTimeout(550);
    }

    //
    // done with the loop, we now need to put together the screenshot array into a single image
    //

    // if it's a single image, can stop here
    if (screenshotArray.length === 1) {
      const downloadLink = document.createElement("a");
      downloadLink.download = imageFilename;
      downloadLink.rel = "noreferrer noopener";
      // the "data:image/png;base64," bit is already present so no need to add it
      downloadLink.href = screenshotArray[0][0];
      downloadLink.click();
      downloadLink.remove();
      return;
    }

    // otherwise, we have to go through the array, convert each data URI to an image, then paste it into a canvas
    // at its corresponding scrollY
    const cnv = document.createElement("canvas");
    const devicePixelRatio = window.devicePixelRatio;
    cnv.width = viewportWidth * devicePixelRatio;
    cnv.height = pageHeight * devicePixelRatio;

    for (let item of screenshotArray) {
      const [thisImage, thisScrollCount, thisScrollValue] = item;
      let imageObj = new Image();
      imageObj.onload = function () {
        cnv
          .getContext("2d")
          .drawImage(
            imageObj,
            0,
            0,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio,
            0,
            thisScrollValue * devicePixelRatio,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio
          );
      };
      imageObj.src = thisImage;
    }

    // wait for all images to be loaded
    console.log("Waiting for all images to be loaded...");
    await awaitableTimeout(500);

    // save the final image
    const finalImageDataURI = cnv.toDataURL("image/png");
    const downloadLink = document.createElement("a");
    downloadLink.download = imageFilename;
    downloadLink.rel = "noreferrer noopener";
    // the "data:image/png;base64," bit is already present so no need to add it
    downloadLink.href = finalImageDataURI;
    downloadLink.click();
    downloadLink.remove();
  } finally {
    // remove the spinner
    toggleIndicatorLoader();
    // bring the user back to their start Y position
    window.scroll(0, startingScrollY);

    // reattach fixed-pos and sticky-pos elements
    reStickyElems(fixedElements, stickyElements);

    // show the recorder div
    showRecorderPanel();
  }
}
//
// end full page screenshot
//

//#region chrome events
chrome.storage.local.get("activated", (data) => {
  if (data["activated"]) {
    chrome.storage.local.get("recording", (data) => {
      renderIndicator(data["recording"]);
    });
    // showRecorderPanel();
  }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Got request: ", request);
  if (request.message === "command") {
    // toggleRecord();
    console.log("message is command");
    if (request.payload === "activate") {
      chrome.storage.local.get("activated", (data) => {
        if (data["activated"]) {
          console.log("Showing recorder panel");
          // location.reload();
          // console.log("Reloaded page")

          chrome.runtime.sendMessage(
            { message: "command", payload: "activate" },
            function (response) {
              console.log("Got response: ", response);
              showRecorderPanel();
            }
          );
        } else {
          hideRecorderPanel();
        }
        sendResponse({ message: "success" });
      });
    }
  }
  return true;
});
//#endregion
