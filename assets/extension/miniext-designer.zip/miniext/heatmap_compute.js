chrome.storage.local.get("heatmap", (data) => {
  if (data["heatmap"]) {
    showHeatMap();
  }
});