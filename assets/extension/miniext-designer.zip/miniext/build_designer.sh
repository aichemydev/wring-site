cp manifest.designer.json manifest.json
cp config.designer.json config.json
cd ..
zip -r miniext-designer.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-designer.zip wring-site/assets/extension
rm miniext-designer.zip
