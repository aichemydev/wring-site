cp manifest.full.json manifest.json
cp config.pro.json config.json
cd ..
zip -r miniext-pro.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-pro.zip wring-site/assets/extension
rm miniext-pro.zip
