#!/usr/bin/env bash

./switch_to_pro.sh
cd ..
zip -r miniext-key.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-key.zip wring-site/assets/extension
rm miniext-key.zip
