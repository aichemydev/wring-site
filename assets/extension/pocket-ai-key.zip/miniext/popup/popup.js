const isLogged = () => chrome.windows.qlyUserAccessTokenPMAssist !== null;
const render = () => {
  // document.getElementById("qly--container").remove();
  const _parent = document.getElementById("qly-app");
  // Commented this out until Biya is ready with the login
  const _logged = true;
  // const _logged = true;
  const _error = sessionStorage.getItem("qly-login-error")
    ? `<div class="qly--alert_danger">
      An error has occurred while login, please check credentials
      or network!
    </div>`
    : ``;

  _logged && chrome.qlyUserAccessTokenPMAssist;
  _error.length > 3 && sessionStorage.removeItem("qly-login-error");
  _parent.innerHTML = ` <input class="" alt="start" type="image" id="start" width="25" src="/logo/logo-16.png"></input>`;
  // _parent.innerHTML = `
  //   <header class="qly--header">
  //     <h2>PM Assist</h2>
  //     <h4 class="qly--small_txt">Powerful product assistant</h4>
  //   </header>
  //   <main class="qly--main">
  //     <input class="" alt="start" type="image" id="start" width="25%" src="/logo/logo-16.png"></input>
  //    
  // //   </main>`;
};

render(); // render the popup content

if (document.getElementById("start")) {
  
  document.getElementById("start").addEventListener("load", async () => {
  // chrome.webNavigation.onCompleted.addListener(async () => {
    let queryOptions = { active: true, currentWindow: true };

    let tabs =  await chrome.tabs.query(queryOptions);
    chrome.storage.local.set({ activated: true });

    chrome.runtime.sendMessage(
      { message: "command", payload: "activate" },
      function (response) {
        console.log("Got response: ", response);
      }
    );
  });
}

if (document.getElementById("login-form")) {
  const form = document.getElementById("login-form");
  console.log("form: ", form);
}
