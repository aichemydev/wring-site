#!/usr/bin/env bash

cp manifest.qa.json manifest.json
cp config.qa.json config.json