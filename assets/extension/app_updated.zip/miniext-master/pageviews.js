console.log("Injecting pageviews!");

var project_apiKey = sessionStorage.getItem("qly-project-apiKey");
var projectId =  sessionStorage.getItem("qly-project-id");
//
// if (projectId == null) { 
//   // Maybe on page reload, we need to get the project Id again
//  
// }
// let wringr = window.wring



console.log("project_apiKey: ", project_apiKey);
// qly-project-apiKey

function getFromLocalStorage(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(key, (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result[key]);
      }
    });
  });
}


function apiCapture() {
  const wringInterceptor = (function () {
    let v = !1;
    const B = {
      local: "http://walserver.waqasbhatti.org/interceptor/apicalls/v1/phc",
      dev: "https://dev.wring.dev/interceptor/apicalls/v1/phc",
      prod: "https://app.wring.dev/interceptor/apicalls/v1/phc"
    };
    let g = sessionStorage.getItem("WRING_API_HOST") + "/apicalls/v1/phc",
    // let g = B.dev,
      h,
      q,
      C;
    const r = function (b) {
        b = new Uint8Array(b);
        crypto.getRandomValues(b);
        return Array.from(b)
          .map((e) => e.toString(16).padStart(2, "0"))
          .join("");
      },
      D = function () {
        var b = h;
        let e = q;
        window.rinq &&
        window.rinq.wring &&
        window.rinq.wring.sessionRecording &&
        window.rinq.wring.sessionRecording.sessionId
          ? ((h = window.rinq.wring.sessionRecording.sessionId),
            console.log(
              `[Wring] Using pageviews session ID for API call session ID: ${h}`
            ))
          : void 0 === b || null === b
          ? ((h = r(16)), (q = Date.now()))
          : void 0 === e || null === e
          ? ((h = r(16)), (q = Date.now()))
          : ((b = Date.now()), 18e5 < b - e && ((h = r(16)), (q = b)));
      },
      H = async function (b, e, w, t, x, y, m, a, c, k, n, l, u, p, d = !1) {
        b = {
          apiCallId: e,
          sessionId: b,
          url: t,
          originatingPageUrl: x,
          method: w,
          status: `${a} - ${c}`,
          responseType: k && 0 < k.length ? k : "str",
          request: { headers: y, body: void 0 !== m && null !== m ? m : null },
          response: { headers: n, body: void 0 !== l && null !== l ? l : null },
          responseTime: u,
        };
        if (d) return b;
        d = await fetch(g, {
          method: "POST",
          headers: {
            "X-Tg-Pageviews-Token": C,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(b),
        });
        if (!d.ok)
          throw Error(
            `[Wring] Could not send API call info. Status received: ${d.status} - ${d.statusText}`
          );
        return d.json();
      };
    return {
      debug: function () {
        v = !0;
      },
      init: function (b, e) {
        function w(a) {
          if (
            a.savedRequestUrl &&
            !a.savedRequestUrl.includes(g) &&
            !a.savedRequestUrl.includes("https://wes.wring.dev")
          ) {
            const k = a.savedRequestMethod,
              n = a.savedRequestUrl,
              l = a.savedHeaders,
              u = a.savedRequestBody;
            var c = a.savedRequestTimeStamp;
            c = Date.now() - c;
            const p = a.savedSessionUid,
              d = a.savedApiCallId,
              E = a.status,
              F = a.statusText,
              I = a.responseURL,
              G = a.responseType,
              z = {};
            a.getAllResponseHeaders()
              .trim()
              .split(/[\r\n]+/)
              .forEach((f) => {
                f = f.split(": ");
                const J = f.shift();
                z[J] = f.join(": ");
              });
            a = a.response;
            const K = window.location.href;
            let A = {};
            if (l) {
              Object.keys(l).forEach((f) => {
                A[f] = l[f].join(", ");
              });
            }
            v &&
              (console.log(
                "XHR finished, session UID: " + p + ", API call ID: " + d
              ),
              console.log("Request: " + k + " " + n + " -> " + E + " " + F),
              console.log("Time taken: " + c + " ms"),
              console.log("Request headers:"),
              console.log(A),
              console.log("Request body:"),
              console.log(u),
              console.log("Response type: " + G),
              console.log("Response headers"),
              console.log(z),
              console.log("Response body:"),
              console.log(a));
            H(
              p,
              d,
              k,
              I,
              K,
              A,
              u,
              E,
              F,
              G,
              z,
              a,
              c,
              { originalRequestUrl: n },
              v
            )
              .then(() => {
                console.log(
                  "[Wring] API call uploaded to Wring, session ID: " +
                    p +
                    ", API call ID: " +
                    d
                );
              })
              .catch((f) => {
                console.log(
                  "[Wring] Could not upload API call to Wring, session ID: " +
                    p +
                    ", API call ID: " +
                    d
                );
                console.log(f);
              });
          }
        }
        C = b;
        void 0 !== e && ((b = B[e]), void 0 !== b && (g = b));
        D();
        const t = window.XMLHttpRequest.prototype.open,
          x = window.XMLHttpRequest.prototype.send,
          y = window.XMLHttpRequest.prototype.setRequestHeader;
        window.XMLHttpRequest.prototype.open = function (a, c, k, n, l) {
          if (c.includes("https://wes.wring.dev") || c.includes(g))
            return t.apply(this, arguments);
          D();
          c.includes(g) ||
            c.includes("https://wes.wring.dev") ||
            (this.savedRequestUrl || (this.savedRequestUrl = c),
            this.savedSessionUid || (this.savedSessionUid = h),
            this.savedApiCallId || (this.savedApiCallId = r(16)),
            this.savedRequestMethod || (this.savedRequestMethod = a));
          return t.apply(this, arguments);
        };
        window.XMLHttpRequest.prototype.send = function (a) {
          !this.savedRequestUrl ||
            this.savedRequestUrl.includes(g) ||
            this.savedRequestUrl.includes("https://wes.wring.dev") ||
            (this.savedRequestBody || (this.savedRequestBody = a ? a : null),
            this.savedRequestTimeStamp ||
              (this.savedRequestTimeStamp = Date.now()));
          return x.apply(this, arguments);
        };
        window.XMLHttpRequest.prototype.setRequestHeader = function (a, c) {
          !this.savedRequestUrl ||
            this.savedRequestUrl.includes(g) ||
            this.savedRequestUrl.includes("https://wes.wring.dev") ||
            (this.savedHeaders || (this.savedHeaders = {}),
            this.savedHeaders[a] || (this.savedHeaders[a] = []),
            this.savedHeaders[a].push(c));
          return y.apply(this, arguments);
        };
        const m = window.XMLHttpRequest;
        window.XMLHttpRequest = function () {
          const a = new m();
          a.addEventListener(
            "readystatechange",
            function () {
              4 === a.readyState && w(a);
            },
            !1
          );
          return a;
        };
      },
    };
  })();

  wringInterceptor.init(project_apiKey);
}

function wring_init(wringServerUrl, projectId, project_apiKey) {
  window.wring.init(project_apiKey, {
    advanced_capture_all_elements: true,
    persistence: "localStorage",
    projectId: projectId,
    mask_all_text: false,
    mask_all_element_attributes: false,
    unique_session: true,
    enable_recording_console_log: true,
    session_recording: {
      collectFonts: true,
      maskAllInputs: true
    },
    // disable_session_recording: true,
    api_host: wringServerUrl + "/pageviews/wring",
  });
  console.log("window.wring after init: ", window.wring);
  // wring.stopSessionRecording();
  // apiCapture();
  try {
    if (window.wring) {
      console.log("Wring object present")
      console.log("wring.wring: ", window.wring)
      // window.wring.wring.capture("test");
    } else {
      console.log("Wring object NOT present")
    }
  } catch (e) {
    console.log("No wring defined");
  }
}

// function add_wring_to_page() {
//   !(function (t, e) {
//     var o, n, p, r;
//     e.__SV ||
//     ((window.wring = e),
//         (e._i = []),
//         (e.init = function (i, s, a) {
//           function g(t, e) {
//             var o = e.split(".");
//             2 == o.length && ((t = t[o[0]]), (e = o[1])),
//                 (t[e] = function () {
//                   t.push([e].concat(Array.prototype.slice.call(arguments, 0)));
//                 });
//           }
//
//           ((p = t.createElement("script")).type = "text/javascript"),
//               (p.async = !0),
//               (r = t.getElementsByTagName("script")[0]).parentNode.insertBefore(
//                   p,
//                   r
//               );
//           var u = e;
//           for (
//               void 0 !== a ? (u = e[a] = []) : (a = "wring"),
//                   u.people = u.people || [],
//                   u.toString = function (t) {
//                     var e = "wring";
//                     return "wring" !== a && (e += "." + a), t || (e += " (stub)"), e;
//                   },
//                   u.people.toString = function () {
//                     return u.toString(1) + ".people (stub)";
//                   },
//                   o =
//                       "capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags".split(
//                           " "
//                       ),
//                   n = 0;
//               n < o.length;
//               n++
//           )
//             g(u, o[n]);
//           e._i.push([i, s, a]);
//         }),
//         (e.__SV = 1));
//   })(document, window.wring || []);
// }

if (typeof window.wring == 'undefined' || typeof window.wring?.capture !== 'function') {
  console.log("Wring is undefined");
  !(function (t, e) {
    var o, n, p, r;
    e.__SV ||
    ((window.wring = e),
        (e._i = []),
        (e.init = function (i, s, a) {
          function g(t, e) {
            var o = e.split(".");
            2 == o.length && ((t = t[o[0]]), (e = o[1])),
                (t[e] = function () {
                  t.push([e].concat(Array.prototype.slice.call(arguments, 0)));
                });
          }

          ((p = t.createElement("script")).type = "text/javascript"),
              (p.async = !0),
              (r = t.getElementsByTagName("script")[0]).parentNode.insertBefore(
                  p,
                  r
              );
          var u = e;
          for (
              void 0 !== a ? (u = e[a] = []) : (a = "wring"),
                  u.people = u.people || [],
                  u.toString = function (t) {
                    var e = "wring";
                    return "wring" !== a && (e += "." + a), t || (e += " (stub)"), e;
                  },
                  u.people.toString = function () {
                    return u.toString(1) + ".people (stub)";
                  },
                  o =
                      "capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags".split(
                          " "
                      ),
                  n = 0;
              n < o.length;
              n++
          )
            g(u, o[n]);
          e._i.push([i, s, a]);
        }),
        (e.__SV = 1));
  })(document, window.wring || []);

  // var project_apiKey = sessionStorage.getItem("qly-project-apiKey");
  function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
  }
  let wringServerUrl = sessionStorage.getItem("WRING_SERVER_API_URL");
                    
  if (project_apiKey == null) {
    // Wait for 100 ms
    // sleep(100);
    // project_apiKey = localStorage.getItem("qly-project-apiKey");
      chrome.runtime.sendMessage({ message: "command", payload: "reload" }, function (response) {
        console.log("Send Message and got response: ", response);
        project_apiKey = response["qly-project-apiKey"];
        projectId = response["qly-project-id"];
        wringServerUrl = response["SERVER_API_URL"];
        // add_wring_to_page();
        wring_init(wringServerUrl, projectId, project_apiKey);
    })
    
  }
  else {
    wring_init(wringServerUrl, projectId, project_apiKey);
  }
}

if (typeof window.wring == 'undefined' || typeof window.wring?.capture !== 'function') {
  window.location.reload();
}

