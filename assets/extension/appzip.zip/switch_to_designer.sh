#!/usr/bin/env bash

cp manifest.designer.json manifest.json
cp config.designer.json config.json
