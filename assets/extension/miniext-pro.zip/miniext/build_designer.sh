#!/usr/bin/env bash

./switch_to_designer.sh
cd ..
zip -r miniext-designer.zip miniext -x "*.git*" -x "*.idea*"
cp miniext-designer.zip wring-site/assets/extension
rm miniext-designer.zip
