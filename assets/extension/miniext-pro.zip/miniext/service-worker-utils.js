let designer_inject = ["./designer.js"];
let pro_inject = ["./pro.js"];
let auth_inject = ["./auth.js"];

let js_injected = ["./html-to-image.js","./cleanup_markers.js", "./heatmap.js", "./json5.min.js","./html2canvas.js", "./jquery-3.6.1.min.js", "./jquery.dataTables.min.js", "./bootstrap.bundle.min.js", "./foreground.js", "./heatmap_compute.js", "./leader-line.min.js", "./getElementOuterHtml.js"];
let pageviews_injected = ["./recorder.js", "./pageviews.js", "./array.js"];

console.log("External file is also loaded!");
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    activated: false,
  });
  chrome.storage.local.get("qly-user", (user) => {
    console.log(user["qly-user"])
    if (user["qly-user"]) {
      chrome.windows.qlyUserAccessTokenPMAssist = user["qly-user"]
    }
  });
  chrome.qly_funnels = null
});


function DataURIToBlob(dataURI) {
  const splitDataURI = dataURI.split(',')
  const byteString = splitDataURI[0].indexOf('base64') >= 0 ? atob(splitDataURI[1]) : decodeURI(splitDataURI[1])
  const mimeString = splitDataURI[0].split(':')[1].split(';')[0]

  const ia = new Uint8Array(byteString.length)
  for (let i = 0; i < byteString.length; i++)
    ia[i] = byteString.charCodeAt(i)

  return new Blob([ia], { type: mimeString })
}

function injectScript(tabId) {
  chrome.scripting
    .insertCSS({
      target: {tabId: tabId},
      files: [ "./css/foreground_styles.css", "./css/jquery.dataTables.min.css"],
    })
    .then(() => {

      let files_to_inject = [];
      const user_qly = chrome.windows.qlyUserAccessTokenPMAssist  
      console.log(user_qly)
      if(!user_qly){
        files_to_inject = auth_inject
      } else {
        files_to_inject = js_injected
      }
      fetch('./config.json')
      .then(response => response.json())
      .then(obj => {
        let login = files_to_inject.indexOf("./auth.js")
        if(login === -1){
          console.log("Inject pageviews: ", obj["PAGEVIEWS"]);
          if (obj["PAGEVIEWS"] === "true") {
            console.log("Injecting pageviews to script");
            files_to_inject = files_to_inject.concat(pageviews_injected)
          }
          else {
            console.log("Not injecting pageviews");
          }
          
          if (obj["VERSION"] === "designer") {
            files_to_inject = designer_inject.concat(files_to_inject);
          }
          else {
            files_to_inject = pro_inject.concat(files_to_inject);
          }
        }
        
        chrome.scripting
          .executeScript({
            target: {tabId: tabId},
            // To turn off recording, remove ./pageviews.js
            // files: ["./foreground.js", "./pageviews.js", "./recorder.js", "./array.js"]

            // files: ["./cleanup_markers.js", "./foreground.js", "./heatmap_compute.js", "./recorder.js", "./array.js", "./pageviews.js", "./leader-line.min.js"],
            files: files_to_inject
          })
          .then(() => {
            console.log("INJECTED THE FOREGROUND SCRIPT.");
          });
      
      })
      
    })
    .catch((err) => console.log(err));
}

async function setDefaultRecorderProject() {
  const user_qly = chrome.windows.qlyUserAccessTokenPMAssist 
  const access_token = chrome.windows.qlyUserAccessTokenPMAssist 
  const headers = {
    'Authorization': `Bearer ${access_token}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  };
  fetch("./env.json")
    .then(response => response.json())
    .then(data => {
      console.log("data: ", data);
      // if data['PAGEVIEW_API_URL']
      if (!('PAGEVIEWS_API_URL' in data)) {
        data['PAGEVIEWS_API_URL'] = data['SERVER_API_URL'];
      }

      fetch(
        `${data['SERVER_API_URL']}/pageviews/user-projects`,
        {
          method: 'GET',
          headers
        }
      )
        .then((response) => {
          return response.json();
          // console.log("output json: ", output);
        })
        .then((response) => {
          console.log("response: ", response);
          chrome.storage.local.set({"qly-project-id": response.response[0].projectId})
          chrome.storage.local.set({"qly-project-apiKey": response.response[0].apiKey})
          
          console.log('Stored qly-project-apiKey ',sessionStorage.getItem("qly-project-apiKey"));
          // console.log("set qly-project-apiKey");
          // console.log("projectId: ", response.response[0].projectId);
          // console.log("apiKey: ", response.response[0].apiKey);
          

          // return response;
          // console.log("output json: ", response);
        })
    })
}
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  chrome.storage.local.get('activated', data => {
    if (data["activated"]) {
      if (changeInfo.status === "complete" && /^http/.test(tab.url)) {
        injectScript(tabId);
      }
    }
  });
  if (changeInfo.url) {
    if (changeInfo.url.includes('/verify')) {
      const url = new URL(changeInfo.url)
      const searchParams = new URLSearchParams(url.search)
      const walToken = searchParams.get('walToken')
      if(chrome.windows.quikly_created_tab_id === tabId){
        chrome.tabs.remove(tabId)
        chrome.windows.qlyUserAccessTokenPMAssist = walToken
        chrome.storage.local.set({ "qly-qly-user": walToken })
        // Google and Github post login
        await setDefaultRecorderProject()
        chrome.tabs.reload()
      }
      
    }
  }
});

chrome.runtime.onMessage.addListener( (request, sender, sendResponse) => {
  console.log("Got request to service-worker: ", request);
  if (request.message === "command") {
    console.log("Command received: ", request.message);
    console.log("Request.payload: ", request.payload);
    // const project_id = 158;
    const access_token =  chrome.windows.qlyUserAccessTokenPMAssist 
    const headers = {
      'Authorization': `Bearer ${access_token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    fetch("./env.json")
    .then(response => response.json())
    .then( data => {
      console.log("data: ", data);
      // if data['PAGEVIEW_API_URL']
      if (!('PAGEVIEWS_API_URL' in data)) {
        data['PAGEVIEWS_API_URL'] = data['SERVER_API_URL'];
      }
      if (request.url && request.payload === "heatmap") {
        // call heatmap api
        let formData = new FormData();
        formData.append('limit_events',100);
        formData.append('project_id',request.project_id);
        formData.append('url',request.url);
        fetch(
          `${data['SERVER_API_URL']}/pageviews/paths`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${access_token}`,
            }, 
            body:formData
          }
        )
        .then(response => response.json())
        .then(result => {
          if (result.message == "Auth token failed verification") {
              chrome.windows.qlyUserAccessTokenPMAssist = null
            }
          console.log("response_json heatmap: ", result);
          sendResponse({
            message: "success",
            command: request.message,
            payload: result,
            url: request.url,
          });
        });
      }
      
      else if (request.payload === "projects") {
        // "https://dev.wring.dev/interceptor/pageviews/paths?project_id=138&url="+          
        // https://demo.quikly.dev/interceptor/pageviews/user-projects
        // console.log("User projects method", getUserProjects());
        
        fetch(
          `${data['SERVER_API_URL']}/pageviews/user-projects`,
          {
            method: 'GET',
            headers
          }
        )
          .then( (response) => {
            return response.json();
          })
          .then((result) => {
            console.log(chrome.storage.local)
            if (result.message.includes("Auth token failed verification")) {
              chrome.windows.qlyUserAccessTokenPMAssist = null
              chrome.tabs.reload()
            }
            console.log("response_json: ", result);
            sendResponse({
              message: "success",
              command: request.message,
              payload: result,
              // url: request.url,
            });
            return result
          });
      
      }
  
      else if (request.url && request.payload === "funnel") {
        // call funnel list api
        // request.action = add/delete/list
        // request.steps = JSON steps
  
        if (request.action === "list") {
  
          fetch(
            `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=list&project_id=${request.project_id}`,
            {headers, method: "get"}
          )
            .then(function (response) {
              return response.json();
            })
            .then(function (result) {
              console.log("response_json: ", result);
              if (result.message.includes("Auth token failed verification")){
                chrome.windows.qlyUserAccessTokenPMAssist = null
                chrome.tabs.reload()
              }
              sendResponse({
                message: "success",
                command: request.message,
                payload: result,
                url: request.url,
              });
            });
        }
        
        else if (request.action === "add") {
          
          let formData = new FormData();
          let uuid;
          let project_api_key = request.project_api_key;
          
          if ( request && request.funnel && request.funnel.length && request.funnel[0]["uuid"])
          {
            uuid = request.funnel[0]["uuid"];
            request.funnel.shift();
            request.funnel[0]["uuid"] = uuid;
          }
          
          formData.append('contains_elements', JSON.stringify(request.funnel));
          formData.append('type', request.type_funnel);
          // formData.append('name', 'PM Assist');
          
          console.log(request.funnel);
          
          // let modified_headers= {'Authorization': `Bearer ${access_token}`
          //   // "Content-Type": "application/x-www-form-urlencoded"
          // };
          // console.log("modified_headers: ", modified_headers);
          
          // Send all screenshots from EACH Step:
          
          
          // modified_headers
          try {
  
            fetch(
              // Change to this API because we need it to show up on the Quikly UI
              // `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=add&name=${request.name}&project_id=${request.project_id}&datatype=elements&limit=10`,
              `${data['PAGEVIEWS_API_URL']}/pageviews/funnelsimpleadd?cmd=add&name=${request.name}&project_id=${request.project_id}&datatype=elements&limit=10`,
              {
                headers: {
                  Authorization: `Bearer ${access_token}`,
                },  
                method: "POST",
                body: formData,
                credentials: 'include'
              }
            )
              .then(function (response) {
                return response.json();
              })
              .then(function (result) {
                console.log("response_json: ", result);
                if (result.message.includes("Auth token failed verification")) {
                  chrome.windows.qlyUserAccessTokenPMAssist = null
                  chrome.tabs.reload()
                }
                sendResponse({
                  message: "success",
                  command: request.message,
                  payload: result,
                  url: request.url,
                });
                
                // Now we need to change all screenshots to point to the new project
                // X-Tg-Pageviews-Token: phc_qJANulw8pDrUjtoTCctScpNJeLyDuskZs7SHoDVBWkX

                // {
                //   "projectId": 60,
                //   "sessionId": "0955e1ae-2114-475c-b3b4-fa86c16ed0cd"
                // }

                let myHeaders = new Headers();
                // console.log("projectAPIKey: ", api_key);
                myHeaders.append("X-Tg-Pageviews-Token", project_api_key);
                myHeaders.append('Content-Type', 'application/json')
                myHeaders.append('Accept', 'application/json')
                // 'Content-Type': 'application/json',
                //   'Accept': 'application/json'

                // let newFormData = new FormData();
                // newFormData.append("projectId", request.project_id);
                // newFormData.append("sessionId", uuid);
                // console.log("UUID: ", uuid);
                // console.log("project_id: ", request.project_id);
                
                let json_form_data = { 
                  "projectId": request.project_id,
                  "sessionId": uuid
                }

                let requestOptions = {
                  method: 'PUT',
                  headers: myHeaders,
                  body: JSON.stringify(json_form_data),
                };

                fetch(`${data['PAGEVIEWS_API_URL']}/pageviews/mobile/incoming`, requestOptions)
                  .then(response => response.text())
                  .then(result => console.log(result))
                  .catch(error => console.log('error', error));
              


              });
          } catch (error) {
            sendResponse({
              message: "success",
              command: error,
              payload: result,
              url: request.url,
            });
          }
        }



        else if (request.action === "delete") {
          fetch(
            `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=delete&name=${request.name}&project_id=${request.project_id}`,
            {headers, method: "delete"}
          )
            .then(function (response) {
              return response.json();
            })
            .then(function (result) {
              console.log("response_json: ", result);
              if (result.message.includes("Auth token failed verification")) {
                chrome.windows.qlyUserAccessTokenPMAssist = null
                chrome.tabs.reload()
              }
              sendResponse({
                message: "success",
                command: request.message,
                payload: result,
                url: request.url,
              });
            });
        }

        else if (request.action === "get") {
          fetch(
            `${data['PAGEVIEWS_API_URL']}/pageviews/funnelsimpleget?cmd=get&project_id=${request.project_id}&name=${request.name}&limit=10`,
            {headers, method: "GET"}
          )
            .then(function (response) {
              return response.json();
            })
            .then(function (result) {
              console.log("response_json: ", result);
              if (result.message.includes("Auth token failed verification")) {
                chrome.windows.qlyUserAccessTokenPMAssist = null
                chrome.tabs.reload()
              }
              sendResponse({
                message: "success",
                command: request.message,
                payload: result,
                url: request.url,
              });
            });
        }
      }
      // else if (request.payload === "screenshot" && request.item) {
      //   console.log("Got screenshot request");
      //   console.log("request: ", request);
      //
      //   sendResponse({
      //           message: "failed screenshot",
      //         });
      // }
      else if (request.payload === "activate") {
  
        console.log("Got activate request");
        chrome.storage.local.set({ funnel: false });
        chrome.storage.local.set({ heatmap: false });
  
        let queryOptions = { active: true, currentWindow: true };
  
        let tabs = chrome.tabs.query(queryOptions, function (tabs) {
          // var url = tabs[0].url;
          // console.log("URL from main.js", url);
          injectScript(tabs[0].id);
        });
  
  
        // return true;
      } 
      
      // full page screenshot functionality
      else if (request.payload === "fullPageScreenshot") {
        console.log("Got full page screenshot request");
        chrome.tabs.captureVisibleTab(null, {format: "png"}, function (dataUrl) {
          if (dataUrl) {
            sendResponse({image: dataUrl});
          } else {
            console.log("Sorry, screenshot functionality is disabled. The 'activeTab' permission is required");
            return false;
          }
        });
        
      }
      
      else if (request.payload === "funnelScreenshot") {
       
        console.log("Funnel screenshot");

        let tg_pageviews_token_name = "qly-project-apiKey";
        if (!request.image_base64) {
          console.log("Need a base64 image, none provided");
          return;
        }

        // message: "command",
        //   payload: "funnelScreenshot",
        //   // url: window.location.href,
        //   image_base64: screenshotArray[0][0],
        //   element: interacted_element

        // chrome.storage.local.get(tg_pageviews_token_name, (projectApiKey) =>{
        let projectApiKey = request.project_api_key

          if (!projectApiKey) {
            console.log("Need to select a project");
          }
          
          else {
            let api_key = projectApiKey;


            // let interacted_element = {
            //   "url": window.location.href,
            //   "xpath": abs_xpath,
            //   human_label: getDeepComputedLabel(e.srcElement),
            // };
            // interacted_element["step_num"] = golden_paths.length;
            //
            // Use this code to SEND screenshots
            let element = request.element;

            let uuid = request.metadata["uuid"];
            
            let myHeaders = new Headers();
            // console.log("projectAPIKey: ", api_key);
            myHeaders.append("X-Tg-Pageviews-Token", api_key);
            myHeaders.append("X-App-Package", "miniext");
            myHeaders.append("X-App-System", "web");
            myHeaders.append("X-App-Event", element.human_label);
            myHeaders.append("X-Session-Id", uuid);
            myHeaders.append("X-Step-Number", element.step_num);
            // myHeaders.append("X-Posthog-Associated-Uid", "puid");
            myHeaders.append("X-Screenshot-Filetype", "png");
            // myHeaders.append("Authorization", `Bearer ${access_token}`);

            let formdata = new FormData();
            // formdata.append("afchess_test", fileInput.files[0], "afchess_test.png");

            const file = DataURIToBlob(request.image_base64);
            const formData = new FormData();
            formData.append('upload', file, 'image.jpg');
            // formData.append('profile_id', this.profile_id); //other param
            // formData.append('path', 'temp/'); //other param

            var requestOptions = {
              method: 'POST',
              headers: myHeaders,
              body: formData,
              redirect: 'follow'
            };

            fetch(`${data['PAGEVIEWS_API_URL']}/pageviews/mobile/incoming`, requestOptions)
            .then(response => response.text())
            .then(result => console.log(result))
            .catch(error => console.log('error', error));
          }
          
        // })

        
        
      }
      
      else if (request.payload === "auth") {
        if (request.action === 'extraLogin') {
          const callback = async createdTab => {
            chrome.windows.quikly_created_tab_id = createdTab.id
          }
          chrome.tabs.create(
            {
              url: `${data['SERVER_API_URL']}${request.url}`,
              active: true,
            },
            callback
          )
        }
        else if (request.action === "fetchPost") {
          fetch(`${data['SERVER_API_URL']}${request.url}`,{
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: request.body
          })
          .then(response => response.json())
          .then(async(result) => {
            if (result.status === "success" && request.url === "/auth/v1/users/login" ) {
              chrome.windows.qlyUserAccessTokenPMAssist = result.response.access_token
              chrome.storage.local.set({ "qly-qly-user": result.response.access_token })
              // Do one more API call to get the pageviews token for the first project
              // Username/password login
              await setDefaultRecorderProject()
              
              chrome.tabs.reload()
            }
            sendResponse({
              message: "success",
              command: request.message,
              payload: result,
            });
          })
        }
        else if (request.action === "logout") {
          fetch(`${data['SERVER_API_URL']}${request.url}`,{
            method: 'POST',
            headers: headers,
          })
          .then(response => response.json())
            .then(result => {
              if (result.status === "success") {
                chrome.windows.qlyUserAccessTokenPMAssist = null
                chrome.tabs.reload()

              }
              if (result.message.includes("Auth token failed verification")){
                chrome.windows.qlyUserAccessTokenPMAssist = null
                chrome.tabs.reload()
              }
            sendResponse({
              message: "success",
              command: request.message,
              payload: result,
            });
          })
        }
      }
      return true;
    })
  }
  return true;
});