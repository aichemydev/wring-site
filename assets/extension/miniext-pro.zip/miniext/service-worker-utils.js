let designer_inject = ["./designer.js"];
let pro_inject = ["./pro.js"];

let js_injected = ["./html-to-image.js","./cleanup_markers.js", "./heatmap.js", "./json5.min.js","./html2canvas.js", "./jquery-3.6.1.min.js", "./jquery.dataTables.min.js", "./bootstrap.bundle.min.js", "./fontawesome-all.min.js", "./foreground.js", "./heatmap_compute.js", "./leader-line.min.js", "./getElementOuterHtml.js", "env.js"];
let pageviews_injected = ["./recorder.js", "./pageviews.js", "./array.js"];
console.log("External file is also loaded!");
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    activated: false,
  });
});

function injectScript(tabId) {
  chrome.scripting
    .insertCSS({
      target: {tabId: tabId},
      files: ["./css/bootstrap.min.css", "./css/foreground_styles.css", "./css/jquery.dataTables.min.css"],
    })
    .then(() => {
      console.log("INJECTED THE FOREGROUND STYLES.");
      
      let files_to_inject = js_injected;
      
      fetch('./config.json')
        .then(response => response.json())
        .then(obj => {
          console.log("Inject pageviews: ", obj["PAGEVIEWS"]);
          
          if (obj["PAGEVIEWS"] === "true") {
            console.log("Injecting pageviews to script");
            files_to_inject = js_injected.concat(pageviews_injected)
          }
          else {
            console.log("Not injecting pageviews");
          }
          
          if (obj["VERSION"] === "designer") {
            files_to_inject = designer_inject.concat(files_to_inject);
          }
          else {
            files_to_inject = pro_inject.concat(files_to_inject);
          }
          
          chrome.scripting
            .executeScript({
              target: {tabId: tabId},
              // To turn off recording, remove ./pageviews.js
              // files: ["./foreground.js", "./pageviews.js", "./recorder.js", "./array.js"]

              // files: ["./cleanup_markers.js", "./foreground.js", "./heatmap_compute.js", "./recorder.js", "./array.js", "./pageviews.js", "./leader-line.min.js"],
              files: files_to_inject
            })
            .then(() => {
              console.log("INJECTED THE FOREGROUND SCRIPT.");
            });
        
        })
      
    })
    .catch((err) => console.log(err));
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  chrome.storage.local.get('activated', data => {
    if (data["activated"]) {
      if (changeInfo.status === "complete" && /^http/.test(tab.url)) {
        injectScript(tabId);
      }
    }
  });
  if (changeInfo.url) {
    if (changeInfo.url.includes('/verify')) {
      const url = new URL(changeInfo.url)
      const searchParams = new URLSearchParams(url.search)
      const walToken = searchParams.get('walToken')
      if(chrome.windows.quikly_created_tab_id === tabId){
        chrome.tabs.remove(tabId)
        chrome.storage.local.set({"qly-user": walToken})
        chrome.tabs.reload()
      }
      
    }
  }
});

chrome.runtime.onMessage.addListener( (request, sender, sendResponse) => {
  console.log("Got request to service-worker: ", request);
  if (request.message === "command") {
    console.log("Command received: ", request.message);
    console.log("Request.payload: ", request.payload);
    // const project_id = 158;
    chrome.storage.local.get("qly-user", (data) => {
      const access_token =  data["qly-user"]
      const headers = {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      };
      fetch("./env.json")
      .then(response => response.json())
      .then( data => {
        console.log("data: ", data);
        // if data['PAGEVIEW_API_URL']
        if (!('PAGEVIEWS_API_URL' in data)) {
          data['PAGEVIEWS_API_URL'] = data['SERVER_API_URL'];
        }
        if (request.url && request.payload === "heatmap") {
          // call heatmap api
          fetch(
            `${data['SERVER_API_URL']}/pageviews/paths?project_id="+request.project_id+"&url="+
            request.url`,
            { headers }
          )
            .then(function (response) {
              return response.json();
            })
            .then(function (result) {
              console.log("response_json: ", result);
              sendResponse({
                message: "success",
                command: request.message,
                payload: result,
                url: request.url,
              });
            });
        }
        
        else if (request.payload === "projects") {
          // "https://dev.wring.dev/interceptor/pageviews/paths?project_id=138&url="+          
          // https://demo.quikly.dev/interceptor/pageviews/user-projects
          fetch(
            `${data['SERVER_API_URL']}/pageviews/user-projects`,
            {
              method: 'GET',
              headers
            }
          )
            .then( (response) => {
              return response.json();
            })
            .then( (result) => {
              console.log("response_json: ", result);
              sendResponse({
                message: "success",
                command: request.message,
                payload: result,
                // url: request.url,
              });
              return result
            });
        
        }
    
        else if (request.url && request.payload === "funnel") {
          // call funnel list api
          // request.action = add/delete/list
          // request.steps = JSON steps
    
          if (request.action === "list") {
    
            fetch(
              `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=list&project_id=${request.project_id}`,
              {headers, method: "get"}
            )
              .then(function (response) {
                return response.json();
              })
              .then(function (result) {
                console.log("response_json: ", result);
                sendResponse({
                  message: "success",
                  command: request.message,
                  payload: result,
                  url: request.url,
                });
              });
          }
          
          else if (request.action === "add") {
            // let funnel_json = JSON.stringify(request.funnel);
            // const data = new URLSearchParams();
            // for (const pair of new FormData(formElement)) {
            //   data.append(pair[0], pair[1]);
            // }

            let formData = new FormData();
            formData.append('contains_elements', JSON.stringify(request.funnel));
            // formData.append('password', 'John123');

            // fetch("api/SampleData",
            //   {
            //     body: formData,
            //     method: "post"
            //   });
            
            
            console.log(request.funnel);
            
            let modified_headers= {'Authorization': `Bearer ${access_token}`
              // "Content-Type": "application/x-www-form-urlencoded"
            };
            console.log("modified_headers: ", modified_headers);

            // let modified_headers = { ...headers };
            // delete modified_headers["Content-Type"];
            // delete modified_headers["Accept"];
            
            // modified_headers
            fetch(
              `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=add&name=${request.name}&project_id=${request.project_id}&datatype=elements&limit=102`,
              {
                Authorization: `Bearer ${access_token}`,
                method: "POST",
                body: formData,
                credentials: 'include'

              }
            )
              .then(function (response) {
                return response.json();
              })
              .then(function (result) {
                console.log("response_json: ", result);
                sendResponse({
                  message: "success",
                  command: request.message,
                  payload: result,
                  url: request.url,
                });
              });
          }
    
          else if (request.action === "delete") {
            fetch(
              `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=delete&name=${request.name}&project_id=${request.project_id}`,
              {headers, method: "delete"}
            )
              .then(function (response) {
                return response.json();
              })
              .then(function (result) {
                console.log("response_json: ", result);
                sendResponse({
                  message: "success",
                  command: request.message,
                  payload: result,
                  url: request.url,
                });
              });
          }
    
          else if (request.action === "get") {
            fetch(
              `${data['PAGEVIEWS_API_URL']}/pageviews/funnelstorage?cmd=get&project_id=${request.project_id}&name=${request.name}`,
              {headers, method: "GET"}
            )
              .then(function (response) {
                return response.json();
              })
              .then(function (result) {
                console.log("response_json: ", result);
                sendResponse({
                  message: "success",
                  command: request.message,
                  payload: result,
                  url: request.url,
                });
              });
          }
            
          
        }
        // else if (request.payload === "screenshot" && request.item) {
        //   console.log("Got screenshot request");
        //   console.log("request: ", request);
        //
        //   sendResponse({
        //           message: "failed screenshot",
        //         });
        // }
        else if (request.payload === "activate") {
    
          console.log("Got activate request");
          chrome.storage.local.set({ funnel: false });
          chrome.storage.local.set({ heatmap: false });
    
          let queryOptions = { active: true, currentWindow: true };
    
          let tabs = chrome.tabs.query(queryOptions, function (tabs) {
            // var url = tabs[0].url;
            // console.log("URL from main.js", url);
            injectScript(tabs[0].id);
          });
    
    
          // return true;
        } 
        
        // full page screenshot functionality
        else if (request.payload === "fullPageScreenshot") {
          console.log("Got full page screenshot request");
          chrome.tabs.captureVisibleTab(null, {format: "png"}, function (dataUrl) {
            if (dataUrl) {
              sendResponse({image: dataUrl});
            } else {
              console.log("Sorry, screenshot functionality is disabled. The 'activeTab' permission is required");
              return false;
            }
          });
          
        }
        else if (request.action === "extraLogin") {
          const callback = async createdTab => {
            chrome.windows.quikly_created_tab_id = createdTab.id
          }
          chrome.tabs.create(
            {
              url: request.url,
              active: true,
            },
            callback
          )
        }
        return true;
      })
    } ) 
  }
  return true;
});