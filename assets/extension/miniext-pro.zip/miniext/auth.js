const GOLDEN_PATH_CLASSNAME = "crx_golden_path"; // Unique ID for the className.
const UI_URL = "https://beta.quikly.dev/";
let prevDOM = null; // Previous dom, that we want to track, so we can remove the previous styling.
let qlyIndicatorContainer = document.createElement("DIV"); // The indicator container
// let golden_paths = [];
console.log("PRODUCT VERSION: ", window.wring_version);

const render = () => {
    let line_awesome = document.createElement("link"); // The indicator container
    line_awesome.rel = "stylesheet"
    line_awesome.href = chrome.runtime.getURL("/css/line_awesome/css/line_awesome.min.css") 
    document.querySelector("head").appendChild(line_awesome);
  let qlyAppContainer = document.createElement("DIV"); // The indicator container
  qlyAppContainer.id = "qly-app";
  document.querySelector("html").appendChild(qlyAppContainer);
  const _parent = document.getElementById("qly-app");
  const wring_logo = chrome.runtime.getURL("/logo/logo-16.png");
  // Commented this out until Biya is ready with the login
  const _logged = false;
  // const _logged = true;
  const _error = sessionStorage.getItem("qly-login-error")
  ? `<div class="qly--alert_danger qly--fnt-family">
  An error has occurred while login, please check credentials
  or network!
  </div>`
  : ``;
  let la_envelope = chrome.runtime.getURL("/images/icon/la-envelope.svg")
  let la_github = chrome.runtime.getURL("/images/icon/la-github.svg")
  let la_google= chrome.runtime.getURL("/images/icon/la-google.svg")
  let la_lock = chrome.runtime.getURL("/images/icon/la-lock.svg")
  let la_login = chrome.runtime.getURL("/images/icon/la-login.svg")
  let la_user = chrome.runtime.getURL("/images/icon/la-user.svg")
  _logged && localStorage.removeItem("qly-user");
  _error.length > 3 && sessionStorage.removeItem("qly-login-error");
  _parent.innerHTML = `<div id="qly--headless--container" class="qly--container--login">
    <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
    <span class="qly--indicator_close ph-no-capture" id="qly-container-closer">x</span>
      <div id="Login-show" >
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <div class=" qly--fnt-family qly--h1"> PM Assist </div>
          <div class=" qly--fnt-family qly--p"> Powerful product assistant  </div>
        </div>
        <form id="login-form" class="qly--app_login" action="" >
          <div class="qly-para  qly--fnt-family qly--p">Sign in with</div>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary">
              <span class="ico-btn">
                <img alt="la_github" title="la_github" src="${la_github}" />
              </span>
              <span class="text-btn  qly--fnt-family">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <img alt="la_google" title="la_google" src="${la_google}" />
              </span>
              <span class="text-btn  qly--fnt-family">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <div class="qly-para  qly--fnt-family qly--p">Or sign in with credentials</div>
            ${_error}
            <div id="alert_danger" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_envelope}" />
              </span>
              <input class="qly--fnt-family" type="email" name="email" placeholder="Enter Email" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_lock}" />
              </span>
              <input class="qly--fnt-family" type="password" name="password"  placeholder="Enter Password" required />
            </div>
            <div class="qly--ipt_group_remember f--center">
              <input class=" qly--fnt-family" title="remember-check" type="checkbox" name="remember"/>
              <span class="qly--fnt-family">Remember me ?</span>
            </div>
      
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <img alt="la_login" title="la_login" src="${la_login}" />
              </span>
              <span class="text-btn  qly--fnt-family">Sign In</span>
            </button>
          </div>
        </form>
        <div class="create-forgot">
          <div class="after--link">
            <a class=" qly--fnt-family" id="link-forgot-password" rel="noreferrer" href="#">
            Forgot password?
            </a>
          </div>
          <div class="after--link">
            <a id="link-create-new-account" class=" qly--fnt-family" rel="noreferrer" href="#">
              Create new account »
            </a>
          </div>
        </div>
      </div>
      <div id="create-new-account" style="display: none;">
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <div class=" qly--fnt-family qly--h1"> Create an account </div>
          <div class=" qly--fnt-family qly--p"> Sign up for PM Assist</div>
        </div>
        <form id="create-new-account-form" class="qly--app_login" action="" >
          <div class="qly-para qly--fnt-family qly--p">Sign in with</div>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary">
              <span class="ico-btn">
                <img alt="la_github" title="la_github" src="${la_github}" />
              </span>
              <span class="text-btn  qly--fnt-family">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <img alt="la_google" title="la_google" src="${la_google}" />
              </span>
              <span class="text-btn  qly--fnt-family">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <div class="qly-para  qly--fnt-family qly--p">Or sign in with credentials</div>
            ${_error}
            <div id="alert_danger_create" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_user}" />
              </span>
              <input class=" qly--fnt-family" type="text" name="full_name" placeholder="Enter Full Name" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_envelope}" />
              </span>
              <input class=" qly--fnt-family" type="email" name="email" placeholder="Enter Email" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_lock}" />
              </span>
              <input class=" qly--fnt-family" type="password" name="password" placeholder="Enter Password" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_lock}" />
              </span>
              <input class=" qly--fnt-family" type="password" name="confirm_password" placeholder="Confirm Password" required />
            </div>
            <div class="qly--ipt_group_remember f--center">
              <input class=" qly--fnt-family" title="remember-check" type="checkbox" name="terms_conditions" required />
              <span class=" qly--fnt-family" >I agree with the <a target="_blank" href="${UI_URL}service-agreement"> Terms and conditions</a></span>
            </div>
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <img alt="la_login" title="la_login" src="${la_login}" />
              </span>
              <span class="text-btn qly--fnt-family">Create account</span>
            </button>
          </div>
        </form>
          <div class="create-forgot">
            <div class="after--link qly--fnt-family">
              Have an account? <a class="qly--fnt-family"id="link-login-show" rel="noreferrer" href="#">
                Login
              </a>
            </div>
          </div>
      </div>
      <div id="forgot-password" style="display: none;">
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <div class="qly--fnt-family qly--h1"> PM Assist </div>
        </div>
        <form id="forgot-password-form" class="qly--app_login" action="">
          <div class="qly-para qly--fnt-family">Sign in with</div>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary">
              <span class="ico-btn">
                <img alt="la_github" title="la_github" src="${la_github}" />
              </span>
              <span class="text-btn  qly--fnt-family">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <img alt="la_google" title="la_google" src="${la_google}" />
              </span>
              <span class="text-btn  qly--fnt-family">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <div class="qly-para qly--fnt-family qly--p">Or reset your password</div>
            ${_error}
            <div id="alert_danger_forgot_password" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <img alt="la_login" title="la_login" src="${la_envelope}" />
              </span>
              <input class="qly--fnt-family" type="email" name="email" placeholder="Enter Email" required />
            </div>
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <img alt="la_login" title="la_login" src="${la_login}" />
              </span>
              <span class="text-btn qly--fnt-family">Send Password Reset Link</span>
            </button>
          </div>
        </form>
          <div class="create-forgot">
            <div class="after--link">
              <a class="qly--fnt-family" id="p--link-login-show" rel="noreferrer" href="#">
                Login
              </a>
            </div>
            <div class="after--link">
              <a class="qly--fnt-family" id="p--link-create-new-account" rel="noreferrer" href="#">
                Create new account »
              </a>
            </div>
          </div>
      </div>
    </div>`

  if (document.getElementById("qly-container-closer")) {
    document
      .getElementById("qly-container-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("qly--headless--container");
        console.log(elt)
        if (elt) {
          elt.style.display = "none";
          clearHeatMap();
          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
        }
      });
  }
  if( document.getElementById("link-create-new-account")){
    document
      .getElementById("link-create-new-account")
      .addEventListener("click", (e) => {
        console.log("register")
        showContentLogin("register")
      });
  }
  if( document.getElementById("link-login-show")){
    document
      .getElementById("link-login-show")
      .addEventListener("click", (e) => {
        console.log("login")
        showContentLogin("login")
      });
  }
  if( document.getElementById("p--link-create-new-account")){
    document
      .getElementById("p--link-create-new-account")
      .addEventListener("click", (e) => {
        console.log("register")
        showContentLogin("register")
      });
  }
  if( document.getElementById("p--link-login-show")){
    document
      .getElementById("p--link-login-show")
      .addEventListener("click", (e) => {
        console.log("login")
        showContentLogin("login")
      });
  }
  if( document.getElementById("link-forgot-password")){
    document
      .getElementById("link-forgot-password")
      .addEventListener("click", (e) => {
        console.log("password")
        showContentLogin("password")
      });
  }

  if( document.getElementById("forgot-password-form")){
    document
      .getElementById("forgot-password-form")
      .addEventListener("submit", (e) => {
        console.log("forgot-password-form")
        e.preventDefault();
      });
  }
  if( document.getElementById("create-new-account-form")){
    document
      .getElementById("create-new-account-form")
      .addEventListener("submit", (e) => {
        console.log("create-new-account-form")
        e.preventDefault();
        register()
      });
  }
  if( document.getElementById("login-form")){
    document
      .getElementById("login-form")
      .addEventListener("submit", (e) => {
        console.log("login-form")
        e.preventDefault();
        login()
      });
  }
  if( document.getElementById("github-login")){
    document
      .getElementById("github-login")
      .addEventListener("click", (e) => {
        console.log('fokoui',e)
        githubLogin()
      });
  }
  if( document.getElementById("google-login")){
    document
      .getElementById("google-login")
      .addEventListener("click", (e) => {
        googleLogin()
      });
  }
  if(document.getElementById("forgot-password-form")){
    document
      .getElementById("forgot-password-form")
      .addEventListener("submit", (e) => {
        e.preventDefault();
        forgotPassword()
      });
  }
  if (document.getElementById("qly-container-closer")) {
      document
        .getElementById("qly-container-closer")
        .addEventListener("click", (e) => {
          let elt = document.getElementById("qly--headless--container");
          if (elt) {
            elt.style.display = "none";
            clearHeatMap();
            chrome.storage.local.set({ recording: false });
            chrome.storage.local.set({ activated: false });
          }
        });
    }
  if( document.getElementById("link-create-new-account")){
    document
      .getElementById("link-create-new-account")
      .addEventListener("click", (e) => {
        showContentLogin("register")
      });
  }
  if( document.getElementById("link-login-show")){
    document
      .getElementById("link-login-show")
      .addEventListener("click", (e) => {
        showContentLogin("login")
      });
  }
  if( document.getElementById("p--link-create-new-account")){
    document
      .getElementById("p--link-create-new-account")
      .addEventListener("click", (e) => {
        showContentLogin("register")
      });
  }
  if( document.getElementById("p--link-login-show")){
    document
      .getElementById("p--link-login-show")
      .addEventListener("click", (e) => {
        showContentLogin("login")
      });
  }
  if( document.getElementById("link-forgot-password")){
    document
      .getElementById("link-forgot-password")
      .addEventListener("click", (e) => {
        showContentLogin("password")
      });
  }
};

async function forgotPassword(){
  let _error = document.getElementById("alert_danger_forgot_password")
  const from = document.getElementById("forgot-password-form")
  toggleIndicatorLoader();
  try {
    const body =  JSON.stringify({
        email: from.elements["email"].value,
    })
    const url = "/auth/v1/users/password/forgot"
    chrome.runtime.sendMessage(
    { message: "command", payload: "auth", action: 'fetchPost', body: body, url:url},
      function (response) {
      console.log("jbfdksbfnlkhdnkjsbkjbsjbfkjb", response)
      if(!response.payload || response.payload.status === "failed"){
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = response.payload.message
        _error.style.display = "block"
        return 
      }else{
        from.elements["email"].value = ""
        showContentLogin("login")
        let _succes = document.getElementById("alert_danger")
        _succes.classList.add("qly--alert_success");
        _succes.innerHTML = response.payload.message
        _succes.style.display = "block"
        console.log(_error)
      }
    });
  } catch (error) {
    console.log(error)
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
  }
  toggleIndicatorLoader()
}

async function login() {
  toggleIndicatorLoader();
  const from = document.getElementById("login-form")
  if(from.elements["email"].value.length < 1){
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Email required !"
    _error.style.display = "block"
    return 
  }
  // qly--alert_danger
  if(from.elements["password"].value.length < 1){
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Password required!"
    _error.style.display = "block"
    return 
  }
  try {
    const body = JSON.stringify(
      {
        email: from.elements["email"].value,
        password: from.elements["password"].value,
      }
    )
    const url = "/auth/v1/users/login"
    chrome.runtime.sendMessage(
      { message: "command", payload: "auth", action: 'fetchPost', body: body, url: url},
    function (response) {
      if(!response.payload || response.payload.status === "failed"){
        toggleIndicatorLoader();
        let _error = document.getElementById("alert_danger")
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = "An error has occurred while login, please check credentials or network!"
        _error.style.display = "block"
        return 
      }else{
        let elt = document.getElementById("qly-indicator-loader");
        elt.style.display = "none";
        document.getElementById("qly-app").remove()
      }
    });
  } catch (error) {
    console.log(error)
    console.log(error)
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
    toggleIndicatorLoader()
  }
}

async function googleLogin(){
  chrome.runtime.sendMessage({
    message: "command",
    payload: "auth",
    action: "extraLogin",
    url: "/auth/v1/oauth2/custom/google",
  });
}

async function githubLogin(){
  chrome.runtime.sendMessage({
    message: "command",
    action: "extraLogin",
    payload: "auth",
    url: "/auth/v1/oauth2/custom/github",
  });
}

async function register() {
  const from = document.getElementById("create-new-account-form")
  const passwrdRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
  let _error = document.getElementById("alert_danger_create")
  _error.classList.add("qly--alert_danger");
  _error.style.display = "none"
  if(!passwrdRegex.test(from.elements['password'].value)){
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "the password must be at least 8 characters long and contain at least one number and one special character !"
    _error.style.display = "block"
    return 
  }
  if(from.elements['password'].value !== from.elements['confirm_password'].value){
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Passwords did not match!"
    _error.style.display = "block"
    return 
  }

  toggleIndicatorLoader();
  try {
    const body = JSON.stringify(
      {
        fullName: from.elements["full_name"].value,
        email: from.elements["email"].value,
        password: from.elements["password"].value,
        confirmPassword: from.elements["confirm_password"].value,
      }
    )
    const url = "/auth/v1/users/new"
    chrome.runtime.sendMessage(
    { message: "command", payload: "auth", action: 'fetchPost', body: body, url: url },
    function (response) {
      if(!response.payload || response.payload.status === "failed"){
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = response.payload.message
        _error.style.display = "block"
        return 
      }else{
        from.elements["full_name"].value = ""
        from.elements["email"].value = ""
        from.elements["password"].value = ""
        from.elements["confirm_password"].value = ""
        showContentLogin("login")
        let _succes = document.getElementById("alert_danger")
        _succes.classList.add("qly--alert_success");
        _succes.innerHTML = ""
        _succes.innerHTML = response.payload.message
        _succes.style.display = "block"
        console.log(_error)
      }
    });
  } catch (error) {
    console.log(error)
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
  }
  toggleIndicatorLoader()

}
function toggleIndicatorLoader() {
  let elt = document.getElementById("qly-indicator-loader");
  elt.style.display = elt.style.display === "none" ? "flex" : "none";
  console.log("elt: ", elt.style.display);
}
function showContentLogin(go){
  document.getElementById("alert_danger").innerHTML = ""
  document.getElementById("alert_danger").style.display = "none"
  document.getElementById("alert_danger_forgot_password").innerHTML = ""
  document.getElementById("alert_danger_forgot_password").style.display = "none"
  document.getElementById("alert_danger_create").innerHTML = ""
  document.getElementById("alert_danger_create").style.display = "none"

  document.getElementById("forgot-password").style.display = "none"
  document.getElementById("Login-show").style.display = "none"
  document.getElementById("create-new-account").style.display = "none"
  if(go === "login"){
    document.getElementById("Login-show").style.display = "block"
  }
  if(go === "password"){
    document.getElementById("forgot-password").style.display = "block"
  }
  if(go === "register"){
    document.getElementById("create-new-account").style.display = "block"
  }
}
function clearHeatMap() {
  let displayed = false;
  console.log("Calling clearHeatMap");

  let boxes = document.querySelectorAll(".qly_heatmap_element_hover");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element_hover");
  });

  document.querySelectorAll(".qly--elt_circle_bg").forEach((box) => {
    box.remove();
  });

  boxes = document.querySelectorAll(".qly_heatmap_element");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element");
  });

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  // chrome.storage.local.set({ heatmap: false });
  return displayed;
}
chrome.storage.local.get("activated", (data) => {
  if (data["activated"]) {
    render()
  }
});