#!/usr/bin/env bash

cp manifest.designer.json manifest.json
cp config.staging.json config.json
