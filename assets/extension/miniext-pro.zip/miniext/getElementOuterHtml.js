function getElementsByXPath(xpath, contextNode) {
  let xpathResult = ''
  if (contextNode === undefined) {
    xpathResult = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.ANY_TYPE,
      null
    )
  } else {
    xpathResult = contextNode.evaluate(
      xpath,
      contextNode,
      null,
      XPathResult.ANY_TYPE,
      null
    )
  }
  var array = []
  var element
  element = xpathResult.iterateNext()
  while (element) {
    array[array.length] = element
    element = xpathResult.iterateNext()
  }
  return array
}

function getElementByOuterHTML(outer_html) {
  [...document.querySelectorAll("*")].forEach((el)=>{
    if(el.outerHTML == outer_html){
      return el;
    }
    // console.log("el.outerHtml: ", el.outerHTML);
    // console.log("el: ", el);
  });
}

function xpath(el, relative) {
  if (typeof el == "string") return document.evaluate(el, document, null, 0, null);
  if (!el || el.nodeType != 1) return '';
  if (relative) {
    if (el.id) return "//*[@id='" + el.id + "']"
  }
  var sames = [].filter.call(el.parentNode.children, function (x) { return x.tagName == el.tagName });
  return xpath(el.parentNode) + '/' + el.tagName.toLowerCase() + (sames.length > 1 ? '['+([].indexOf.call(sames, el)+1)+']' : '')
}


function getElementByXPath(xpath, contextNode) {
  let xpathResult = ''
  if (contextNode === undefined) {
    xpathResult = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.ANY_TYPE,
      null
    )
  } else {
    xpathResult = contextNode.evaluate(
      xpath,
      contextNode,
      null,
      XPathResult.ANY_TYPE,
      null
    )
  }
  return xpathResult.iterateNext()
}

function extractedElementDetail(el, method) {
  let thisRect = el.getBoundingClientRect()
  let elementId = el.id
  let text = el.textContent
  // console.log("el.text: ", text)
  let tag = el.tagName
  let cssClass = el.className
  // let cssClass = await webElement.getAttribute("class");
  let htmlName = el.tagName
  let htmlId = el.id
  let thisOuterHtml = el.outerHTML
  let thisInnerHtml = el.innerHTML

  return {
    elementId,
    text,
    tag,
    isEnabled: true,
    isDisplayed: true,
    cssClass,
    htmlName,
    htmlId,
    x: thisRect.x,
    y: thisRect.y,
    width: thisRect.width,
    height: thisRect.height,
    innerHtml: thisInnerHtml,
    outerHtml: thisOuterHtml,

  }
}

function parseElementFromTarget(string_target) {
  let parsed_target = ''
  let method = 'xpath'
  if (string_target.startsWith('xpath=')) {
    parsed_target = string_target.replace('xpath=', '')
  } else if (string_target.startsWith('id=')) {
    parsed_target = string_target.replace('id', '')
    parsed_target = "//*[@id='" + parsed_target + "']"
    // css_target = f"#{string_target.replace('id=','')}"
  } else if (string_target.startsWith('class=')) {
    parsed_target = string_target.replace('class=', '')
    parsed_target = "//*[@class='" + parsed_target + "']"
  } else if (string_target.startsWith('name=')) {
    parsed_target = string_target.replace('name=', '')
    // console.log('parsed_target: ', parsed_target)
    parsed_target = "//*[@name='" + parsed_target + "']"
  } else if (string_target.startsWith('partialLinkText=')) {
    parsed_target = string_target.replace('partialLinkText=', '')
    parsed_target = '//a[contains(string(), ' + '"' + parsed_target + '")]'
  } else if (
    string_target.startsWith('link=') ||
    string_target.startsWith('linkText=')
  ) {
    parsed_target = string_target.replace('link=', '').replace('linkText=', '')
    parsed_target = '//a[contains(string(), ' + '"' + parsed_target + '")]'
  } else if (string_target.startsWith('css=')) {
    parsed_target = string_target
    method = 'css'
  } else {
    // console.log('Could not parse target: ', target, ' for command: ', command)
    parsed_target = string_target
    method = 'other'
  }
  return {parsed_target, method}
}

function getDeepComputedLabel(element) {
  // var label = getComputedLabel(element);
  // if (!label) {
  //   // getComputedLabel(element.childList)
  //
  //   for (const child of element.children) {
  //     label = getComputedLabel(child);
  //   }
  // }
  var label = getComputedLabel(element);
  if (!label) {
    return allDescendants(element);
  }
  return label;
}

function allDescendants (node) {
  for (var i = 0; i < node.children.length; i++) {
    var child = node.children[i];
    allDescendants(child);
    label = getComputedLabel(child);
    if (label) return label;
  }

}

// function allDescendants (node) {
//     for (var i = 0; i < node.childNodes.length; i++) {
//       var child = node.childNodes[i];
//       allDescendants(child);
//       label = getComputedLabel(child);
//       if (label) return label;
//     }
//  
// }

function getComputedLabel(element) {
  if (element) {
    // The element's `aria-labelledby
    var ariaLabelledby = element.getAttribute('aria-labelledby')
    if (ariaLabelledby) {
      var ariaLabelledbyElement = document.getElementById(ariaLabelledby)
      if (ariaLabelledbyElement) {
        var ariaLabelledbyElementText = ariaLabelledbyElement.innerText
        if (ariaLabelledbyElementText) return ariaLabelledbyElementText
      }
    }
    // The element's `aria-label`
    var ariaLabel = element.getAttribute('aria-label')
    if (ariaLabel) return ariaLabel
    // If it's an image/etc., alternate text
    // Even if it's an empty alt attribute alt=""
    if (
      element.tagName === 'APPLET' ||
      element.tagName === 'AREA' ||
      element.tagName === 'IMG' ||
      element.tagName === 'INPUT'
    ) {
      const altText = element.getAttribute('alt')
      if (typeof altText === 'string') return altText
    }
    // <desc> for SVGs
    if (element.tagName === 'SVG') {
      var descElt = element.querySelector('desc')
      if (descElt) {
        var descText = descElt.innerText || descElt.innerHTML
        if (descText) return descText
      }
    }
    // The value of the element
    const innerText = element.innerText
    if (innerText) return innerText
    
    let name = element.getAttribute('name')
    if (name) return name
    
    let placeholder = element.getAttribute('placeholder')
    if (placeholder) return placeholder;
  }
}

function ElementOuterHTML(document_root) {
  // console.log('command: ', command)
  // console.log('target: ', target)
  // console.log('pageURL: ', pageURL)
  let parsed_target = ''
  let css_target = ''
  // const string_target = target.trim()
  let method = 'xpath'

  let outerHtml = ''
  let elDetail = ''
  // console.log('targets: ', command_targets)

  let el = null
  let string_target = null

  command_targets.every(function (target, index) {
    string_target = target[0].trim()
    // console.log('target: ', target)
    // console.log('string_target: ', string_target)

    if (target[1].startsWith('linkText')) {
      // console.log('linkText target, skipping this locator, moving to next')
      return true
    }
    const __ret = parseElementFromTarget(string_target)
    parsed_target = __ret.parsed_target
    css_target = __ret.css_target
    method = __ret.method
    // console.log('method: ', method)

    if (method === 'xpath') {
      // console.log('parsed_xpath_target: ', parsed_target)
      el = getElementByXPath(parsed_target)
      // console.log('el: ', el)
    } else if (method === 'css') {
      el = document.querySelector(css_target)
      // console.log('el: ', el)
    } else if (method === 'other') {
      return true
    }
    return !el
  })

  // console.log('Element after loop: ', el)

  if (!el) {
    // console.log('No element found, returning back: ', el)
    return {}
  }
  elDetail = extractedElementDetail(el)

  // if (el)
  let humanLabel = getComputedLabel(el)
  let elText = el.innerText
  // if (humanLabel) humanLabel = humanLabel.substring(0, 25)

  let dimensions = {
    full: {},
    element: {},
  }
  dimensions.devicePixelRatio = window.devicePixelRatio

  let screenshotType = 'fullPage' // or "fullPage"

  // if (screenshotType === "fullPage") {
  let elem = el
  while (elem !== document.body && elem !== null && elem !== undefined) {
    dimensions.element.top += elem.offsetTop
    dimensions.element.left += elem.offsetLeft
    elem = elem.offsetParent
  }
  // dimensions.top = 0
  // dimensions.left = 0
  // dimensions.width = el.offsetWidth
  // dimensions.height = el.offsetHeight

  dimensions.full.top = 0
  dimensions.full.left = 0
  if (elem) {
    dimensions.full.width = elem.offsetWidth
    dimensions.full.height = elem.offsetHeight
  }
  dimensions.element.width = elDetail.width
  dimensions.element.height = elDetail.height
  dimensions.element.top = elDetail.top
  dimensions.element.left = elDetail.left

  // } else {
  //   dimensions.width = elDetail.width
  //   dimensions.height = elDetail.height
  //   dimensions.top = elDetail.top
  //   dimensions.left = elDetail.left
  // }

  let loc = {
    id: command_id,
    command: command,
    value: command_value,
    target: string_target,
    insights: {humanLabel: humanLabel},
    // targets: command_targets,
    // insights: {"name": "special"}
  }

  // chrome.runtime.sendMessage({
  //   uri: '/record/command',
  //   verb: 'put',
  //   // command: loc["id"],
  //   // target: "an initial target",
  //   // value: "an initial value",
  //   // select: false,
  //   payload: loc,
  // })

  // console.log('result: ', {
  //   tab_id: tab_id,
  //   id: command_id,
  //   css_target: css_target,
  //   parsed_target: parsed_target,
  //   target: string_target,
  //   command: command,
  //   outerHtml: outerHtml,
  //   elDetail: elDetail,
  //   dimensions: dimensions,
  // })

  return {
    tab_id: tab_id,
    id: command_id,
    css_target: css_target,
    parsed_target: parsed_target,
    target: string_target,
    command: command,
    outerHtml: outerHtml,
    pageUrl: pageURL,
    elDetail: elDetail,
    dimensions: dimensions,
    method: method,
  }
}

function createXPathFromElement(elm) {
  let allNodes = document.getElementsByTagName('*');
  let segs = [];
  for (segs = []; elm && elm.nodeType === 1; elm = elm.parentNode)
  {
    if (elm.hasAttribute('id')) {
      let uniqueIdCount = 0;
      for (let n=0;n < allNodes.length;n++) {
        if (allNodes[n].hasAttribute('id') && allNodes[n].id === elm.id) uniqueIdCount++;
        if (uniqueIdCount > 1) break;
      };
      if ( uniqueIdCount === 1) {
        segs.unshift('id("' + elm.getAttribute('id') + '")');
        return segs.join('/');
      } else {
        segs.unshift(elm.localName.toLowerCase() + '[@id="' + elm.getAttribute('id') + '"]');
      }
    } else if (elm.hasAttribute('class')) {
      segs.unshift(elm.localName.toLowerCase() + '[@class="' + elm.getAttribute('class') + '"]');
    } else {
      for (i = 1, sib = elm.previousSibling; sib; sib = sib.previousSibling) {
        if (sib.localName === elm.localName)  i++; };
      segs.unshift(elm.localName.toLowerCase() + '[' + i + ']');
    };
  };
  return segs.length ? '/' + segs.join('/') : null;
};
