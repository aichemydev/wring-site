const SERVER_API_URL = "https://dev.wring.dev/interceptor"
const UI_URL = "https://beta.quikly.dev/"