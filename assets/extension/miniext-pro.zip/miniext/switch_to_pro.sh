#!/usr/bin/env bash

cp manifest.pro.json manifest.json
cp config.pro.json config.json
