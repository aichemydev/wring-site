const GOLDEN_PATH_CLASSNAME = "crx_golden_path"; // Unique ID for the className.
let prevDOM = null; // Previous dom, that we want to track, so we can remove the previous styling.
let qlyIndicatorContainer = document.createElement("DIV"); // The indicator container
// let golden_paths = [];
console.log("PRODUCT VERSION: ", window.wring_version);
let dropDownStatus = "closed";

const render = () => {
  let qlyAppContainer = document.createElement("DIV"); // The indicator container
  qlyAppContainer.id = "qly-app";
  document.querySelector("html").appendChild(qlyAppContainer);
  let line_awesome = document.createElement("link"); // The indicator container
  line_awesome.rel = "stylesheet"
  line_awesome.href = "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css"
  document.querySelector("head").appendChild(line_awesome);
  const _parent = document.getElementById("qly-app");
  const wring_logo = chrome.runtime.getURL("/logo/logo-16.png");
  // Commented this out until Biya is ready with the login
  const _logged = false;
  // const _logged = true;
  const _error = sessionStorage.getItem("qly-login-error")
    ? `<div class="qly--alert_danger">
      An error has occurred while login, please check credentials
      or network!
    </div>`
    : ``;

  _logged && localStorage.removeItem("qly-user");
  _error.length > 3 && sessionStorage.removeItem("qly-login-error");
  _parent.innerHTML = !_logged
    ? `<div id="qly--headless--container" class="qly--container--login">
    <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
    <span class="qly--indicator_close ph-no-capture" id="qly-container-closer">x</span>
      <div id="Login-show" >
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <h1> PM Assist </h1>
          <p> Powerful product assistant  </p>
        </div>
        <form id="login-form" class="qly--app_login" action="" >
          <p class="qly-para">Sign in with</p>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary">
              <span class="ico-btn">
                <i class="lab la-github"></i>
              </span>
              <span class="text-btn">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <i class="lab la-google"></i>
              </span>
              <span class="text-btn">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <p class="qly-para">Or sign in with credentials</p>
            ${_error}
            <div id="alert_danger" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-envelope"></i>
              </span>
              <input type="email" name="email" placeholder="Enter Email" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-lock"></i>
              </span>
              <input type="password" name="password"  placeholder="Enter Password" required />
            </div>
            <div class="qly--ipt_group_remember f--center">
              <input title="remember-check" type="checkbox" name="remember"/>
              <span>Remember me ?</span>
            </div>
      
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <i class="las la-sign-in-alt"></i>
              </span>
              <span class="text-btn">Sign In</span>
            </button>
          </div>
        </form>
        <div class="create-forgot">
          <div class="after--link">
          <a id="link-forgot-password" rel="noreferrer" href="#">
          Forgot password?
          </a>
          </div>
          <div class="after--link">
            <a id="link-create-new-account" rel="noreferrer" href="#">
              Create new account »
            </a>
          </div>
        </div>
      </div>
      <div id="create-new-account" style="display: none;">
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <h1> Create an account </h1>
          <p> Sign up for PM Assist</p>
        </div>
        <form id="create-new-account-form" class="qly--app_login" action="" >
          <p class="qly-para">Sign in with</p>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary">
              <span class="ico-btn">
                <i class="lab la-github"></i>
              </span>
              <span class="text-btn">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <i class="lab la-google"></i>
              </span>
              <span class="text-btn">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <p class="qly-para">Or sign in with credentials</p>
            ${_error}
            <div id="alert_danger_create" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-user"></i>
              </span>
              <input type="text" name="full_name" placeholder="Enter Full Name" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-envelope"></i>
              </span>
              <input type="email" name="email" placeholder="Enter Email" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-lock"></i>
              </span>
              <input type="password" name="password" placeholder="Enter Password" required />
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-lock"></i>
              </span>
              <input type="password" name="confirm_password" placeholder="Confirm Password" required />
            </div>
            <div class="qly--ipt_group_remember f--center">
              <input title="remember-check" type="checkbox" name="terms_conditions" required />
              <span>I agree with the <a target="_blank" href="${UI_URL}service-agreement"> Terms and conditions</a></span>
            </div>
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <i class="las la-sign-in-alt"></i>
              </span>
              <span class="text-btn">Create account</span>
            </button>
          </div>
        </form>
          <div class="create-forgot">
            <div class="after--link">
              Have an account? <a id="link-login-show" rel="noreferrer" href="#">
                Login
              </a>
            </div>
          </div>
      </div>
      <div id="forgot-password" style="display: none;">
        <div class="qly--login--header " >
          <img width="25%" src="${wring_logo}" />
          <h1> PM Assist </h1>
        </div>
        <form id="forgot-password-form" class="qly--app_login" action="">
          <p class="qly-para">Sign in with</p>
          <div class="qly--other_auth">
            <div id="github-login" class="ico--btn secondary >
              <span class="ico-btn">
                <i class="lab la-github"></i>
              </span>
              <span class="text-btn">Github</span>
            </div>
            <div id="google-login" class="ico--btn danger">
              <span class="ico-btn">
                <i class="lab la-google"></i>
              </span>
              <span class="text-btn">Google</span>
            </div>
          </div>
          <div class="qly--ipt_container">
            <p class="qly-para">Or reset your password</p>
            ${_error}
            <div id="alert_danger_forgot_password" >
            </div>
            <div class="qly--ipt_group">
              <span class="ipt--append">
                <i class="las la-envelope"></i>
              </span>
              <input type="email" name="email" placeholder="Enter Email" required />
            </div>
            <button type="submit" class="ico--btn info">
              <span class="ico-btn">
                <i class="las la-sign-in-alt"></i>
              </span>
              <span class="text-btn">Send Password Reset Link</span>
            </button>
          </div>
        </form>
          <div class="create-forgot">
            <div class="after--link">
              <a id="p--link-login-show" rel="noreferrer" href="#">
                Login
              </a>
            </div>
            <div class="after--link">
              <a id="p--link-create-new-account" rel="noreferrer" href="#">
                Create new account »
              </a>
            </div>
          </div>
      </div>
    </div>`
    : `<header class="qly--header">
      <h2>PM Assist</h2>
      <h4 class="qly--small_txt">Powerful product assistant</h4>
    </header>
    <main class="qly--main">
      <input class="" alt="start" type="image" id="start" width="25%" src="/logo/logo-16.png"></input>
      
    </main>`;

    if (document.getElementById("qly-container-closer")) {
      document
        .getElementById("qly-container-closer")
        .addEventListener("click", (e) => {
          let elt = document.getElementById("qly--headless--container");
          console.log(elt)
          if (elt) {
            elt.style.display = "none";
            clearHeatMap();
            chrome.storage.local.set({ recording: false });
            chrome.storage.local.set({ activated: false });
          }
        });
    }
  if( document.getElementById("link-create-new-account")){
    document
      .getElementById("link-create-new-account")
      .addEventListener("click", (e) => {
        console.log("register")
        showContentLogin("register")
      });
  }
  if( document.getElementById("link-login-show")){
    document
      .getElementById("link-login-show")
      .addEventListener("click", (e) => {
        console.log("login")
        showContentLogin("login")
      });
  }
  if( document.getElementById("p--link-create-new-account")){
    document
      .getElementById("p--link-create-new-account")
      .addEventListener("click", (e) => {
        console.log("register")
        showContentLogin("register")
      });
  }
  if( document.getElementById("p--link-login-show")){
    document
      .getElementById("p--link-login-show")
      .addEventListener("click", (e) => {
        console.log("login")
        showContentLogin("login")
      });
  }
  if( document.getElementById("link-forgot-password")){
    document
      .getElementById("link-forgot-password")
      .addEventListener("click", (e) => {
        console.log("password")
        showContentLogin("password")
      });
  }

  if( document.getElementById("forgot-password-form")){
    document
      .getElementById("forgot-password-form")
      .addEventListener("submit", (e) => {
        console.log("forgot-password-form")
        e.preventDefault();
      });
  }
  if( document.getElementById("create-new-account-form")){
    document
      .getElementById("create-new-account-form")
      .addEventListener("submit", (e) => {
        console.log("create-new-account-form")
        e.preventDefault();
        register()
      });
  }
  if( document.getElementById("login-form")){
    document
      .getElementById("login-form")
      .addEventListener("submit", (e) => {
        console.log("login-form")
        e.preventDefault();
        login()
      });
  }
  if( document.getElementById("github-login")){
    document
      .getElementById("github-login")
      .addEventListener("click", (e) => {
        githubLogin()
      });
  }
  if( document.getElementById("google-login")){
    document
      .getElementById("google-login")
      .addEventListener("click", (e) => {
        googleLogin()
      });
  }
  if(document.getElementById("forgot-password-form")){
    document
      .getElementById("forgot-password-form")
      .addEventListener("submit", (e) => {
        console.log(" hunter forgot-password-form")
        e.preventDefault();
        forgotPassword()
      });
  }
};

//#region document events
document.addEventListener("keyup", function (e) {
  // var e = e || window.event; //! for IE to cover IEs window event-object
  if (e.ctrlKey && e.key === "k") {
    hideShowRecorderPanel();
    return false;
  }
});

document.addEventListener(
  "click",
  function (e) {
    if(e.srcElement.id === "qly-MinimizeTable"){
      MinimizeTable("MinimizeTable");
    }
    if(e.srcElement.id === "qly-MaximizeTable"){
      MinimizeTable("MaximizeTable");
    }
    if(e.srcElement.classList.contains("editFunnels")){
      editFunnels(e);
    }
    if(e.srcElement.classList.contains("deleteFunnels")){
      deleteFunnels(e);
    }
    // Do what you want with click event
    // console.log("We got a click event: ", e);
    // e.stopPropagation();

    chrome.storage.local.get("funnel", (data) => {
      if (data["funnel"]) {
        // let golden_paths = sessionStorage.getItem("funnels");
        // console.log("golden_paths: ", golden_paths);
        // if (golden_paths) {
        // }
        // else {
        //   golden_paths = JSON.parse(golden_paths);
        // }

        console.log("In funnel mode, we can DRAW the funnels now");
        // let funnel_storage = sessionStorage.getItem("funnels");
        // console.log("funnel_storage: ", funnel_storage);
        let golden_paths = JSON5.parse(sessionStorage.getItem("funnels"));
        console.log("golden_paths: ", golden_paths);
        if (!golden_paths) {
          golden_paths = [];
        }
        // if (
        //   golden_paths && !golden_paths.length ||
        //   (golden_paths && golden_paths.length && golden_paths.at(-1) !== e.srcElement)
        // ) {
        if (!e.srcElement.classList.contains("ph-no-capture")) {
          let abs_xpath = xpath(e.srcElement);
          let outer_html = e.srcElement.outerHTML;
          // console.log("abs_xpath: ", abs_xpath);
          // console.log("outer_html: ", outer_html);
          // console.log("Abs Xpath of element is: ", createXPathFromElement(e.srcElement));
          // golden_paths.push(e.srcElement);
          golden_paths.push({
            "url": window.location.href,
            // xpath: abs_xpath,
            "xpath": abs_xpath,
            human_label: getDeepComputedLabel(e.srcElement),
            // "human_label": getComputedLabel(e.srcElement),
            // outer_html: outer_html
          });
          // golden_paths.push(e.srcElement.outerHTML);
          // golden_paths.push(e.srcElement.outerHTML);
          console.log("golden_paths: ", golden_paths);
          
          sessionStorage.setItem("funnels", JSON.stringify(golden_paths));
          // e.srcElement.classList.add(GOLDEN_PATH_CLASSNAME);
          e.srcElement.classList.add("qly_funnel_element");
          refreshTableFunnel()
        }

      }
    });
  },
  false
);
//#endregion

//#region functions
async function forgotPassword(){
  let _error = document.getElementById("alert_danger_forgot_password")
  const from = document.getElementById("forgot-password-form")
  const baseUrl = SERVER_API_URL ? SERVER_API_URL : "https://dev.wring.dev/interceptor" ;
  toggleIndicatorLoader();
  try {
    await fetch(`${baseUrl}/auth/v1/users/password/forgot`,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: from.elements["email"].value,
      })
    })
    .then(response => response.json())
    .then( data => {
      if(!data || data.status === "failed"){
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = data.message
        _error.style.display = "block"
        return 
      }else if(data.status === "success"){
        from.elements["email"].value = ""
        showContentLogin("login")
        let _succes = document.getElementById("alert_danger")
        _succes.classList.add("qly--alert_success");
        _succes.innerHTML = data.message
        _succes.style.display = "block"
        console.log(_error)
      }
    })
  } catch (error) {
    console.log(error)
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
  }
  toggleIndicatorLoader()
}

async function login() {
  toggleIndicatorLoader();
  const from = document.getElementById("login-form")
  if(from.elements["email"].value.length < 1){
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Email required !"
    _error.style.display = "block"
    return 
  }
  // qly--alert_danger
  if(from.elements["password"].value.length < 1){
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Password required!"
    _error.style.display = "block"
    return 
  }
  const baseUrl = SERVER_API_URL ? SERVER_API_URL : "https://dev.wring.dev/interceptor" ;
  try {
    await fetch(`${baseUrl}/auth/v1/users/login`,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: from.elements["email"].value,
        password: from.elements["password"].value,
      })
    })
    .then(response => response.json())
    .then( data => {
      if(!data || data.status === "failed"){
        toggleIndicatorLoader();
        let _error = document.getElementById("alert_danger")
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = "An error has occurred while login, please check credentials or network!"
        _error.style.display = "block"
        return 
      }else{
        chrome.storage.local.set({"qly-user":data.response.access_token})
        let elt = document.getElementById("qly-indicator-loader");
        elt.style.display = "none";
        document.getElementById("qly-app").remove()
        renderIndicator()
      }
    })
  } catch (error) {
    console.log(error)
    console.log(error)
    let _error = document.getElementById("alert_danger")
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
    toggleIndicatorLoader()
  }
}

async function googleLogin(){
  const baseUrl = SERVER_API_URL ? SERVER_API_URL: "https://dev.wring.dev/interceptor" ;
  chrome.runtime.sendMessage({
    message: "command",
    action: "extraLogin",
    url: baseUrl +  "/auth/v1/oauth2/custom/google",
  });
}

async function githubLogin(){
  const baseUrl = SERVER_API_URL ? SERVER_API_URL: "https://dev.wring.dev/interceptor" ;
  chrome.runtime.sendMessage({
    message: "command",
    action: "extraLogin",
    url: baseUrl +  "/auth/v1/oauth2/custom/github",
  });
}

async function logout(){
  toggleIndicatorLoader();
  console.log('logout')
  const baseUrl = SERVER_API_URL ? SERVER_API_URL : "https://dev.wring.dev/interceptor";
  chrome.storage.local.get("qly-user", (data) => {

    try {
      fetch(`${baseUrl}/auth/v1/users/logout`,{
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${data["qly-user"]}`
        }
      })
      .then(response => response.json())
      .then( data => {
        if(!data || data.status === "success"){
          chrome.storage.local.remove("qly-user")
          document.getElementById("headless-recorder-overlay").remove()
          render()
          chrome.storage.local.set({ funnel: false });
          clearGoldenPaths(true);
          chrome.storage.local.set({ recording: false});
          sessionStorage.removeItem("funnels")
        }
      })
    } catch (error) {
      console.log(error)
      toggleIndicatorLoader();
    }
  } ) 

}

async function register() {
  const from = document.getElementById("create-new-account-form")
  const passwrdRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
  let _error = document.getElementById("alert_danger_create")
  _error.classList.add("qly--alert_danger");
  _error.style.display = "none"
  if(!passwrdRegex.test(from.elements['password'].value)){
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "the password must be at least 8 characters long and contain at least one number and one special character !"
    _error.style.display = "block"
    return 
  }
  if(from.elements['password'].value != from.elements['confirm_password'].value){
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "Passwords did not match!"
    _error.style.display = "block"
    return 
  }

  const baseUrl = SERVER_API_URL ? SERVER_API_URL : "https://dev.wring.dev/interceptor" ;
  toggleIndicatorLoader();
  try {
    await fetch(`${baseUrl}/auth/v1/users/new`,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        fullName: from.elements["full_name"].value,
        email: from.elements["email"].value,
        password: from.elements["password"].value,
        confirmPassword: from.elements["confirm_password"].value,
      })
    })
    .then(response => response.json())
    .then( data => {
      if(!data || data.status === "failed"){
        _error.classList.add("qly--alert_danger");
        _error.innerHTML = data.message
        _error.style.display = "block"
        return 
      }else if(data.status === "success"){
        from.elements["full_name"].value = ""
        from.elements["email"].value = ""
        from.elements["password"].value = ""
        from.elements["confirm_password"].value = ""
        showContentLogin("login")
        let _succes = document.getElementById("alert_danger")
        _succes.classList.add("qly--alert_success");
        _succes.innerHTML = ""
        _succes.innerHTML = data.message
        _succes.style.display = "block"
        console.log(_error)
      }
    })
  } catch (error) {
    console.log(error)
    _error.classList.add("qly--alert_danger");
    _error.innerHTML = "an error has occurred "
    _error.style.display = "block"
  }
  toggleIndicatorLoader()

}

function norm(value, min, max) {
  return (value - min) / (max - min);
}

const dragElt = (dom, domChild) => {
  let pos1 = 0;
  let pos2 = 0;
  let pos3 = 0;
  let pos4 = 0;

  const eltDrag = (e) => {
    e.preventDefault();

    const _domHeight = dom.getBoundingClientRect().height;

    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    dom.style.top = `${dom.offsetTop - pos2}px`;
    dom.style.left = `${dom.offsetLeft - pos1}px`;
  };

  const closeDragElt = () => {
    document.removeEventListener("mousemove", eltDrag);
    document.removeEventListener("mouseup", closeDragElt);
  };

  const dragMouseDown = (e) => {
    e.preventDefault();

    pos3 = e.clientX;
    pos4 = e.clientY;

    document.addEventListener("mouseup", closeDragElt);
    document.addEventListener("mousemove", eltDrag);
  };

  domChild.addEventListener("mousedown", dragMouseDown);
};

function renderIndicator(rec) {
  console.log("dbahgabkjbdkhvasvhjghjasvjhg")
  let line_awesome = document.createElement("link"); // The indicator container
  line_awesome.rel = "stylesheet"
  line_awesome.href = "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css"
  document.querySelector("head").appendChild(line_awesome);
  chrome.storage.local.get("recording", (data) => {
    if (typeof rec === undefined) {
      sessionStorage.setItem("current-rec-value", data["recording"]);
    }
  });


  let recVal = rec ? rec : sessionStorage.getItem("current-rec-value");
  let icon = recVal
    ? chrome.runtime.getURL("/images/qly_pause.svg")
    : chrome.runtime.getURL("/images/qly_record.svg");
  let quikly_logo = chrome.runtime.getURL("/logo/logo-16.png");
  let heatmap_icon = chrome.runtime.getURL("/images/qly_heatmap.svg");
  let funnel_icon = chrome.runtime.getURL("/images/qly_funnel.svg");
  let screenshot_icon = chrome.runtime.getURL(
    "/images/qly_screenshot_icon.svg"
  );
  let logout_icon = chrome.runtime.getURL(
    "/images/qly_lougot.svg"
  );

  let _extraClass =
    window.wring_version === "designer" ? "qly--need_upgrade" : "";
  let _height = recVal ? "82px" : "55px";
  let _header = recVal
    ? `<header class="qly--indicator_head ph-no-capture">
        <div class="qly--ring_container ph-no-capture">
          <div class="qly--ring_elt ph-no-capture"></div>
          <div class="qly--ring_circle ph-no-capture"></div>
        </div>
        <span class="qly--indicator_head_txt ph-no-capture">Recording ...</span>
      </header>`
    : ``;

  qlyIndicatorContainer.innerHTML = `<div id="headless-recorder-overlay" class="qly--indicator_container ph-no-capture" data-v-app="" style="display: none; height: ${_height}">
    <div id="qly-indicator-content" class="qly--indicator_content ph-no-capture">
      <span class="qly--indicator_close ph-no-capture" id="qly-indicator-closer">x</span>
      ${_header}
      <main class="qly--indicator_main ph-no-capture">
        <span id="action_btn" class="qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Record" class="ph-no-capture" title="Observe" src="${icon}" />
        </span>
        <span id="heatmap_view"  class="qly--heatmap_button_off qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Heatmap"  class="ph-no-capture" title="Session map" src="${heatmap_icon}" />
        </span>
        <span id="funnel_view" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Funnel" class="ph-no-capture" title="Funnels" src="${funnel_icon}" />
        </span>
        <span class="qly--indicator_v_divider ph-no-capture"></span>
        <span id="screenshot_btn" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture">
          <img alt="Screenshot" class="ph-no-capture" title="Screenshot" src="${screenshot_icon}" />
        </span>
        <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
        <div class="qly--indicator_extra ph-no-capture"></div>
        <div class="qly--indicator_extra ph-no-capture dropup" id="projectSelectParent">
            <div id="projectSelectButton" class="qly--indicator_btn ph-no-capture ${_extraClass} qly--indicator_btn_project">
              <i class="las la-bars ph-no-capture" ></i>
              <div class="qly--indicator_dropdown_menu ph-no-capture" id="projectDropList" style="display: none;"> 
                <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader_project" ><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
                <div id="projectDropList_content" > </div>
              </div>
            </div>
            <ul class="dropdown-menu qly--indicator_extra ph-no-capture" id="projectDropList2" aria-labelledby="dropdownMenuButton">
            </ul>
            
            
            
        </div>
        <div class="qly--indicator_extra ph-no-capture"></div>

         <img alt="Logo" class=" ph-no-capture" title="Quikly" id="qly--logo" src="${quikly_logo}" width="32" />
        <div class="qly--indicator_log_link" id="qly-indicator_log_link" style="display: none;"> 
          <a href="${UI_URL}" target="_blank" class="qly--content_log_link ph-no-capture" > 
            <img alt="Logo" class=" ph-no-capture" title="Quikly" src="${quikly_logo}" width="20" />
            <span class="ph-no-capture"> Home</span>
          </a>
          <div class="qly--content_log_link ph-no-capture" id="logout_btn" > 
            <i class="las la-power-off" class="ph-no-capture"></i>
            <span class="ph-no-capture"> Log out</span>
          </div>
        </div>
        </main>
        </div>
        <form id="funnel-form" class="qly--app_funnel ph-no-capture" style="display: none; action="" >
          <h3 class="ph-no-capture">Edit step</h3>
          <div class="qly--ipt_container">
            <div class="qly--ipt_group_funnel ph-no-capture ">
              <label class="ipt--append ph-no-capture">
                Action
              </label>
              <input class="ph-no-capture" type="text" name="action"  disabled />
            </div>
            <div class="qly--ipt_group_funnel ph-no-capture">
              <label class="ipt--append ph-no-capture">
                Label
              </label>
              <input class="ph-no-capture" type="text" name="element" />
            </div>
            <div class="qly--ipt_group_funnel ph-no-capture">
              <label class="ipt--append ph-no-capture">
                Value
              </label>
              <input class="ph-no-capture" type="text" name="value" disabled />
            </div>
            <input type="hidden" name="index"   />
            <div style=" display: flex; justify-content: right;" class="ph-no-capture"">
              <button id="saveFormEditStep" type="submit" class="ico--btn info ph-no-capture">
                <span class="ico-btn ph-no-capture"">
                  <i class="las la-save ph-no-capture""></i>
                </span>
                <span class="text-btn ph-no-capture"">Save</span>
              </button>
              <button type="submit" class="ico--btn danger ph-no-capture" id="colseFormEditStep">
                <span class="ico-btn ph-no-capture"">
                  <i class="las la-times-circle ph-no-capture""></i>
                </span>
                <span class="text-btn ph-no-capture"">Cancel</span>
              </button>
            </div>
          </div>
        </form>
        <form id="funnel-form-save" class="qly--app_funnel ph-no-capture" style="display: none; action="" >
        <span class="qly--indicator_close ph-no-capture" id="qly-indicator-closer_save_funnel">x</span>
          <h3>Save funnel</h3>
          <div id="alert_danger_save_funnel" >
          </div>
          <div class="qly--ipt_container">
            <label class="ipt--append">
             The funnel
            </label>
            <div class="qly--ipt_group_funnel" ph-no-capture>
              <input class="ph-no-capture" type="text" name="name_funnel" required />
              <button id="saveBtnFunnel" type="submit" class="ico--btn info ph-no-capture">
                <span class="ico-btn ph-no-capture"">
                  <i class="las la-save ph-no-capture""></i>
                </span>
                <span class="text-btn ph-no-capture"">Save</span>
              </button>
            </div>
          </div>
        </form>
        <div id="listFunnel" class="qly--app_funnel ph-no-capture" style="display: none;">
          <span class="qly--indicator_close ph-no-capture" id="proccesListFunnel_close" >x</span>
          <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader--listFunnel" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
          <input id="process_search-funnel" class="ph-no-capture search--input" type="text" name="value" placeholder="Search for a funnel by name" />
          <ul class="content--list--funnel ph-no-capture" aria-labelledby="dropdownMenuButton">
          </ul>
        </div>
        <table style="display:none" id="qly--funnel_list" class="qly--funnel_list_container ph-no-capture">
        <thead class="ph-no-capture">
            <tr>
              <th style="width: 10%;" class="ph-no-capture"></th>
              <th style="width: 70%;" class="ph-no-capture">Value</th>
              <th style="width: 20%;" class="ph-no-capture">

                <i id="proccesSaveFunnel" class="las la-save icon--table ph-no-capture"></i>
                <i id="proccesListFunnel" class="las la-chevron-down icon--table ph-no-capture"></i>
                <div class="MinimizeTable ph-no-capture">
                <i id="qly-MaximizeTable" class="las la-plus-circle qly--maximiza ph-no-capture"></i>
                <i id="qly-MinimizeTable" class="las la-minus-circle qly--minimiza ph-no-capture"></i>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
  </div>`;
  chrome.storage.local.get("funnel", (data) => {
    if(data['funnel'] === true && sessionStorage.getItem("funnels") && sessionStorage.getItem("funnels").length > 0){
      refreshTableFunnel()
      document
      .getElementById("funnel_view")
      .classList.remove("qly--heatmap_button_off");
    }
  })

  if (
    sessionStorage.getItem("qly-indicator-pos-b") &&
    sessionStorage.getItem("qly-indicator-pos-l")
  ) {
    qlyIndicatorContainer.firstChild.style.top =
      sessionStorage.getItem("qly-indicator-pos-b") + "px";
    qlyIndicatorContainer.firstChild.style.left =
      sessionStorage.getItem("qly-indicator-pos-l") + "px";
  }

  //#region indicator handlers
  if (!document.getElementById("headless-recorder-overlay")) {
    document.querySelector("body").appendChild(qlyIndicatorContainer);
    dropDownStatus = "closed";
  }
  // <div className="qly--container" id="qly-app"></div>
  // let qlyAppContainer = document.createElement("DIV"); // The indicator container
  // qlyAppContainer.id = "qly-app";
  
  // document.querySelector("body").appendChild(qlyAppContainer);
  
  // Uncomment this to see how ugly the CSS is
  // render();
  const myDropdown = document.getElementById('projectSelectButton')
  if(myDropdown){
    myDropdown.addEventListener('click', () => {
      // console.log("Dropdown opened!");
      dropDownStatus = (dropDownStatus === "open") ? "closed" : "open";

      const projectDropList = document.getElementById('projectDropList');
      let loader = document.getElementById("qly-indicator-loader_project")
      if(loader)
        loader.style.display = 'inline-flex'
      if (dropDownStatus === "open") {
        projectDropList.style.display = "block"
        chrome.runtime.sendMessage( {message: "command", payload: "projects"}, function (response) {
            console.log("Got response: ", response);
            const projectDropList_content = document.getElementById("projectDropList_content")
            projectDropList_content.replaceChildren();
            // projectDropList_content.appendChild()
            if(response.payload.response){
              loader.style.display = 'none'
              for (let el of response.payload.response) {
                // console.log("Response: ", el);
                const li = document.createElement("li");
                li.setAttribute('id', el.projectId);
                li.classList.add("dropdown-item");
                li.classList.add("ph-no-capture");
                li.appendChild(document.createTextNode(el.name));
                li.addEventListener('click', function handleClick(event) {
                  console.log('project clicked:', event);
                  sessionStorage.setItem("qly-project-id", event.target.id);
                  console.log('Selected Project id: ', sessionStorage.getItem("qly-project-id"));
                });
                projectDropList_content.appendChild(li);
              }
            }
          }
        );
      }
      else {
        projectDropList.style.display = "none"
        console.log("Updated dropDownstatus: ", dropDownStatus);
      }

    })
  }
  
  if (document.getElementById("headless-recorder-overlay")) {
    const _indicatorContainer = document.getElementById(
      "headless-recorder-overlay"
    );

    if (document.getElementById("qly-indicator-content")) {
      const _indicatorContent = document.getElementById(
        "qly-indicator-content"
      );
      if (_indicatorContainer && _indicatorContent) {
        dragElt(_indicatorContainer, _indicatorContent);
      }
    }
  }

  if (document.getElementById("qly-indicator-closer")) {
    document
      .getElementById("qly-indicator-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("headless-recorder-overlay");

        if (elt && elt.style.display === "block") {
          clearGoldenPaths(true);
          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
          elt.style.display = "none";
        }
      });
  }
  if (document.getElementById("qly-container-closer")) {
    document
      .getElementById("qly-container-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("qly--headless--container");
        console.log(elt)
        if (elt) {
          elt.style.display = "none";
          clearHeatMap();
          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
        }
      });
  }
  if(document.getElementById("qly-indicator-closer_save_funnel")){
    document
      .getElementById("qly-indicator-closer_save_funnel")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("funnel-form-save");
        elt.style.display = "none";
      });
  }
  if (document.getElementById("funnel_view")) {
    document
      .getElementById("funnel_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showFunnel();
      });
  }

  if (document.getElementById("heatmap_view")) {
    document
      .getElementById("heatmap_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showHeatMap();
      });
  }

  if (document.getElementById("action_btn")) {
    document
      .getElementById("action_btn")
      .addEventListener("click", function (e) {
        let elt = document.getElementById("headless-recorder-overlay");
        let _l = elt.getBoundingClientRect().left;
        let _b = elt.getBoundingClientRect().bottom - 70;
        
        sessionStorage.setItem("qly-indicator-pos-b", _b);
        sessionStorage.setItem("qly-indicator-pos-l", _l);
        
        if (window.wring_version === "pro") {
          console.log("hfabhjabhbfhjab",chrome.storage.local.get("funnel"))
          chrome.storage.local.get("funnel", (data) => {
            if(data['funnel'] === true ){
              console.log("b nb dnmvbv anmbvmnabvbjka",data['funnel'])
              chrome.storage.local.set({ funnel: false });
              clearGoldenPaths(true);
              document
              .getElementById("funnel_view")
              .classList.remove("qly--heatmap_button_off");
            }
          })
          chrome.storage.local.get("recording", (data) => {
            chrome.storage.local.set({ recording: !data["recording"] });
            document.querySelector("body").removeChild(qlyIndicatorContainer);
            renderIndicator(!data["recording"]);
          });
        }
      });
  }
  if (document.getElementById("screenshot_btn")) {
    document
      .getElementById("screenshot_btn")
      .addEventListener("click", (e) => {
        fullPageScreenshot();
      });
  }
  if (document.getElementById("logout_btn")) {
    document
      .getElementById("logout_btn")
      .addEventListener("click", (e) => {
        logout();
      });
  }
  if(document.getElementById("qly--logo")){
    document
      .getElementById("qly--logo")
      .addEventListener("click", (e) => {
        toggleIndicatorLogo();
      });
  }
  if(document.getElementById("colseFormEditStep")){
    document
      .getElementById("colseFormEditStep")
      .addEventListener("click", (e) => {
        e.preventDefault()
        document.getElementById("funnel-form").style.display = "none"
      });
  }
  if(document.getElementById("saveFormEditStep")){
    document
      .getElementById("saveFormEditStep")
      .addEventListener("click", (e) => {
        e.preventDefault()
        document.getElementById("funnel-form").style.display = "none"
        saveFormEditStep()
      });
  }
  if(document.getElementById("proccesSaveFunnel")){
    document
      .getElementById("proccesSaveFunnel")
        .addEventListener("click", (e) => {
          e.preventDefault()
          document.getElementById("alert_danger_save_funnel").innerHTML = ""
          document.getElementById("funnel-form-save").style.display = "flex"
        });
  }
  if(document.getElementById("proccesListFunnel")){
    document
      .getElementById("proccesListFunnel")
        .addEventListener("click", (e) => {
          e.preventDefault()
          const el = document.getElementById("listFunnel")
          if(el.style.display === "block"){
            el.style.display = "none"
            document.getElementById("qly-indicator-loader--listFunnel").style.display = "none"
          }else{
            let project_id = sessionStorage.getItem("qly-project-id");
            if(!project_id){
              alert("you should select a project before liste a funnel!")
              return
            }
            el.style.display = "block"
            showListFunnel()
          }
        });
  }
  if(document.getElementById("proccesListFunnel_close")){
    document
      .getElementById("proccesListFunnel_close")
        .addEventListener("click", (e) => {
          e.preventDefault()
          const el = document.getElementById("listFunnel")
          el.style.display = "none"
          document.getElementById("qly-indicator-loader--listFunnel").style.display = "none"
        });
  }
  if(document.getElementById("saveBtnFunnel")){
    document
      .getElementById("saveBtnFunnel")
      .addEventListener("click", (e) => {
        e.preventDefault()
        saveFunnel()
      })
  }
  if(document.getElementById("process_search-funnel")){
    document
      .getElementById("process_search-funnel")
      .addEventListener("input", (e) => {
        e.preventDefault()
        searchFunnel(e)
      })
  }
  //#endregion

  showRecorderPanel();
  sessionStorage.removeItem("current-rec-value");
}

function clearGoldenPaths(reset = false) {
  let boxes = document.querySelectorAll("." + GOLDEN_PATH_CLASSNAME);
  boxes.forEach((box) => {
    box.classList.remove(GOLDEN_PATH_CLASSNAME);
  });

  $("#qly--funnel_list").hide();

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  clearHeatMap();
  if (reset) {
    // golden_paths = [];
    sessionStorage.removeItem("funnels");
    boxes = document.querySelectorAll(".qly_funnel_element");
    boxes.forEach((box) => {
      box.classList.remove("qly_funnel_element");
    });
  }
}

function clearHeatMap() {
  let displayed = false;
  console.log("Calling clearHeatMap");

  let boxes = document.querySelectorAll(".qly_heatmap_element_hover");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element_hover");
  });

  document.querySelectorAll(".qly--elt_circle_bg").forEach((box) => {
    box.remove();
  });

  boxes = document.querySelectorAll(".qly_heatmap_element");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element");
  });

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  });

  // chrome.storage.local.set({ heatmap: false });
  return displayed;
}
function MinimizeTable(status){
  let table = document.getElementById("qly--funnel_list")
  if(status== "MaximizeTable"){
    table.classList.remove("qly--funnel_list_minimaze")
  }else{
    table.classList.add("qly--funnel_list_minimaze")
  }
}
async function deleteFunnels(el){
  const confirm = await window.confirm(`Are you sure you want to delete step ${el.target.id } (No. of actual step)?`)
  if(confirm){
    let golden_paths = await JSON5.parse(sessionStorage.getItem("funnels"));
    let newgolden_paths = golden_paths.filter( (ls ,index) => {
      if(index != (el.target.id - 1)){
        return ls
      }
    })
    await sessionStorage.setItem("funnels", JSON5.stringify(newgolden_paths));
    refreshTableFunnel()

  }
}
async function saveFormEditStep(el){
  let colm =  document.getElementById(`qly-datatableColum_${el.target.id}`)

  let golden_paths = await JSON5.parse(sessionStorage.getItem("funnels"));
  const index = el.target.id - 1
  let golden_paths_new = await golden_paths.map( (item, id) => {
    if(id == index ){
      item.human_label = colm.children[1].innerHTML 
    }
    return item
  })
  sessionStorage.setItem("funnels", JSON5.stringify(golden_paths_new));
  refreshTableFunnel()

}
function editFunnels(el){
  let funnel = JSON5.parse(sessionStorage.getItem("funnels"))[ el.target.id - 1]
  let colm =  document.getElementById(`qly-datatableColum_${el.target.id}`)
  let editBtn = colm.lastChild.lastChild
  editBtn.classList.remove("la-edit")
  editBtn.classList.remove("las")
  editBtn.classList.remove("editFunnels")
  editBtn.classList.add("las")
  editBtn.classList.add("la-save")
  editBtn.classList.add("saveEditStep")
  colm.children[1].innerHTML = funnel.human_label
  colm.children[1].setAttribute('contentEditable', 'true')
  colm.children[1].focus()
  if(document.getElementsByClassName("saveEditStep")[0]){
    document
      .getElementsByClassName("saveEditStep")[0]
      .addEventListener("click", (e) => {
        e.preventDefault()
        saveFormEditStep(e)
      })
  }
}
function saveFunnel(){
  let project_id = sessionStorage.getItem("qly-project-id");
  if(!project_id){
    document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> you should select a project before saving a funnel!</div>`
    return
  }
  let form = document.getElementById("funnel-form-save")
  const name = form.elements["name_funnel"].value;
  const funnels_arr = JSON.parse(sessionStorage.getItem("funnels"));
  console.log("funnels_arr: ", funnels_arr);

  let funnels_stripped = [];
  
  for (let funnel of funnels_arr) {
    // funnel[""]
    if ("human_label" in funnel) {
      delete funnel["human_label"]
    }
    
    // if ("xpath" in funnel) {
    //   console.log("funnel.xpath: ", funnel["xpath"])
    //   // Add index of element to be in the same format as the backend
    //  
    //   // split_xpath = 
    //   let tokens = funnel["xpath"].split("/");
    //   let modified_xpath_tokens = [];
    //   for (let i in tokens) {
    //     let token = tokens[i];
    //     if (!token.includes("[")) {
    //       // Add a [1] if its not an html tag
    //       if (token !== "html" && token.trim() !== "")
    //       {
    //          token+="[1]";           
    //       }
    //     }
    //     modified_xpath_tokens.push(token);
    //   }
    //   funnel["xpath"] = modified_xpath_tokens.join('/');
    //   // console.log("modified funnel.xpath: ", funnel["xpath"]);
    //
    // }
      funnels_stripped.push(funnel);
    // console.log(funnel);
  }
  
  
  chrome.runtime.sendMessage(
    { message: "command", payload: "funnel", name: name, project_id:project_id, action: "add" , url: window.location.href , funnel: funnels_stripped},
    function (response) {
      // console.log(response.farewell);
      console.log("Got funnel response: ", response);
      if(!response){
        document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> An error has occurred while save funnel, please check credentials or network!</div>`
      }else if(response.payload.status == "failure"){
        document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> ${response.payload.message} </div>`
      }else{
        form.style.display = "none"
      }
    });
}

function showListFunnel(){
  const listFunnel = document.getElementById("listFunnel")
  const ul = listFunnel.children[3]
  ul.replaceChildren()
  const loader = document.getElementById("qly-indicator-loader--listFunnel")
  loader.style.display = "inline-flex"
  // console.log("jwbefsdbbf nmsz cmn mnbz",project_id)
  chrome.runtime.sendMessage( { message: "command", payload: "funnel", project_id:project_id, action: "list" , url: window.location.href}, 
    function (response) {
      console.log("Got response: ", response);
      // projectDropList_content.appendChild()
      if(!response){
        loader.style.display = 'none'
        const li = document.createElement("li");
        li.classList.add("dropdown-item");
        li.classList.add("ph-no-capture");
        li.appendChild(document.createTextNode("No item found"));
        ul.appendChild(li);
        alert("An error has occurred while liste funnel, please check credentials or network!")
      }else if(response.payload.status === "failure"){
        loader.style.display = 'none'
        const li = document.createElement("li");
        li.classList.add("dropdown-item");
        li.classList.add("ph-no-capture");
        li.appendChild(document.createTextNode("no item found"));
        ul.appendChild(li);
        alert(response.payload.message)
      }else if(response.payload.response){
        sessionStorage.setItem("listeFunnel",JSON.stringify(response.payload.response.names))
        loader.style.display = 'none'
        for (let el of response.payload.response.names) {
          // console.log("Response: ", el);
          const li = document.createElement("li");
          li.setAttribute('id', el);
          li.classList.add("dropdown-item");
          li.classList.add("ph-no-capture");
          li.appendChild(document.createTextNode(el));
          li.addEventListener('click', function handleClick(event) {
            SelectionFunnelName(event.target.id)
          });
          ul.appendChild(li);
        }
      }
    }
  );
}
function SelectionFunnelName(name){
  const el = document.getElementById("listFunnel")
  el.style.display = "none"
  let project_id = sessionStorage.getItem("qly-project-id");
  if(!project_id){
    document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> you should select a project before saving a funnel!</div>`
    return
  }
  chrome.runtime.sendMessage(
    { message: "command", payload: "funnel", name: name, project_id: project_id, action: "get" , url: window.location.href},
    function (response) {
      // console.log(response.farewell);
      console.log("Got funnel response: ", response);
      if(!response){
        alert("An error has occurred while get funnel, please check credentials or network!")
      }else if(response.payload.status === "failure"){
        alert(response.payload.message)
      }else{
        sessionStorage.setItem("funnels", JSON.stringify(response.payload.response.funnel))
        refreshTableFunnel()
      }
    });
}
async function refreshTableFunnel(){
  let funnels = JSON5.parse(sessionStorage.getItem("funnels"));
  
    // Draw funnel paths
    if (funnels && funnels.length) {
      //  clear all golden paths first
      clearGoldenPaths();
      let last_element = "";
      // Add all items to list
      $("#qly--funnel_list").show();
      $("#qly--funnel_list tbody").empty();
      if (window.dataTable) {
        await window.dataTable.clear().draw();
        console.log("Cleared dataTable");
      } else {
        window.dataTable = $("#qly--funnel_list").DataTable({
          columnDefs: [
            {
              targets: 2,
              render: function (data, type, row) {
                return `<i  id="${row[0]}" class="las la-trash-alt icon--table ph-no-capture deleteFunnels" aria-hidden="true"></i> <i id="${row[0]}" class="las la-edit icon--table ph-no-capture editFunnels"  ></i>`;
              },
            },
          ],
          columns: [{ searchable: false }, null],
          scrollCollapse: true,
          paging: false,
          searching: false,
          ordering: false,
          info: false,
          createdRow: function (row, data, dataIndex) {
            $(row).addClass('ph-no-capture');
            $(row).attr('id',`qly-datatableColum_${data[0]}`);
            $(row.children).addClass('ph-no-capture')
            $(row.children).addClass('qly--container--focus')
            $(row.children).css('border','none')
          },
        });
      }
      $( window.dataTable.table().body() )
        .addClass( 'ph-no-capture' );
      for (const [i, value] of funnels.entries()) {
        let human_label = value["human_label"] || "";
        window.dataTable.row
          .add([
            i + 1, 
            // `<input id="qly-tableInput_${i}" class="ph-no-capture inp--table" type="text" name="label" value="${human_label.slice(0, 10) + (human_label.length > 10 ? '...' : '')}"/>`,
            human_label.slice(0, 40) + (human_label.length > 40 ? '...' : ''),
            ""])
          .draw(false);
  
        if (last_element["abs_xpath"] && value["abs_xpath"] && last_element["abs_xpath"] !== value["abs_xpath"]) {

          console.log(
            "Drawing leader line from " + last_element["abs_xpath"]
          );
          console.log("To: ", value["abs_xpath"]);
          // console.log("Source element: ", getElementByOuterHTML(last_element["outer_html"]));
          // console.log("Target element: ", getElementByOuterHTML(value["outer_html"]));
          new LeaderLine(
            getElementByXPath(last_element["abs_xpath"]),
            getElementByXPath(value["abs_xpath"]),
            {
              dash: { animation: true },
              opacity: 0.75,
              color: "#ffd700",
              // size = 10 * norm(l["percent"], min_arrow_pct, max_arrow_pct)
            }
          );
        }

        last_element = value;
        
      }
    } else {
      $("#qly--funnel_list").hide();
    }
}
function searchFunnel(el){
  const listeFunnel = JSON.parse(sessionStorage.getItem("listeFunnel"))
  if(listeFunnel){
    const result = listeFunnel.filter(item => {
      if(item.includes(el.target.value))
      return item
    })
    const listFunnel = document.getElementById("listFunnel")
    const ul = listFunnel.children[3]
    ul.replaceChildren()
    if(result.length > 0){
      for (let el of result) {
        // console.log("Response: ", el);
        const li = document.createElement("li");
        li.setAttribute('id', el);
        li.classList.add("dropdown-item");
        li.classList.add("ph-no-capture");
        li.appendChild(document.createTextNode(el));
        li.addEventListener('click', function handleClick(event) {
          SelectionFunnelName(event.target.id)
        });
        ul.appendChild(li);
      }
    }else{
      const li = document.createElement("li");
      li.classList.add("dropdown-item");
      li.classList.add("ph-no-capture");
      li.appendChild(document.createTextNode("no item found"));
      ul.appendChild(li);
    }
  }
}
// First time:
// 

function makeid(length) {
  var result           = '';
  var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for ( var i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function showFunnel() {
  console.log("In show funnel");
  
  chrome.storage.local.get("funnel", (data) => {
    if(data['funnel'] === true && !document.getElementById("funnel_view").classList.contains("qly--heatmap_button_off")){
      chrome.storage.local.set({ funnel: false });
      document
        .getElementById("funnel_view")
        .classList.add("qly--heatmap_button_off");
      clearGoldenPaths(true);
    }else{
      let project_id = sessionStorage.getItem("qly-project-id");
      // if(!project_id)
      //   return alert('select projeect')
      // Show funnel
      // list funnels
      chrome.storage.local.set({ funnel: true });
      // let project_id = sessionStorage.getItem("projec")
      // Uncomment this to see funnels api in action

      let random_funnel_name = makeid(6);
      refreshTableFunnel()

    
      // [{"url":"https://obefit.demobox.wring.dev/how-it-works", "xpath":"/html/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/a[1]"}
      // test of the ADD command
      // chrome.runtime.sendMessage(
      //   { message: "command", payload: "funnel", funnel: [{"url":"https://obefit.demobox.wring.dev/how-it-works", "xpath":"/html/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/a[1]"}], name: random_funnel_name, url: window.location.href, project_id: project_id, action: "add" },
      //   function (response) {
      //     // console.log(response.farewell);
      //     console.log("Got funnel ADD response: ", response);
      //     // test of the LIST command
      //     chrome.runtime.sendMessage(
      //       { message: "command", payload: "funnel", url: window.location.href, project_id: project_id, action: "list" },
      //       function (response) {
      //         // console.log(response.farewell);
      //         console.log("Got funnel LIST response: ", response);
      //         // test of the LIST command
      //         chrome.runtime.sendMessage(
      //           { message: "command", payload: "funnel", url: window.location.href, name: random_funnel_name, project_id: project_id, action: "delete" },
      //           function (response) {
      //             // console.log(response.farewell);
      //             console.log("Got funnel delete response: ", response);
      //
      //
      //             chrome.runtime.sendMessage(
      //               { message: "command", payload: "funnel", url: window.location.href, name: random_funnel_name, project_id: project_id, action: "list" },
      //               function (response) {
      //                 // console.log(response.farewell);
      //                 console.log("Got funnel list response: ", response);
      //
      //               });
      //            
      //            
      //           });
      //       });
      //    
      //   });
      
      

      
      
      // chrome.runtime.sendMessage(
      //   { message: "command", payload: "funnel", name: "funnel44", url: window.location.href, project_id: project_id, action: "get" },
      //   function (response) {
      //     // console.log(response.farewell);
      //     console.log("Got funnel response: ", response);
      //   });
      

      document
        .getElementById("funnel_view")
        .classList.remove("qly--heatmap_button_off");
    }
  })
}

function showHeatMap() {
  console.log("In show heatmap");
  toggleIndicatorLoader();
  let displayed = clearHeatMap();
  if (displayed) {
    toggleIndicatorLoader();
    document
      .getElementById("heatmap_view")
      .classList.add("qly--heatmap_button_off");
    chrome.storage.local.set({ heatmap: false });
    return;
  }

  console.log("Getting heatmap");
  //
  //   // minimal heatmap instance configuration
  //   let heatmapInstance = h337.create({
  //     // only container is required, the rest will be defaults
  //     container: document.querySelector('.col')
  //   });
  //
  // // now generate some random data
  //   var points = [];
  //   var max = 0;
  //   var width = 840;
  //   var height = 400;
  //   var len = 200;
  //
  //   while (len--) {
  //     var val = Math.floor(Math.random()*100);
  //     max = Math.max(max, val);
  //     var point = {
  //       x: Math.floor(Math.random()*width),
  //       y: Math.floor(Math.random()*height),
  //       value: val
  //     };
  //     points.push(point);
  //   }
  // // heatmap data format
  //   var data = {
  //     max: max,
  //     data: points
  //   };
  // // if you have a set of datapoints always use setData instead of addData
  // // for data initialization
  //   heatmapInstance.setData(data);

  chrome.runtime.sendMessage(
    { message: "command", payload: "heatmap", url: window.location.href },
    function (response) {
      // console.log(response.farewell);
      console.log("Got heatmap response: ", response);
      // console.log("elements: ", response.payload.info.data.elements_covering_heatmap);
      const els = response.payload.response;

      let filtered = [];
      let xpath_index = {};

      // console.log("typeelse: ", typeof(els));
      for (const e of els) {
        // console.log("element: ", e);
        // console.log("e.element.url: ", e.element.url);
        if (e.element.url === window.location.href) {
          filtered.push(e);
        }
      }

      console.log("Filtered elements: ", filtered);

      let flagged_elements = [];
      let summary_stats = {};

      for (const e of filtered) {
        let xpath = e.element.xpath;
        // console.log("xpath: ", xpath);
        if (xpath === "/") {
          // print out summary stats
          console.log("Capturing Summary stats: ", e);
          summary_stats["num_sessions"] = e["num_sessions"];
          summary_stats["num_paths_to_element"] = e["num_paths_to_element"];
          summary_stats["num_unique_paths_to_element"] =
            e["num_unique_paths_to_element"];
          // continue;
          xpath = "/body";
        }
        const _elt = document.evaluate(
          xpath,
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        if (_elt) {
          if (
            !_elt.classList.contains("qly") &&
            !_elt.classList.contains("ph-no-capture")
          ) {
            flagged_elements.push({ elt: _elt, details: e });
            xpath_index[xpath] = _elt;
          }
        }
      }

      console.log("flagged_elements: ", flagged_elements);

      const checkChild = (parent, items) => {
        if (parent.children.length > 0) {
          let ret =
            Array.from(parent.children).filter((t) => items.includes(t))
              .length > 0;

          if (!ret) {
            for (newParent of Array.from(parent.children)) {
              if (checkChild(newParent, items)) {
                return true;
              }
            }
          } else {
            return ret;
          }
        } else {
          return false;
        }
      };

      let all_flagged_elements = flagged_elements.map((val) => val["elt"]);
      let real_flagged_elements = [];

      all_flagged_elements.forEach((fl) => {
        let toDel = checkChild(
          fl,
          all_flagged_elements.filter((e) => e !== fl)
        );

        !toDel && real_flagged_elements.push(fl);
      });

      real_flagged_elements.forEach((elt) => {
        elt.classList.add("qly_heatmap_element_hover");
        // elt.classList.add.add("qly_zoom");
        // elt.classList.add("qly--highlight");
      });

      console.log("real_flagged_elements: ", real_flagged_elements);
      // window.endpoints = [];
      // window.jsplumb_elements = [];
      let arrows = [];
      let anchors = [];

      for (const e of flagged_elements) {
        console.log("element: ", e["elt"]);

        if (e["elt"]) {
          let _elt = e["elt"];

          // ADD here
          _elt.classList.add("qly_heatmap_element");
          // _elt.classList.add("qly--highlight");

          for (const nel of e.details.next_elements) {
            // console.log("nel: ", nel);

            let target_el = xpath_index[nel.xpath];

            if (target_el) {
              console.log("nel_pct: ", nel.percent);
              // let one bezier represent 10 percent
              const beziers = Math.floor(nel.percent / 10);
              // console.log("Beziers: ", beziers);

              // console.log("New line: ", _elt, target_el);
              if (_elt !== target_el) {
                arrows.push({
                  src: _elt,
                  target: target_el,
                  percent: nel.percent,
                });
              }
            }
          }
        }
      }

      let max_arrow_pct = 0;
      let min_arrow_pct = 100;
      for (const l of arrows) {
        if (l["percent"] < min_arrow_pct) {
          min_arrow_pct = l["percent"];
        }

        if (l["percent"] > max_arrow_pct) {
          max_arrow_pct = l["percent"];
        }
      }

      function enter(event, props) {
        let props_element = props.element;
        // props.element.classList.add("qly--highlight");
        for (const a of anchors) {
          // Multiple arrows from the same source
          if (a.element === props_element) {
            a.showArrows();
          } else if (a.targetElement === props_element) {
            a.showArrows();
          } else {
            a.hideArrows();
          }
        }
      }

      function leave(event, props) {
        // props.element.classList.remove("qly--highlight");

        for (const a of anchors) {
          // if (a._id !== props_id)
          // {
          a.showArrows();
          // }
        }
      }

      function init(props) {
        // console.log("init props: ", props);
        anchors.push(props);
      }

      for (const l of arrows) {
        const _w = l["target"].clientWidth;
        const _h = l["target"].clientHeight;

        let _dot = document.createElement("span");
        _dot.classList.add("qly--elt_circle_bg");

        l["src"].style.position = "relative";
        // l["src"].classList.add("qly--highlight");
        // l["src"].classList.add("qly_zoom");

        let mhAnchor = LeaderLine.mouseHoverAnchor({
          element: l["src"],
          showEffectName: "draw",
          // target Element stored for hover effects
          targetElement: l["target"],
          style: {},
          mouseEnterCallBack: enter,
          mouseLeaveCallBack: leave,
          initCallback: init,
        });

        let line = new LeaderLine(mhAnchor, l["target"], {
          dash: { animation: true },
          animOptions: {
            duration: 5000,
            timing: "ease-in",
          },
          opacity: 1,
          color: "lightblue",
          size: 2,
          endPlug: "arrow3",
          path: "arc",
        });

        line.size = 7 * norm(l["percent"], 0, max_arrow_pct);
        console.log("line size: ", line.size);
        console.log("line: ", line);
      }

      chrome.storage.local.set({ heatmap: true });
      toggleIndicatorLoader();
      document
        .getElementById("heatmap_view")
        .classList.remove("qly--heatmap_button_off");
    }
  );
}

function hideShowRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    showRecorderPanel();
  } else {
    hideRecorderPanel();
  }
}

function showRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    headlessRecorderOverlay.style.display = "block";
  }
}

function hideRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "block") {
    headlessRecorderOverlay.style.display = "none";
  }
}

function toggleIndicatorLoader() {
  let elt = document.getElementById("qly-indicator-loader");
  elt.style.display = elt.style.display === "none" ? "flex" : "none";
  console.log("elt: ", elt.style.display);
}
function toggleIndicatorLogo() {
  let elt = document.getElementById("qly-indicator_log_link");
  elt.style.display = elt.style.display === "none" ? "inline-block" : "none";
  console.log("elt: ", elt.style.display);
}
async function screenshot() {
  toggleIndicatorLoader();
  window.scrollTo(0, 0);
  let canvas = await html2canvas(document.body, {
    logging: true,
    letterRendering: 1,
    allowTaint: true,
    useCORS: true,
    height: document.body.getBoundingClientRect().height,
    width: document.body.getBoundingClientRect().width,
    // scrollX: 0,
    // scrollY: 0,
    // scrollY: -window.scrollY,
    // scrollX: -window.scrollX,
    // scrollY: -window.scrollY,
    // windowWidth: document.body.offsetWidth,
    // windowHeight: document.body.scrollHeight,
  });

  function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeString });
    return blob;
  }

  try {
    const handle = await showSaveFilePicker({
      suggestedName: window.location.hostname + ".png",
      types: [
        {
          description: "Screenshot",
          accept: { "image/png": [".png"] },
        },
      ],
    });

    const writableStream = await handle.createWritable();
    await writableStream.write(dataURItoBlob(canvas.toDataURL("image/png")));
    await writableStream.close();
  } catch (err) {
    console.error(err.name, err.message);
  } finally {
    toggleIndicatorLoader();
  }

  // const blob = new Blob(['Some text']);

  // canvas.toBlob(function(blob){
  //   let link = document.createElement("a");
  //   link.href = URL.createObjectURL(blob);
  //   console.log(blob);
  //   console.log(link.href); // this line should be here
  // },'image/png');

  // window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
}
function showContentLogin(go){
  document.getElementById("alert_danger").innerHTML = ""
  document.getElementById("alert_danger").style.display = "none"
  document.getElementById("alert_danger_forgot_password").innerHTML = ""
  document.getElementById("alert_danger_forgot_password").style.display = "none"
  document.getElementById("alert_danger_create").innerHTML = ""
  document.getElementById("alert_danger_create").style.display = "none"

  document.getElementById("forgot-password").style.display = "none"
  document.getElementById("Login-show").style.display = "none"
  document.getElementById("create-new-account").style.display = "none"
  if(go === "login"){
    document.getElementById("Login-show").style.display = "block"
  }
  if(go === "password"){
    document.getElementById("forgot-password").style.display = "block"
  }
  if(go === "register"){
    document.getElementById("create-new-account").style.display = "block"
  }
}
//#endregion

//
// full page screenshot
//
/**
 * Function to call setTimeout with await.
 *
 * @param ms milliseconds to wait
 * @returns {Promise<unknown>}
 */
async function awaitableTimeout(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * This is required to make items with CSS fixed/sticky positions not repeat on the screenshot.
 */
function unStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "fixed"
  );
  stickyElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "sticky"
  );
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "absolute"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "relative"));
}

/**
 * This restores any elems that were unattached by unStickElems()
 */
function reStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "fixed"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "sticky"));
}

/**
 * Function to execute a full page screenshot
 * @returns {Promise<void>}
 */
async function fullPageScreenshot() {
  // indicate we're processing
  toggleIndicatorLoader();

  // this stores refs to elements that will be detached for screenshot purposes
  let fixedElements = [];
  let stickyElements = [];

  // save the images in this array
  let screenshotArray = [];
  const imageFilename = window.location.hostname + "-screenshot.png";

  const startingScrollY = window.scrollY;

  // scroll to the top
  window.scroll(0, 0);

  // get the full height of the page
  const pageHeight = Math.max(
    document.body.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.clientHeight,
    document.documentElement.scrollHeight,
    document.documentElement.offsetHeight
  );
  const viewportHeight =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight;

  // not using window.innerWidth because we want to ignore scrollbars
  const viewportWidth =
    document.documentElement.clientWidth || document.body.clientWidth;

  // scroll down by 1 x viewport height each time
  let scrollMaxCount = Math.ceil(pageHeight / viewportHeight);
  console.log(
    `Full page screenshot will scroll the page ${scrollMaxCount} times.`
  );
  // if (scrollMaxCount > 60) {
  //   alert(
  //     "Sorry, this page is too long to be captured in a full page screenshot."
  //   );
  //   window.scroll(0, startingScrollY);
  //   return;
  // }

  try {
    // save current position
    let currentScrollValue = window.scrollY || 0;
    let currentScrollCount = 0;

    // hide the recorder div
    hideShowRecorderPanel();

    // detach fixed-pos and sticky-pos elements
    unStickyElems(fixedElements, stickyElements);

    while (currentScrollCount <= scrollMaxCount) {
      let response = await chrome.runtime.sendMessage({
        message: "command",
        payload: "fullPageScreenshot",
        url: window.location.href,
      });

      console.log("Got response from background script with image.");
      // save the image to the array
      screenshotArray.push([
        response.image,
        currentScrollCount,
        currentScrollValue,
      ]);
      console.log(
        `saved image at scrollY value: ${currentScrollValue}, ` +
          `pageHeight: ${pageHeight}, viewPortHeight: ${viewportHeight}, ` +
          `currentScrollCount: ${currentScrollCount}, ` +
          `scrollMaxCount: ${scrollMaxCount}`
      );

      // scroll down by one viewport height each time
      window.scroll(0, currentScrollCount * viewportHeight);
      currentScrollCount += 1;
      currentScrollValue = window.scrollY;
      // wait 250 msec because:
      // https://developer.chrome.com/docs/extensions/reference/tabs/#property-MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND
      await awaitableTimeout(550);
    }

    //
    // done with the loop, we now need to put together the screenshot array into a single image
    //

    // if it's a single image, can stop here
    if (screenshotArray.length === 1) {
      const downloadLink = document.createElement("a");
      downloadLink.download = imageFilename;
      downloadLink.rel = "noreferrer noopener";
      // the "data:image/png;base64," bit is already present so no need to add it
      downloadLink.href = screenshotArray[0][0];
      downloadLink.click();
      downloadLink.remove();
      return;
    }

    // otherwise, we have to go through the array, convert each data URI to an image, then paste it into a canvas
    // at its corresponding scrollY
    const cnv = document.createElement("canvas");
    const devicePixelRatio = window.devicePixelRatio;
    cnv.width = viewportWidth * devicePixelRatio;
    cnv.height = pageHeight * devicePixelRatio;

    for (let item of screenshotArray) {
      const [thisImage, thisScrollCount, thisScrollValue] = item;
      let imageObj = new Image();
      imageObj.onload = function () {
        cnv
          .getContext("2d")
          .drawImage(
            imageObj,
            0,
            0,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio,
            0,
            thisScrollValue * devicePixelRatio,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio
          );
      };
      imageObj.src = thisImage;
    }

    // wait for all images to be loaded
    console.log("Waiting for all images to be loaded...");
    await awaitableTimeout(500);

    // save the final image
    const finalImageDataURI = cnv.toDataURL("image/png");
    const downloadLink = document.createElement("a");
    downloadLink.download = imageFilename;
    downloadLink.rel = "noreferrer noopener";
    // the "data:image/png;base64," bit is already present so no need to add it
    downloadLink.href = finalImageDataURI;
    downloadLink.click();
    downloadLink.remove();
  } finally {
    // remove the spinner
    toggleIndicatorLoader();
    // bring the user back to their start Y position
    window.scroll(0, startingScrollY);

    // reattach fixed-pos and sticky-pos elements
    reStickyElems(fixedElements, stickyElements);

    // show the recorder div
    showRecorderPanel();
  }
}
//
// end full page screenshot
//

//#region chrome events
chrome.storage.local.get("activated", (data) => {
  if (data["activated"]) {
    chrome.storage.local.get("recording", (data) => {
      chrome.storage.local.get("qly-user", (user) =>{
        if(user["qly-user"] ){
          renderIndicator(data["recording"]);
        }else{
          render()
        }
      } ) 
    });
    // showRecorderPanel();
  }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Got request: ", request);
  if (request.message === "command") {
    // toggleRecord();
    console.log("message is command");
    if (request.payload === "activate") {
      chrome.storage.local.get("activated", (data) => {
        if (data["activated"]) {
          console.log("Showing recorder panel");
          // location.reload();
          // console.log("Reloaded page")

          chrome.runtime.sendMessage(
            { message: "command", payload: "activate" },
            function (response) {
              console.log("Got response: ", response);
              showRecorderPanel();
            }
          );
        } else {
          hideRecorderPanel();
        }
        sendResponse({ message: "success" });
      });
    }
  }
  return true;
});
//#endregion
