const GOLDEN_PATH_CLASSNAME = "crx_golden_path"; // Unique ID for the className.
const UI_URL = "https://beta.quikly.dev/"
let prevDOM = null; // Previous dom, that we want to track, so we can remove the previous styling.
let qlyIndicatorContainer = document.createElement("DIV"); // The indicator container
// let golden_paths = [];
console.log("PRODUCT VERSION: ", window.wring_version);
let dropDownStatus = "closed";
let intervalID;
chrome.storage.local.get(`${getDomain(window.location.host)}`, data => {
  chrome.qly_funnels = data[getDomain(window.location.host)]
})

function uuidv4() {
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
  );
}
//#region document events
document.addEventListener("keyup", function (e) {
  // var e = e || window.event; //! for IE to cover IEs window event-object
  if (e.ctrlKey && e.key === "k") {
    hideShowRecorderPanel();
    return false;
  }
});
document.addEventListener("mouseover", function(e){
  let golden_paths = [];
  let interacted_element = {
    xpath : xpath(e.srcElement),
    url : e.target.baseURI,
    el: e,
  };
  golden_paths[getDeepComputedLabel(e.srcElement)] = interacted_element ;
  localStorage.setItem("cacheXpath", JSON.stringify(golden_paths));

})
document.addEventListener(
  "click",
  function (e) {
    if (e.pointerType.length) {
      if(e.srcElement.classList.contains("qly-open_modal"))
        closeAllModal(e.srcElement.classList.toString())
      if(e.srcElement.id === "qly-MinimizeTable"){
        MinimizeTable("MinimizeTable");
      }
      if(e.srcElement.id === "qly-MaximizeTable"){
        MinimizeTable("MaximizeTable");
      }
      if(e.srcElement.classList.contains("editFunnels")){
        editFunnels(e);
      }
      // Do what you want with click event
      // console.log("We got a click event: ", e);
      // e.stopPropagation();
  
      chrome.storage.local.get("funnel", (data) => {
        if (data["funnel"]) {
          // let golden_paths = localStorage.getItem("qly_funnels");
          // console.log("golden_paths: ", golden_paths);
          // if (golden_paths) {
          // }
          // else {
          //   golden_paths = JSON.parse(golden_paths);
          // }
  
          console.log("In funnel mode, we can DRAW the funnels now");
          // let funnel_storage = localStorage.getItem("qly_funnels");
          // console.log("funnel_storage: ", funnel_storage);
          let golden_paths = chrome.qly_funnels;

          console.log("golden_paths: ", golden_paths);
          if (!golden_paths || !golden_paths.length) {
            golden_paths = [{
             uuid: uuidv4() 
            }];
          }
          // if (
          //   golden_paths && !golden_paths.length ||
          //   (golden_paths && golden_paths.length && golden_paths.at(-1) !== e.srcElement)
          // ) {
          if (!e.srcElement.classList.contains("ph-no-capture")) {
            e.srcElement.classList.add("force_xpath")
            let abs_xpath = null
            let url = window.location.href
            try {
              abs_xpath = xpath(e.srcElement)
            } catch (error) {
              console.log('error xpath',error)
            }
            if(!abs_xpath){
              let cache = JSON5.parse(localStorage.getItem('cacheXpath'))
              abs_xpath = cache[getDeepComputedLabel(e.srcElement)].xpath
              url = cache[getDeepComputedLabel(e.srcElement)].url
            }
            let outer_html = e.srcElement.outerHTML;
            // console.log("abs_xpath: ", abs_xpath);
            // console.log("outer_html: ", outer_html);
            // console.log("Abs Xpath of element is: ", createXPathFromElement(e.srcElement));
            // golden_paths.push(e.srcElement);
  
            let interacted_element = {
              "url": url,
              "xpath": abs_xpath,
              human_label: getDeepComputedLabel(e.srcElement),
              step_num: golden_paths.length // As the first element is a UUID marker
            };
            golden_paths.push(interacted_element);
            // golden_paths.push(e.srcElement.outerHTML);
            // golden_paths.push(e.srcElement.outerHTML);
            // console.log("golden_paths: ", golden_paths);
            
            // localStorage.setItem("qly_funnels", JSON.stringify(golden_paths));
            chrome.qly_funnels = golden_paths
            let pageName = {}
            pageName[getDomain(window.location.host)] = golden_paths
            // console.log("jkbdfkjsfnjkhfnjksnjkbfgkjfdshbgjksdb",pageName)
            chrome.storage.local.set(pageName)
            // e.srcElement.classList.add(GOLDEN_PATH_CLASSNAME);
            e.srcElement.classList.add("qly_funnel_element");
            // console.log("Captured new element");
            pageScreenshot(false, interacted_element, golden_paths[0]);
            refreshTableFunnel();
          }
        }

      });
    }
  },
  false
);
document.addEventListener("scroll", e =>{
  const error = sessionStorage.getItem('errorFunnel') 
  if(error && error === 'no show xpath')
    refreshTableFunnel()
});
//#endregion

//#region functions
function norm(value, min, max) {
  return (value - min) / (max - min);
}

const dragElt = (dom, domChild) => {
  let pos1 = 0;
  let pos2 = 0;
  let pos3 = 0;
  let pos4 = 0;

  const eltDrag = (e) => {
    e.preventDefault();

    const _domHeight = dom.getBoundingClientRect().height;

    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    dom.style.top = `${dom.offsetTop - pos2}px`;
    dom.style.left = `${dom.offsetLeft - pos1}px`;
  };

  const closeDragElt = () => {
    document.removeEventListener("mousemove", eltDrag);
    document.removeEventListener("mouseup", closeDragElt);
  };

  const dragMouseDown = (e) => {
    e.preventDefault();

    pos3 = e.clientX;
    pos4 = e.clientY;

    document.addEventListener("mouseup", closeDragElt);
    document.addEventListener("mousemove", eltDrag);
  };

  domChild.addEventListener("mousedown", dragMouseDown);
}

function logout(){
  toggleIndicatorLoader();

  try {
    const url = "/auth/v1/users/logout"
    chrome.runtime.sendMessage(
      { message: "command", payload: "auth", action: 'logout', url: url},
      function (response) {
      if(response.payload.status === "success"){
        chrome.windows.qlyUserAccessTokenPMAssist = null
        document.getElementById("headless-recorder-overlay").remove()
        chrome.storage.local.set({ funnel: false });
        clearGoldenPaths(true);
        chrome.storage.local.set({ recording: false});
        sessionStorage.removeItem("funnels")
        window.location.reload()
      }
    });
  } catch (error) {
    console.log(error)
    toggleIndicatorLoader();
  }

}

function renderIndicator(rec, ful, hmap) {
    let line_awesome = document.createElement("link"); // The indicator container
    line_awesome.rel = "stylesheet"
    line_awesome.href = chrome.runtime.getURL("/css/line_awesome/css/line_awesome.min.css") 
    document.querySelector("head").appendChild(line_awesome);
  

  chrome.storage.local.get("recording", (data) => {
    if (rec === undefined) {
      if (data["recording"])
      sessionStorage.setItem("current-rec-value", data["recording"]);
    }
  });
  chrome.storage.local.get("funnel", (data) => {
    if (ful === undefined) {
      if (data["funnel"])
      sessionStorage.setItem("current-ful-value", data["funnel"]);
    }
  });
  chrome.storage.local.get("heatmap", (data) => {
    if (ful === undefined) {
      if (data["heatmap"])
      sessionStorage.setItem("current-hmap-value", data["heatmap"]);
    }
  });


  let recVal = rec ? rec : JSON.parse(sessionStorage.getItem("current-rec-value"));
  let fulVal = ful ? ful : JSON.parse(sessionStorage.getItem("current-ful-value"));
  let hmapVal = hmap ? hmap : JSON.parse(sessionStorage.getItem("current-hmap-value"));
  let icon;
  
  if (fulVal) 
  {
    icon = chrome.runtime.getURL("/images/qly_record.svg")
  }
  
  else {
    icon = recVal
      ? chrome.runtime.getURL("/images/qly_pause.svg")
      : chrome.runtime.getURL("/images/qly_record.svg");
  }
  let funnel_icon = fulVal 
    ? chrome.runtime.getURL("/images/qly_stop.svg")
    : chrome.runtime.getURL("/images/qly_funnel.svg");
  
  // let quikly_logo = chrome.runtime.getURL("/logo/logo-16.png");
  let quikly_logo = chrome.runtime.getURL("/logo/logo.svg");
  let heatmap_icon = chrome.runtime.getURL("/images/qly_heatmap.svg");
  let screenshot_icon = chrome.runtime.getURL(
    "/images/qly_screenshot_icon.svg"
  );
  let logout_icon = chrome.runtime.getURL(
    "/images/qly_lougot.svg"
  );

  let _extraClass =
    window.wring_version === "designer" ? "qly--need_upgrade" : "";
  let _height = recVal ? "92px" : "55px";
  let funnelHeight = recVal ? "107px" : "70px";
  let _header = recVal
    ? `<header class="qly--indicator_head ph-no-capture">
        <div class="qly--ring_container ph-no-capture">
          <div class="qly--ring_elt ph-no-capture"></div>
          <div class="qly--ring_circle ph-no-capture"></div>
        </div>
        <span class="qly--indicator_head_txt ph-no-capture qly--fnt-family">Recording ...</span>
      </header>`
    : ``;
    const listTypeFunnel = ["Awareness", "Acquisition", "Activation", "Retention", "Revenue", "Referral"]
    let optionFunnel = ""
    
    for (let i = 0; i < listTypeFunnel.length; i++) {
      optionFunnel = optionFunnel + `<option  class="ph-no-capture"  value="${listTypeFunnel[i]}">${listTypeFunnel[i]}</option>`
    }
    let bars = chrome.runtime.getURL("/images/icon/la-ellipsis.svg")
    let la_down = chrome.runtime.getURL("/images/icon/la-down.svg")
    let la_edit = chrome.runtime.getURL("/images/icon/la-edit.svg")
    let la_trash = chrome.runtime.getURL("/images/icon/la-trash-alt.svg")
    let la_minus = chrome.runtime.getURL("/images/icon/la-minus-circle.svg")
    let la_plus = chrome.runtime.getURL("/images/icon/la-plus-circle.svg")
    let las_save = chrome.runtime.getURL("/images/icon/las-save.svg")
    let las_save1 = chrome.runtime.getURL("/images/icon/las-save1.svg")
    let clear = chrome.runtime.getURL("/images/icon/clear.svg")
    let la_off = chrome.runtime.getURL("/images/icon/la-off.svg")
    let funnels = chrome.qly_funnels;
    let isSave = ""
    if(funnels && funnels.length){
      isSave = "disabled"
    }

  qlyIndicatorContainer.innerHTML = `<div id="headless-recorder-overlay" class="qly--indicator_container qly--fnt-family ph-no-capture" data-v-app="" style="display: none; height: ${_height}">
    <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
    <div id="qly-indicator-content" class="qly--indicator_content qly--fnt-family ph-no-capture">
      <span class="qly--indicator_close qly--fnt-family ph-no-capture" id="qly-indicator-closer">x</span>
      ${_header}
      <div class="qly--indicator_main qly--fnt-family ph-no-capture">
        <!-- <span id="action_btn" class="qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Record" class="ph-no-capture" title="Observe" src="${icon}" />
        </span> -->
        <span id="heatmap_view"  class="${!hmapVal ? 'qly--heatmap_button_off' : '' } qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Heatmap"  class="ph-no-capture" title="Session map" src="${heatmap_icon}" />
        </span>
        <span id="funnel_view" class="qly--indicator_btn ph-no-capture ${_extraClass}">
          <img alt="Funnel" class="ph-no-capture" title="Funnels" src="${funnel_icon}" />
        </span>
        <span id="screenshot_btn" class="qly--heatmap_button_off qly--indicator_btn ph-no-capture">
          <img alt="Screenshot" class="ph-no-capture" title="Screenshot" src="${screenshot_icon}" />
        </span>
        <!-- <div class="qly&#45;&#45;indicator_extra ph-no-capture"></div>-->
                <span class="qly--indicator_v_divider ph-no-capture"></span>

        <div class="qly--indicator_extra ph-no-capture dropup" style="z-index:99;" id="projectSelectParent">
            <div id="projectSelectButton" class="qly--indicator_btn ph-no-capture ${_extraClass} qly--indicator_btn_project" style="height: 25px;">
              <img alt="Funnel" class="ph-no-capture qly-open_modal qly--heatmap_button_off qly--indicator_btn" title="Funnels" src="${bars}" />
              <div class="qly--indicator_dropdown_menu ph-no-capture" id="projectDropList" style="display: none;"> 
                <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader_project" ><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
                <div id="projectDropList_content" class="ph-no-capture" > 
                </div>
              </div>
            </div>
            <ul class="dropdown-menu qly--indicator_extra ph-no-capture qly--modal" id="projectDropList2" aria-labelledby="dropdownMenuButton">
            </ul>
        </div>
        <!-- <div class="qly&#45;&#45;indicator_extra ph-no-capture"></div>-->

         <img alt="Logo" class=" ph-no-capture qly-open_modal qly-indicator_log_link" title="Quikly" id="qly--logo"  src="${quikly_logo}" width="32" />
        <div class="qly--indicator_log_link ph-no-capture qly--fnt-family qly--modal" id="qly-indicator_log_link" style="display: none;"> 
          <a href="${UI_URL}" target="_blank" class="qly--content_log_link qly--fnt-family ph-no-capture" > 
            <img alt="Logo" class=" ph-no-capture" title="Quikly" src="${quikly_logo}" width="20" />
            <span class="ph-no-capture qly--fnt-family"> Home</span>
          </a>
          <div class="qly--content_log_link ph-no-capture" id="logout_btn" > 
            <span class="qly-open_modal ph-no-capture qly--indicator_btn">
              <img alt="off" class="ph-no-capture" src="${la_off}" />
            </span>
            <span class="ph-no-capture qly--fnt-family"> Log out</span>
          </div>
        </div>
        </div>
        </div>
        <div id="confirm_box" class="qly--app_funnel qly--fnt-family ph-no-capture qly--modal" style="display: none;" >
          <div class="qly--ipt_group_funnel qly--fnt-family ph-no-capture" >
          </div>
          <div class="qly--confirm_box--bottom qly--fnt-family ph-no-capture">
            <button id="closeConfirm_box" class="ico--btn yellow ph-no-capture qly--fnt-family" >
              <span class="text-btn ph-no-capture qly--fnt-family">Cancel</span>
            </button>
            <button class="ico--btn info ph-no-capture" >
              <span class="text-btn ph-no-capture qly--fnt-family"> Ok </span>
            </button>
          </div>
        </div>
        <div id="listFunnel" class="qly--app_funnel ph-no-capture qly--fnt-family qly--modal" style="display: none;">
          <span class="qly--indicator_close ph-no-capture" id="proccesListFunnel_close" >x</span>
          <div class="qly--indicator_loader ph-no-capture" id="qly-indicator-loader--listFunnel" style="display: none;"><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
          <input id="process_search-funnel" class="ph-no-capture qly-search--input qly--fnt-family" type="text" name="value" placeholder="Search" />
          <button id="proccesSaveFunnel" class="ico--btn info ph-no-capture qly-open_modal funnel-form-save base_listeFunnel" style=" display: none; width:95%; justify-content: left;">
            <span class="ico-btn ph-no-capture qly-open_modal funnel-form-save base_listeFunnel">
              <img alt="off" class="ph-no-capture " src="${las_save1}" />
            </span>
            <span class="text-btn ph-no-capture qly-open_modal funnel-form-save base_listeFunnel qly--fnt-family">Create new funnel : </span>
            <span class="text-btn ph-no-capture qly-open_modal funnel-form-save base_listeFunnel qly--fnt-family"> </span>
          </button>
          <ul class="qly-content--list--funnel ph-no-capture qly--fnt-family" aria-labelledby="dropdownMenuButton">
          </ul>
        </div>
        <table style="display:none; bottom:${funnelHeight};" id="qly--funnel_list" class="qly--funnel_list_container qly--fnt-family ph-no-capture">
        <thead class="ph-no-capture">
            <tr class="ph-no-capture">
              <th style="width: 10%;" class="ph-no-capture"></th>
              <th style="width: 55%;" class="ph-no-capture qly--fnt-family">Value </th>
              <th style="width: 35%; display: flex;" class="ph-no-capture" >
                <img alt="off" id="proccesSaveFunnel2"  class="ph-no-capture qly-open_modal funnel-form-save " src="${las_save}" style="margin-right: 10px;"/>
                <img alt="off"  id="proccesListFunnel" class="qly-icon--table ph-no-capture qly-open_modal listFunnel" src="${la_down}" />
                <img alt="off"  id="qly-indicator-clear-funnel" class="qly-icon--table ph-no-capture  listFunnel" style="margin-right: 10px;" src="${clear}"/>
                
                <div id="qly-minimize--funnel--table" class="MinimizeTable ph-no-capture">
                  <img alt="off" id="qly-MinimizeTable" class="qly--minimiza ph-no-capture" src="${la_minus}" />
                </div>
              </th>
            </tr>
          </thead>
        </table>
        <form id="funnel-form-save" class="qly--app_funnel ph-no-capture qly--modal" style="display: none; action="" >
        <div class="qly--indicator_loader qly--fnt-family ph-no-capture" id="qly-indicator-loader_saveFunnel" style="display: none;" ><div class="qly--indicator_lds_spinner ph-no-capture"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>
        <span class="qly--indicator_close qly--fnt-family ph-no-capture" id="qly-indicator-closer_save_funnel">x</span>
          <div class="qly--h3 qly--fnt-family">Save funnel</div>
          <div id="alert_danger_save_funnel" class=" qly--fnt-family">
          </div>
          <div class="qly--ipt_container ph-no-capture">
            <div class="" ph-no-capture>
              <div id="type_funnel" class="qly--ipt_group_funnel ph-no-capture">
                <div class="qly--ipt--append ph-no-capture">
                  Type
                </div>
                <select name="type_funnel" value="" id="qly-type-funnel"  class="ph-no-capture qly--fnt-family" >
                  ${optionFunnel}
                </select>
              </div>
              <div class="qly--ipt_group_funnel ph-no-capture">
                <div class="qly--ipt--append qly--fnt-family ph-no-capture">
                  Name
                </div>
                <input id="qly-inp" class="ph-no-capture qly--fnt-family "  type="text" name="name_funnel"  placeholder="name funnel" required />
                </div>
              <button id="editNameBtnFunnel" type="submit" class="ico--btn success qly--fnt-family ph-no-capture" style="float: right; display: none; ">
                <span class="ico-btn ph-no-capture"">
                  <img alt="off" class="ph-no-capture " src="${la_edit}" />
                </span>
                <span class="text-btn ph-no-capture qly--fnt-family">Save name</span>
              </button>
              <button id="saveBtnFunnel" type="submit" class="ico--btn info qly--fnt-family ph-no-capture" style="float: right;">
                <span class="ico-btn ph-no-capture"">
                  <img alt="off" class="ph-no-capture " src="${las_save1}" />
                </span> 
                <span class="text-btn ph-no-capture qly--fnt-family">Save</span>
              </button>
            </div>
          </div>
        </form>
  </div>`;
  chrome.storage.local.get("funnel", (data) => {
    if(data['funnel'] === true && chrome.qly_funnels && chrome.qly_funnels.length > 0){
      refreshTableFunnel()
      document
      .getElementById("funnel_view")
      .classList.remove("qly--heatmap_button_off");
    }
  })

  if (
    sessionStorage.getItem("qly-indicator-pos-b") &&
    sessionStorage.getItem("qly-indicator-pos-l")
  ) {
    qlyIndicatorContainer.firstChild.style.top =
      sessionStorage.getItem("qly-indicator-pos-b") + "px";
    qlyIndicatorContainer.firstChild.style.left =
      sessionStorage.getItem("qly-indicator-pos-l") + "px";
  }

  //#region indicator handlers
  if (!document.getElementById("headless-recorder-overlay")) {
    document.querySelector("body").appendChild(qlyIndicatorContainer);
    dropDownStatus = "closed";
  }
  const myDropdown = document.getElementById('projectSelectButton')
  if(myDropdown){
    myDropdown.addEventListener('click', () => {
      // console.log("Dropdown opened!");
      dropDownStatus = (dropDownStatus === "open") ? "closed" : "open";

      const projectDropList = document.getElementById('projectDropList');
      let loader = document.getElementById("qly-indicator-loader_project")
      if(loader)
        loader.style.display = 'inline-flex'
      if (dropDownStatus === "open") {
        projectDropList.style.display = "block"
        chrome.runtime.sendMessage( {message: "command", payload: "projects"}, function (response) {
            console.log("Got response: ", response);
            const projectDropList_content = document.getElementById("projectDropList_content")
            projectDropList_content.replaceChildren();
            // projectDropList_content.appendChild()
            if(response.payload.response){
              loader.style.display = 'none'
              const li = document.createElement("li");
              li.appendChild(document.createTextNode("Select Project"));
              li.classList.add("qly--indicator_list_head_txt");
              li.classList.add("ph-no-capture");
              projectDropList_content.appendChild(li);


              for (let el of response.payload.response) {
                // console.log("Response: ", el);
                const li = document.createElement("li");
                li.setAttribute('id', el.projectId);
                li.setAttribute('apiKey', el.apiKey);
                li.classList.add("qly-dropdown-item");
                li.classList.add("ph-no-capture");
                li.appendChild(document.createTextNode(el.name));
                li.addEventListener('click', function handleClick(event) {
                  console.log('project clicked:', event);
                //   console.log('project apiKey:', event.target.attributes.apiKey.value);
                  // Saving project ID
                  sessionStorage.setItem("qly-project-id", event.target.id);
                  sessionStorage.setItem("qly-project-apiKey", event.target.attributes.apiKey.value);
                  
                  console.log('Selected Project id: ', sessionStorage.getItem("qly-project-id"));
                  console.log('project api key: ', sessionStorage.getItem("qly-project-apiKey"));
                });
                projectDropList_content.appendChild(li);
              }
            }
          }
        );
      }
      else {
        projectDropList.style.display = "none"
        console.log("Updated dropDownstatus: ", dropDownStatus);
      }

    })
  }
  
  if (document.getElementById("headless-recorder-overlay")) {
    const _indicatorContainer = document.getElementById(
      "headless-recorder-overlay"
    );

    if (document.getElementById("qly-indicator-content")) {
      const _indicatorContent = document.getElementById(
        "qly-indicator-content"
      );
      if (_indicatorContainer && _indicatorContent) {
        dragElt(_indicatorContainer, _indicatorContent);
      }
    }
  }

  if (document.getElementById("qly-indicator-closer")) {
    document
      .getElementById("qly-indicator-closer")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("headless-recorder-overlay");

        if (elt && elt.style.display === "block") {
          clearGoldenPaths(true);
          clearHeatMap();

          chrome.storage.local.set({ recording: false });
          chrome.storage.local.set({ activated: false });
          chrome.qly_funnels = false
          chrome.storage.local.remove(`${getDomain(window.location.host)}`)
          elt.style.display = "none";
        }
        
        // elt = document.getElementById("qly--headless--container");
        // // console.log(elt)
        // if (elt) {
        //   elt.style.display = "none";
        //   clearHeatMap();
        //   chrome.storage.local.set({ recording: false });
        //   chrome.storage.local.set({ activated: false });
        // }
        window.location.reload();
      });
  }
  if (document.getElementById("qly-indicator-clear-funnel")) {
    document
      .getElementById("qly-indicator-clear-funnel")
      .addEventListener("click", (e) => {
        chrome.qly_funnels = false
        let name = {}
        name[getDomain(window.location.host)] = false
        chrome.storage.local.set(name)
        refreshTableFunnel()
      });
  }
  // if (document.getElementById("qly-container-closer")) {
  //   document
  //     .getElementById("qly-container-closer")
  //     .addEventListener("click", (e) => {
  //       let elt = document.getElementById("qly--headless--container");
  //       console.log(elt)
  //       if (elt) {
  //         elt.style.display = "none";
  //         clearHeatMap();
  //         chrome.storage.local.set({ recording: false });
  //         chrome.storage.local.set({ activated: false });
  //       }
  //     });
  // }
  if(document.getElementById("qly-indicator-closer_save_funnel")){
    document
      .getElementById("qly-indicator-closer_save_funnel")
      .addEventListener("click", (e) => {
        let elt = document.getElementById("funnel-form-save");
        elt.style.display = "none";
      });
  }
  if (document.getElementById("funnel_view")) {
    document
      .getElementById("funnel_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showFunnel();
      });
  }

  if (document.getElementById("heatmap_view")) {
    document
      .getElementById("heatmap_view")
      .addEventListener("click", function (e) {
        if (window.wring_version === "pro") showHeatMap();
      });
  }

  if (document.getElementById("action_btn")) {
    document
      .getElementById("action_btn")
      .addEventListener("click", function (e) {
        showRec()
      });
  }
  if (document.getElementById("screenshot_btn")) {
    document
      .getElementById("screenshot_btn")
      .addEventListener("click", (e) => {
        pageScreenshot(true);
      });
  }
  if (document.getElementById("logout_btn")) {
    document
      .getElementById("logout_btn")
      .addEventListener("click", (e) => {
        logout();
      });
  }
  if(document.getElementById("qly--logo")){
    document
      .getElementById("qly--logo")
      .addEventListener("click", (e) => {
        toggleIndicatorLogo();
      });
  }
  if(document.getElementById("colseFormEditStep")){
    document
      .getElementById("colseFormEditStep")
      .addEventListener("click", (e) => {
        e.preventDefault()
        document.getElementById("funnel-form").style.display = "none"
      });
  }
  if(document.getElementById("saveFormEditStep")){
    document
      .getElementById("saveFormEditStep")
      .addEventListener("click", (e) => {
        e.preventDefault()
        document.getElementById("funnel-form").style.display = "none"
        saveFormEditStep()
      });
  }
  if(document.getElementById("proccesSaveFunnel")){
    document
      .getElementById("proccesSaveFunnel")
        .addEventListener("click", (e) => {
          e.preventDefault()
          if (e.srcElement.classList.contains("base_listeFunnel")) {
            let form = document.getElementById("funnel-form-save")
            form.elements["name_funnel"].value = sessionStorage.getItem("new_funnel_name")
          }
          document.getElementById("alert_danger_save_funnel").innerHTML = ""
          document.getElementById("funnel-form-save").style.display = "flex"
        });
  }
  if(document.getElementById("proccesSaveFunnel2")){
    document
      .getElementById("proccesSaveFunnel2")
        .addEventListener("click", (e) => {
          e.preventDefault()
          proccesSaveFunnel()
        });
  }
  if(document.getElementById("proccesListFunnel")){
    document
      .getElementById("proccesListFunnel")
        .addEventListener("click", (e) => {
          e.preventDefault()
          const el = document.getElementById("listFunnel")
          if(el.style.display === "block"){
            el.style.display = "none"
            document.getElementById("qly-indicator-loader--listFunnel").style.display = "none"
          }else{
            let project_id = sessionStorage.getItem("qly-project-id");
            if(!project_id){
              alert("you should select a project before adding a funnel!")
              return
            }
            el.style.display = "block"
            showListFunnel()
          }
        });
  }
  if(document.getElementById("proccesListFunnel_close")){
    document
      .getElementById("proccesListFunnel_close")
        .addEventListener("click", (e) => {
          e.preventDefault()
          const el = document.getElementById("listFunnel")
          el.style.display = "none"
          document.getElementById("qly-indicator-loader--listFunnel").style.display = "none"
        });
  }
  if(document.getElementById("saveBtnFunnel")){
    document
      .getElementById("saveBtnFunnel")
      .addEventListener("click", (e) => {
        e.preventDefault()
        saveFunnel()
      })
  }
  if(document.getElementById("editNameBtnFunnel")){
    document
      .getElementById("editNameBtnFunnel")
      .addEventListener("click", (e) => {
        e.preventDefault()
        saveFunnel()
      })
  }
  if(document.getElementById("process_search-funnel")){
    document
      .getElementById("process_search-funnel")
      .addEventListener("input", (e) => {
        e.preventDefault()
        searchFunnel(e)
      })
  }
  if (document.getElementById("closeConfirm_box")) {
    document
      .getElementById("closeConfirm_box")
      .addEventListener("click", (e) => {
        document.getElementById("confirm_box").style.display = "none"
      })
  }
  //#endregion

  showRecorderPanel()
  sessionStorage.removeItem("current-rec-value")
  sessionStorage.removeItem("current-ful-value")
  sessionStorage.removeItem("current-hmap-value")

  chrome.storage.local.get("heatmap", (data) => {
    if (data['heatmap'] === true) {
      toggleIndicatorLoader();
      refreshheatmap()
    }
  })
}
function clearGoldenPaths(reset = false) {
  let boxes = document.querySelectorAll("." + GOLDEN_PATH_CLASSNAME);
  if(boxes)
    boxes.forEach((box) => {
      box.classList.remove(GOLDEN_PATH_CLASSNAME);
    });

  $("#qly--funnel_list").hide();

  boxes = document.querySelectorAll(".qly-line");
  if(boxes)
    boxes.forEach((box) => {
      displayed = true;
      // document.querySelector('heat')
      box.remove();
    });

  clearHeatMap();
  if (reset) {
    // golden_paths = [];
    sessionStorage.removeItem("funnels");
    boxes = document.querySelectorAll(".qly_funnel_element");
    boxes.forEach((box) => {
      box.classList.remove("qly_funnel_element");
    });
  }
}
function proccesSaveFunnel(from){
  document.getElementById("alert_danger_save_funnel").innerHTML = ""
 let contentForm =  document.getElementById("funnel-form-save")
 contentForm.style.display = "flex"
  let edit = document.getElementById("editNameBtnFunnel")
  edit.style.display = "none"
  let save = document.getElementById("saveBtnFunnel")
  save.style.display = "flex"
  let type_funnel = document.getElementById("type_funnel")
  type_funnel.style.display = "flex"
  let form = document.getElementById("funnel_form-save")
  contentForm.children[2].innerHTML = "Save funnel"
  if(localStorage.getItem('qyl--nameFunnel')){
    form.elements["name_funnel"].value = localStorage.getItem("funnel_form-save")
  }
  if(from === "strat_funnel"){
    edit.style.display = 'flex'
    type_funnel.style.display = "none"
    save.style.display = "none"
    contentForm.children[2].innerHTML = " Name your funnel"
  }

}
function saveNmaeFunnel(){
  let form = document.getElementById("funnel_form-save")
  localStorage.setItem("funnel_form-save", form.elements["name_funnel"].value )
  form.elements["name_funnel"].value = ""
  document.getElementById("funnel-form-save").style.display = "none"
}
async function clearHeatMap() {
  let displayed = false;
  console.log("Calling clearHeatMap");

  let boxes = document.querySelectorAll(".qly_heatmap_element_hover");

  boxes.forEach((box) => {
    box.classList.remove("qly_heatmap_element_hover");
    displayed = true;
  });

  document.querySelectorAll(".qly--elt_circle_bg").forEach((box) => {
    box.remove();
  });

  boxes = document.querySelectorAll(".qly_heatmap_element");

  boxes.forEach((box) => {
    box.removeEventListener("mouseover", (e) => {
      let el = document.getElementById("/")
      el.style.display = "block";
    });
    box.removeEventListener("mouseout", (e) => {
      let el = document.getElementById("/")
      el.style.display = "none";
    });
    box.classList.remove("qly_heatmap_element");
  });

  boxes = document.querySelectorAll(".qly-line");
  boxes.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  }); 
  let details = document.querySelectorAll(".qly_heatmap_element_detail");
  details.forEach((box) => {
    displayed = true;
    // document.querySelector('heat')
    box.remove();
  }); 
  // chrome.storage.local.set({ heatmap: false });
  return displayed;
}
function MinimizeTable(status) {
  let table = document.getElementById("qly--funnel_list")
  let mi = document.getElementById("qly-minimize--funnel--table")
  let la_minus = chrome.runtime.getURL("/images/icon/la-minus-circle.svg")
  let la_plus = chrome.runtime.getURL("/images/icon/la-plus-circle.svg")
  if(status== "MaximizeTable"){
    table.classList.remove("qly--funnel_list_minimaze")
    mi.innerHTML = ` <img alt="off" id="qly-MinimizeTable" class="qly--minimiza ph-no-capture" src="${la_minus}" />`
  }else{
    table.classList.add("qly--funnel_list_minimaze")
    mi.innerHTML = `<img alt="off" id="qly-MaximizeTable" class="qly--minimiza ph-no-capture" src="${la_plus}" />`
  }
}
async function deleteFunnels(el) {
  let confirm_box = document.getElementById("confirm_box")
  confirm_box.style.display = "block"
  confirm_box.children[0].innerHTML = `Are you sure you want to delete step ${el.target.id} (No. of actual step)?`
  confirm_box.children[1].children[1].addEventListener("click", (e) => {
    let golden_paths = chrome.qly_funnels;
    console.log("sdjmbfjskmbfnsbmdnfmbsfhdghbfjkshjkfhdnskjmfnjksmd",el.target.id)
    let newgolden_paths = golden_paths.filter((ls) => {
      if(ls['step_num'] !== Number(el.target.id)/3){
        return ls
      }
    })

    chrome.qly_funnels = newgolden_paths.map((item ,id)=> {
      item['step_num'] = id
      return item
    })
    let pageName = {}
    pageName[getDomain(window.location.host)] = newgolden_paths.map((item ,id)=> {
      item['step_num'] = id
      return item
    })
    chrome.storage.local.set(pageName)
    confirm_box.style.display = "none"
    refreshTableFunnel()
    confirm_box.innerHTML = `<div class="qly--ipt_group_funnel qly--fnt-family ph-no-capture" >
          </div>
          <div class="qly--confirm_box--bottom qly--fnt-family ph-no-capture">
            <button id="closeConfirm_box" class="ico--btn yellow ph-no-capture qly--fnt-family" >
              <span class="text-btn ph-no-capture qly--fnt-family">Cancel</span>
            </button>
            <button class="ico--btn info ph-no-capture" >
              <span class="text-btn ph-no-capture qly--fnt-family"> Ok </span>
            </button>
          </div>`
  })
}
function deleteAs(el) {
  let golden_paths = chrome.qly_funnels;
  let newgolden_paths = golden_paths.filter((ls, index) => {
      console.log("sdjmbfjskmbfnsbmdnfmbsfhdghbfjkshjkfhdnskjmfnjksmd",ls)
      if(index !== Number(el.target.id) - 1000000){
        return ls
      }
    })
    chrome.qly_funnels = newgolden_paths
    let pageName = {}
    pageName[getDomain(window.location.host)] = newgolden_paths
    chrome.storage.local.set(pageName)
    confirm_box.style.display = "none"
    refreshTableFunnel()
}
async function saveFormEditStep(el){
  let id = null
  if (el.target && el.target.id) {
    id = el.target.id ;
  } else {
    id = el.id  ;
  }
  let colm = document.getElementById(`qly-datatableColum_${id}`);
  let golden_paths = chrome.qly_funnels 
  
  const index = id ;
  let golden_paths_new = await golden_paths.map( (item, id) => {
    if(id  == index ){
      // console.log("fllndjbfkjbjkbkajbjkb",item)
      item.human_label = colm.children[1].innerHTML 
    }
    return item
  })
  chrome.qly_funnels = golden_paths_new
  let pageName = {}
  pageName[getDomain(window.location.host)] = golden_paths_new
  chrome.storage.local.set(pageName)
  refreshTableFunnel()

}
function editFunnels(el) {
  let table = window.dataTable.table().body().children
  if (table.length > 1) {
    for (let i = 0; i < table.length; i++) {
      if (table[i].children[1].hasAttribute("contentEditable")) {
          saveFormEditStep(table[i].children[2].children[1])
      }
    }
  }
  let las_save = chrome.runtime.getURL("/images/icon/las-save2.svg")
  let la_edit = chrome.runtime.getURL("/images/icon/la-edit.svg")
  let funnel = chrome.qly_funnels[ el.target.id]
  let colm =  document.getElementById(`qly-datatableColum_${el.target.id}`)
  let editBtn = colm.lastChild.lastChild.lastChild
  editBtn.classList.remove("editFunnels")
  editBtn.src = las_save
  editBtn.classList.add("saveEditStep")
  colm.children[1].innerHTML = funnel.human_label
  colm.children[1].setAttribute('contentEditable', 'true')
  colm.children[1].focus()
  if(document.getElementsByClassName("saveEditStep")[0]){
    document
      .getElementsByClassName("saveEditStep")[0]
      .addEventListener("click", (e) => {
        e.preventDefault()
        saveFormEditStep(e)
      })
  }
}
function saveFunnel(){
  let project_id = sessionStorage.getItem("qly-project-id");
  let funnels =  chrome.qly_funnels;
  let loader = document.getElementById("qly-indicator-loader_saveFunnel")
  if(!project_id){
    document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> you should select a project before saving a funnel!</div>`
    return
  }
  if(!funnels || funnels.length < 1){
    alert('the list of funnels is empty!')
    return
  }
  // loader.style.display = "flex"
  let form = document.getElementById("funnel-form-save")
  form.style.display = "none"
  const name = form.elements["name_funnel"].value;
  const type = form.elements["type_funnel"].value;
  const funnels_arr = chrome.qly_funnels;
  // console.log("funnels_arr: ", funnels_arr);

  let funnels_stripped = [];
  
  for (let funnel of funnels_arr) {
    // funnel[""]
    // if ("human_label" in funnel) {
    //   delete funnel["human_label"]
    // }
      funnels_stripped.push(funnel);
    // console.log(funnel);
  }
  
  
  chrome.runtime.sendMessage(
    { message: "command", payload: "funnel", name: name, type_funnel: type, project_id: project_id, action: "add" , url: window.location.href , funnel: funnels_stripped},
    function (response) {
      // console.log(response.farewell);
      console.log("Got funnel response: ", response);
      if (!response) {
        alert("An error has occurred while save funnel, please check credentials or network!")
        // document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> An error has occurred while save funnel, please check credentials or network!</div>`
        // loader.style.display = "none"
      } else if (response.payload.status == "failure") {
        alert(`${response.payload.message} `)
        document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> ${response.payload.message} </div>`
      }
      // else {
      //   form.style.display = "none"
      // }
    });
}
function closeAllModal(el) {
  let modal = document.getElementsByClassName("qly--modal")
  for (let i = 0; i < modal.length; i++) {
    if(!el.includes(modal[i].id))
      modal[i].style.display = "none"
  }
}
function showListFunnel() {
  let project_id = sessionStorage.getItem("qly-project-id");
  if(!project_id){
    document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> you should select a project before saving a funnel!</div>`
  }
  const listFunnel = document.getElementById("listFunnel")
  const create = listFunnel.children[3]
  create.style.display = "none"
  const ul = listFunnel.children[4]
  ul.replaceChildren()
  const loader = document.getElementById("qly-indicator-loader--listFunnel")
  loader.style.display = "inline-flex"
  // console.log("jwbefsdbbf nmsz cmn mnbz",project_id)
  chrome.runtime.sendMessage( { message: "command", payload: "funnel", project_id:project_id, action: "list" , url: window.location.href}, 
    function (response) {
      console.log("Got response: ", response);
      // projectDropList_content.appendChild()
      if(!response){
        loader.style.display = 'none'
        const li = document.createElement("li");
        li.classList.add("qly-dropdown-item");
        li.classList.add("ph-no-capture");
        li.appendChild(document.createTextNode("No item found"));
        li.style.color = '#ffff';
        ul.appendChild(li);
        alert("An error has occurred while liste funnel, please check credentials or network!")
      }else if(response.payload.status === "failure"){
        loader.style.display = 'none'
        const li = document.createElement("li");
        li.classList.add("qly-dropdown-item");
        li.classList.add("ph-no-capture");
        li.appendChild(document.createTextNode("no item found"));
        li.style.color = '#ffff';
        ul.appendChild(li);
        alert(response.payload.message)
      }else if(response.payload.response){
        sessionStorage.setItem("listeFunnel",JSON.stringify(response.payload.response.names))
        loader.style.display = 'none'
        for (let el of response.payload.response.names) {
          // console.log("Response: ", el);
          const li = document.createElement("li");
          li.setAttribute('id', el);
          li.classList.add("qly-dropdown-item");
          li.classList.add("ph-no-capture");
          li.style.color = '#ffff';
          li.appendChild(document.createTextNode(el));
          li.addEventListener('click', function handleClick(event) {
            SelectionFunnelName(event.target.id)
          });
          ul.appendChild(li);
        }
      }
    }
  );
}
function SelectionFunnelName(name){
  const el = document.getElementById("listFunnel")
  el.style.display = "none"
  let project_id = sessionStorage.getItem("qly-project-id");
  if(!project_id){
    document.getElementById("alert_danger_save_funnel").innerHTML = `<div class="qly--alert_danger"> you should select a project before saving a funnel!</div>`
    return
  }
  chrome.runtime.sendMessage(
    { message: "command", payload: "funnel", name: name, project_id: project_id, action: "get" , url: window.location.href},
    function (response) {
      // console.log(response.farewell);
      console.log("Got funnel response: ", response);
      if(!response){
        alert("An error has occurred while get funnel, please check credentials or network!")
      }else if(response.payload.status === "failure"){
        alert(response.payload.message)
      } else if (response.payload.status === "success") {
        let newPath = [{
             uuid: uuidv4() 
            }]
        chrome.qly_funnels = newPath.concat(JSON5.parse(response.payload.response.params.contains_elements))
        let pageName = {}
        pageName[getDomain(window.location.host)] = newPath.concat(JSON5.parse(response.payload.response.params.contains_elements))
        chrome.storage.local.set(pageName)
        refreshTableFunnel()
      }
    });
}
async function refreshTableFunnel() {
  sessionStorage.removeItem('errorFunnel')
  let la_edit = chrome.runtime.getURL("/images/icon/la-edit.svg")
  let la_trash = chrome.runtime.getURL("/images/icon/la-trash-alt.svg")
  // let funnels = JSON5.parse(localStorage.getItem("qly_funnels"));
  
  let funnels = chrome.qly_funnels

  if(funnels && funnels.length){

    //  clear all golden paths first
    clearGoldenPaths();
    let last_element = "";
    // Add all items to list
    $("#qly--funnel_list").show();
    $("#qly--funnel_list tbody").empty();
    if (window.dataTable) {
      await window.dataTable.clear().draw();
      console.log("Cleared dataTable");
    } else {
      window.dataTable = $("#qly--funnel_list").DataTable({
        columnDefs: [
          {
            targets: 2,
            render: function (data, type, row) {
              return row[2];
            },
          },
        ],
        columns: [{ searchable: false }, null],
        scrollCollapse: true,
        paging: false,
        searching: false,
        ordering: false,
        info: false,
        createdRow: function (row, data, dataIndex) {
          $(row).addClass('ph-no-capture');
          $(row).attr('id',`qly-datatableColum_${data[0]}`);
          $(row.children).addClass('ph-no-capture')
          $(row.children).addClass('qly--container--focus')
          $(row.children).css('border','none')
        },
      });
    }
    $( window.dataTable.table().body() )
      .addClass( 'ph-no-capture' );
      $(window.dataTable.table().header().children[0].children[0]).css('width', '10%')
      $(window.dataTable.table().header().children[0].children[1]).css('width', '200px')
      $(window.dataTable.table().header().children[0].children[2]).css('width', '35%')
    
    for (const [i, value] of funnels.entries()) {
      let human_label = value["human_label"] || value["xpath"] ;
        // console.log("value: ", value);
       if (!human_label) {
          continue;
        }
      const url = new URL(value["url"])
        window.dataTable.row
          .add([
            i, 
            human_label.slice(0, 40) + (human_label.length > 40 ? '...' : ''),
            `<div style="display: flex;"> <img alt="off" id="${Number(value['step_num'])*3}" class="qly-icon--table ph-no-capture deleteFunnels" src="${la_trash}" style="margin-right: 5px;"/> <img alt="off" id="${i}" class="qly-icon--table ph-no-capture editFunnels" src="${la_edit}" />`])
        .draw(false);
        $(`#${Number(value['step_num'])*3}`).click((e) => {
          deleteFunnels(e)
        })
          let last =  getElementByXPath(last_element["xpath"]) 
          let first =  getElementByXPath(value["xpath"]) 
          if(!first)
            sessionStorage.setItem('errorFunnel','no show xpath')
          if (last && first && last_element["xpath"] !== value["xpath"]) {
            if(!first.classList.contains("qly_funnel_element"))
              first.classList.add("qly_funnel_element")
  
            console.log("To: ", value["xpath"]);
            console.log(
              "Drawing leader line from " + last_element["xpath"]
            );
              new LeaderLine(
                last,
                first,
                {
                  dash: { animation: true },
                  opacity: 0.75,
                  color: "#ffd700",
                  // size = 10 * norm(l["percent"], min_arrow_pct, max_arrow_pct)
                }
              );
          }
  
        last_element = value;
      
    }
  }else{
    if (window.dataTable) {
      window.dataTable.clear().draw();
    }
  }
}
function searchFunnel(el){
  const listeFunnel = JSON.parse(sessionStorage.getItem("listeFunnel"))
  if(listeFunnel){
    const result = listeFunnel.filter(item => {
      if(item.includes(el.target.value))
      return item
    })
    const listFunnel = document.getElementById("listFunnel")
    const create = listFunnel.children[3]
    create.style.display = "none"
    const ul = listFunnel.children[4]
    ul.replaceChildren()
    if(result.length > 0){
      for (let el of result) {
        // console.log("Response: ", el);
        const li = document.createElement("li");
        li.setAttribute('id', el);
        li.classList.add("qly-dropdown-item");
        li.classList.add("ph-no-capture");
        li.style.color = '#ffff';
        li.appendChild(document.createTextNode(el));
        li.addEventListener('click', function handleClick(event) {
          SelectionFunnelName(event.target.id)
        });
        ul.appendChild(li);
      }
    }else{
      const li = document.createElement("li");
      li.classList.add("qly-dropdown-item");
      li.classList.add("ph-no-capture");
      li.style.color = '#ffff';
      li.appendChild(document.createTextNode("no item found"));
      ul.appendChild(li);
      create.style.display = "flex"
      create.children[2].innerHTML = ""
      create.children[2].innerHTML = " " + el.target.value
      sessionStorage.setItem("new_funnel_name", el.target.value)
      console.log(create.children[3])
    }
  }
}
// First time:
// 

function makeid(length) {
  var result           = '';
  var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for ( var i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function showRec() {
  let elt = document.getElementById("headless-recorder-overlay");
  let _l = elt.getBoundingClientRect().left;
  let _b = elt.getBoundingClientRect().bottom - 70;
  
  sessionStorage.setItem("qly-indicator-pos-b", _b);
  sessionStorage.setItem("qly-indicator-pos-l", _l);
  
  if (window.wring_version === "pro") {
    chrome.storage.local.get("recording", (data) => {
      chrome.storage.local.set({ recording: !data["recording"] });
      if(data["recording"]){
        chrome.storage.local.set({ funnel: false });
        clearGoldenPaths(true);
        document.querySelector("body").removeChild(qlyIndicatorContainer);
        renderIndicator(!data["recording"],false);
      } else {
        document.querySelector("body").removeChild(qlyIndicatorContainer);
        renderIndicator(!data["recording"]);
      }
      
    });
  }
}
function showFunnel() {
  console.log("In show funnel");
  
  chrome.storage.local.get("funnel", (data) => {
    if (data['funnel'] === true) {
      chrome.storage.local.set({ funnel: false });
      // btnFunnel.classList.add("qly--heatmap_button_off");
      clearGoldenPaths(true);
      localStorage.removeItem("qly_funnels")
      localStorage.removeItem('qyl--nameFunnel')
      let elt = document.getElementById("headless-recorder-overlay");
      let _l = elt.getBoundingClientRect().left;
      let _b = elt.getBoundingClientRect().bottom - 70;
      
      sessionStorage.setItem("qly-indicator-pos-b", _b);
      sessionStorage.setItem("qly-indicator-pos-l", _l);
      
      if (window.wring_version === "pro") {
        chrome.storage.local.set({ recording: false});
         window.location.reload();
      }
    } else {
      chrome.storage.local.set({ funnel: true });
      clearHeatMap();
      document
      .getElementById("heatmap_view")
      .classList.add("qly--heatmap_button_off");
      chrome.storage.local.set({ heatmap: false });

      // setTimeout(() => {
      //   proccesSaveFunnel("strat_funnel");
      // }, 300);
      let elt = document.getElementById("headless-recorder-overlay");
      let _l = elt.getBoundingClientRect().left;
      let _b = elt.getBoundingClientRect().bottom - 70;
      
      sessionStorage.setItem("qly-indicator-pos-b", _b);
      sessionStorage.setItem("qly-indicator-pos-l", _l);
      let prevUrl = undefined;
        setInterval(() => {
          const currUrl = window.location.href;
          if (currUrl != prevUrl) {
            // URL changed
            prevUrl = currUrl;
            clearGoldenPaths
            refreshTableFunnel()
          }
        }, 60);
      if (window.wring_version === "pro") {
        chrome.storage.local.set({ recording: true});
        document.querySelector("body").removeChild(qlyIndicatorContainer);
        renderIndicator(true,true,false);
      }
      
      let random_funnel_name = makeid(6);
    }
    // renderIndicator()
  })
}
async function chekheatmap(){
  chrome.storage.local.get("heatmap", (data) => {
    if (data['heatmap']) {
      clearHeatMap();
      toggleIndicatorLoader("flex");
      refreshheatmap()
    }
  })
}
async function showHeatMap() {
  console.log("In show heatmap");
  chrome.storage.local.get("heatmap", (hmap) => {
    if(hmap["heatmap"] === true){
      clearHeatMap();
      document
      .getElementById("heatmap_view")
      .classList.add("qly--heatmap_button_off");
      chrome.storage.local.set({ heatmap: false });
    }else{
      chrome.storage.local.set({ funnel: false });
      clearGoldenPaths(true);
      localStorage.removeItem("qly_funnels")
      localStorage.removeItem('qyl--nameFunnel')
      let elt = document.getElementById("headless-recorder-overlay");
      let _l = elt.getBoundingClientRect().left;
      let _b = elt.getBoundingClientRect().bottom - 70;
      
      sessionStorage.setItem("qly-indicator-pos-b", _b);
      sessionStorage.setItem("qly-indicator-pos-l", _l);
      let iconFunnel = document.getElementById("funnel_view")
      iconFunnel.classList.add("qly--heatmap_button_off")
      iconFunnel.children[0].src = chrome.runtime.getURL("/images/qly_funnel.svg")
      // renderIndicator(false,false,true);
      toggleIndicatorLoader("flex");
      refreshheatmap()
      let prevUrl = undefined;
        setInterval(() => {
          const currUrl = window.location.href;
          if (currUrl != prevUrl) {
            // URL changed
            prevUrl = currUrl;
            chekheatmap()
          }
        }, 60);

      
    }
  })
}

function refreshheatmap() {
  let project_id = sessionStorage.getItem("qly-project-id");
  if(!project_id){
    alert("you must select a project before showing heatmap !")
    return
  }
  setTimeout(() => {
    toggleIndicatorLoader("none");
    chrome.storage.local.set({ heatmap: true });
    document
        .getElementById("heatmap_view")
        .classList.remove("qly--heatmap_button_off");
  }, 60000);
  chrome.runtime.sendMessage(
    { message: "command", project_id : project_id, payload: "heatmap", url: window.location.href },
    function (response) {
      // console.log(response.farewell);
      console.log("Got heatmap response: ", response);
      // console.log("elements: ", response.payload.info.data.elements_covering_heatmap);
      const els = response.payload.response;

      let filtered = els.filter(item => item.element.url === window.location.href)
      let xpath_index = {};


      // console.log("Filtered elements: ", filtered);

      let flagged_elements = [];
      let summary_stats = {};

      for (const e of filtered) {
        let xpath = e.element.xpath;
        // console.log("xpath: ", e);
        if (xpath === "/") {
          // print out summary stats
          console.log("Capturing Summary stats: ", e);
          summary_stats["num_sessions"] = e["num_sessions"];
          summary_stats["num_paths_to_element"] = e["num_paths_to_element"];
          summary_stats["num_unique_paths_to_element"] =
            e["num_unique_paths_to_element"];
          // continue;
          xpath = "/body";
        }
        const _elt = document.evaluate(
          xpath,
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        if (_elt) {
          if (
            !_elt.classList.contains("qly") &&
            !_elt.classList.contains("ph-no-capture")
          ) {
            flagged_elements.push({ elt: _elt, details: e });
            xpath_index[xpath] = _elt;
          }
        }
      }

      // console.log("flagged_elements: ", flagged_elements);

      const checkChild = (parent, items) => {
        if (parent.children.length > 0) {
          let ret =
            Array.from(parent.children).filter((t) => items.includes(t))
              .length > 0;

          if (!ret) {
            for (newParent of Array.from(parent.children)) {
              if (checkChild(newParent, items)) {
                return true;
              }
            }
          } else {
            return ret;
          }
        } else {
          return false;
        }
      };

      let all_flagged_elements = flagged_elements.map((val) => val["elt"]);
      let real_flagged_elements = [];

      all_flagged_elements.forEach((fl) => {
        let toDel = checkChild(
          fl,
          all_flagged_elements.filter((e) => e !== fl)
        );

        !toDel && real_flagged_elements.push(fl);
      });

      real_flagged_elements.forEach((elt) => {
        elt.classList.add("qly_heatmap_element_hover");
        // elt.classList.add("qly_zoom");
        // elt.classList.add("qly--highlight");
      });

      // console.log("real_flagged_elements: ", real_flagged_elements);
      // window.endpoints = [];
      // window.jsplumb_elements = [];
      let arrows = [];
      let anchors = [];

      for (const e of flagged_elements) {
        // console.log("element: ", e["elt"]);
        let container = document.createElement("div")
        container.classList.add("qly_heatmap_element_detail")
        container.setAttribute('id', e.details.element.xpath);
        if (e.details.num_paths_to_element) {
          let els = document.createElement("div")
          els.classList.add("qly_heatmap_element_detail_content")
          let span_1 = document.createElement("span");
          let span_2 = document.createElement("span");
          // li.classList.add("qly-dropdown-item");
          span_2.classList.add("ph-no-capture");
          span_2.appendChild(document.createTextNode(e.details.num_paths_to_element ));
          span_1.classList.add("ph-no-capture");
          span_1.appendChild(document.createTextNode(" num_paths_to_element : "));
          els.appendChild(span_1)
          els.appendChild(span_2)
          container.appendChild(els)
        }
        if (e.details.num_sessions) {
          let els = document.createElement("div")
          els.classList.add("qly_heatmap_element_detail_content")
          let span_1 = document.createElement("span");
          let span_2 = document.createElement("span");
          // li.classList.add("qly-dropdown-item");
          span_2.classList.add("ph-no-capture");
          span_2.appendChild(document.createTextNode(e.details.num_sessions ));
          span_1.classList.add("ph-no-capture");
          span_1.appendChild(document.createTextNode(" num_sessions : "));
          els.appendChild(span_1)
          els.appendChild(span_2)
          container.appendChild(els)
        }
        if (e.details.num_unique_paths_to_element) {
          let els = document.createElement("div")
          els.classList.add("qly_heatmap_element_detail_content")
          let span_1 = document.createElement("span");
          let span_2 = document.createElement("span");
          // li.classList.add("qly-dropdown-item");
          span_2.classList.add("ph-no-capture");
          span_2.appendChild(document.createTextNode(e.details.num_unique_paths_to_element ));
          span_1.classList.add("ph-no-capture");
          span_1.appendChild(document.createTextNode(" num_unique_paths_to_element : "));
          els.appendChild(span_1)
          els.appendChild(span_2)
          container.appendChild(els)
        }
        for (const sta of Object.entries(e.details.statistics)) {
          let els = document.createElement("div")
          els.classList.add("qly_heatmap_element_detail_content")
          let span_1 = document.createElement("span");
          let span_2 = document.createElement("span");
          // li.classList.add("qly-dropdown-item");
          span_2.classList.add("ph-no-capture");
          span_2.appendChild(document.createTextNode(" " + sta[1]));
          span_1.classList.add("ph-no-capture");
          span_1.appendChild(document.createTextNode(sta[0] + " :"));
          els.appendChild(span_1)
          els.appendChild(span_2)
          container.appendChild(els)
        }
        document.body.appendChild(container)
        if (e["elt"]) {
          e["elt"].addEventListener("mouseenter", (event) => {
            console.log(event)
            let el = document.getElementById(e.details.element.xpath)
            el.style.display = "block"
            el.classList.add("qly_processOpen")
            let checkHover = document.getElementsByClassName("qly_processOpen")
            if (checkHover) {
              checkHover.forEach((el) => {
                el.classList.remove('qly_processOpen')
                el.style.display = "none"
              })
            }
            // setTimeout(() => {
            //   el.style.display = "block"
            //   el.classList.add("qly_processOpen")
            // }, 2000);
            // const rect = e["elt"].getBoundingClientRect();
            // el.style.top = `${rect.top + window.scrollY}px`
            // if ((rect.left + window.scrollX / 4) > 10) {
            //   el.style.left = `${rect.left + window.scrollX / 4}px`
            // } else {
            //   el.style.right = "10px"
            // }
          })
          e["elt"].addEventListener("mouseleave", (event) => {
            console.log(event)
            let el = document.getElementById(e.details.element.xpath)
            if (el.classList.contains('qly_processOpen')) {
              el.classList.remove("qly_processOpen")
            }
            el.classList.add("qly_processClose")
            // setTimeout(() => {
            //   el.classList.remove("qly_processClose")
            // }, 2000);
            el.style.display = "none"
          })
          let _elt = e["elt"];

          // ADD here
          _elt.classList.add("qly_heatmap_element");
          // _elt.classList.add("qly--highlight");

          for (const nel of e.details.next_elements) {
            // console.log("nel: ", nel);

            // let target_el = xpath_index[nel.xpath];
            let target_el = document.evaluate(
                nel.xpath,
                document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
              ).singleNodeValue;
            // console.log("jhfnjsbdsljflkjwqjhjhq",nel.xpath)
            // let target_el = getElementByXPath(nel.xpath);

            if (target_el && nel.xpath != "/" ) {
              // let one bezier represent 10 percent
              const beziers = Math.floor(nel.percent / 10);
              // console.log("Beziers: ", beziers);

              // console.log("New line: ", _elt, target_el);
              if (_elt !== target_el) {
                arrows.push({
                  src: _elt,
                  // statistics: nel.statistics,
                  target: target_el,
                  percent: nel.percent,
                });
              }
            }
          }
        }
      }

      let max_arrow_pct = 0;
      let min_arrow_pct = 100;
      for (const l of arrows) {
        min_arrow_pct = l["percent"] < min_arrow_pct ? l["percent"] : 100;
        max_arrow_pct = l["percent"] > max_arrow_pct ? l["percent"] : 0;
      }

      function enter(event, props) {
        let props_element = props.element;
        // props.element.classList.add("qly--highlight");
        for (const a of anchors) {
          // Multiple arrows from the same source
          if (a.element === props_element) {
            a.showArrows();
          } else if (a.targetElement === props_element) {
            a.showArrows();
          } else {
            a.hideArrows();
          }
        }
      }

      function leave(event, props) {
        // props.element.classList.remove("qly--highlight");

        for (const a of anchors) {
          // if (a._id !== props_id)
          // {
          a.showArrows();
          // }
        }
      }

      function init(props) {
        // console.log("init props: ", props);
        anchors.push(props);
      }
      lineIndex = 0
      for (const l of arrows) {
        lineIndex++
        const _w = l["target"].clientWidth;
        const _h = l["target"].clientHeight;

        let _dot = document.createElement("span");
        _dot.classList.add("qly--elt_circle_bg");

        // l["src"].style.position = "relative";
        // l["src"].classList.add("qly--highlight");
        // l["src"].classList.add("qly_zoom");
        
        let mhAnchor = LeaderLine.mouseHoverAnchor({
          element: l["src"],
          showEffectName: "draw",
          // target Element stored for hover effects
          targetElement: l["target"],
          style: {},
          mouseEnterCallBack: enter,
          mouseLeaveCallBack: leave,
          initCallback: init,
        });
        if (mhAnchor && l["target"]) {
          let line = new LeaderLine(mhAnchor, l["target"], {
            dash: { animation: true },
            animOptions: {
              duration: 5000,
              timing: "ease-in",
            },
            opacity: 1,
            color: "#23b2ee",
            size: 5,
            endPlug: "arrow3",
            path: "arc",
          });
          // line.size = 7 * norm(l["percent"], 0, max_arrow_pct);
        }
        if(lineIndex > 50)
          break
      }
      chrome.storage.local.set({ heatmap: true });
      toggleIndicatorLoader("none");
      document
        .getElementById("heatmap_view")
        .classList.remove("qly--heatmap_button_off");
    }
  );
}

function hideShowRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    showRecorderPanel();
  } else {
    hideRecorderPanel();
  }
}

function showRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "none") {
    headlessRecorderOverlay.style.display = "block";
  }
}

function hideRecorderPanel() {
  let headlessRecorderOverlay = document.getElementById(
    "headless-recorder-overlay"
  );
  if (headlessRecorderOverlay.style.display === "block") {
    headlessRecorderOverlay.style.display = "none";
  }
}

function toggleIndicatorLoader(val) {
  if(val){
    let elt = document.getElementById("qly-indicator-loader");
    elt.style.display = val;
    console.log("elt: ", elt.style.display);
  }else{
    let elt = document.getElementById("qly-indicator-loader");
    elt.style.display = elt.style.display === "none" ? "flex" : "none";
    console.log("elt: ", elt.style.display);
  }
}
function toggleIndicatorLogo() {
  let elt = document.getElementById("qly-indicator_log_link");
  // closeAllModal("qly-indicator_log_link")
  elt.style.display = elt.style.display === "none" ? "inline-block" : "none";
}
async function screenshot() {
  toggleIndicatorLoader();
  window.scrollTo(0, 0);
  let canvas = await html2canvas(document.body, {
    logging: true,
    letterRendering: 1,
    allowTaint: true,
    useCORS: true,
    height: document.body.getBoundingClientRect().height,
    width: document.body.getBoundingClientRect().width,
    // scrollX: 0,
    // scrollY: 0,
    // scrollY: -window.scrollY,
    // scrollX: -window.scrollX,
    // scrollY: -window.scrollY,
    // windowWidth: document.body.offsetWidth,
    // windowHeight: document.body.scrollHeight,
  });

  function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeString });
    return blob;
  }

  try {
    const handle = await showSaveFilePicker({
      suggestedName: window.location.hostname + ".png",
      types: [
        {
          description: "Screenshot",
          accept: { "image/png": [".png"] },
        },
      ],
    });

    const writableStream = await handle.createWritable();
    await writableStream.write(dataURItoBlob(canvas.toDataURL("image/png")));
    await writableStream.close();
  } catch (err) {
    console.error(err.name, err.message);
  } finally {
    toggleIndicatorLoader();
  }

  // const blob = new Blob(['Some text']);

  // canvas.toBlob(function(blob){
  //   let link = document.createElement("a");
  //   link.href = URL.createObjectURL(blob);
  //   console.log(blob);
  //   console.log(link.href); // this line should be here
  // },'image/png');

  // window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
}
//#endregion

//
// full page screenshot
//
/**
 * Function to call setTimeout with await.
 *
 * @param ms milliseconds to wait
 * @returns {Promise<unknown>}
 */
async function awaitableTimeout(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * This is required to make items with CSS fixed/sticky positions not repeat on the screenshot.
 */
function unStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "fixed"
  );
  stickyElementStorage = [...document.body.getElementsByTagName("*")].filter(
    (elem) =>
      getComputedStyle(elem, null).getPropertyValue("position") === "sticky"
  );
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "absolute"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "relative"));
}

/**
 * This restores any elems that were unattached by unStickElems()
 */
function reStickyElems(fixedElementStorage, stickyElementStorage) {
  fixedElementStorage.forEach((elem) => (elem.style["position"] = "fixed"));
  stickyElementStorage.forEach((elem) => (elem.style["position"] = "sticky"));
}

function getDomain(url){
  let aR = url.split('.')
  let nam = aR.slice(-2, -1)
  let nam2 = aR.slice(-1)
  return nam +'.'+ nam2
}

/**
 * Function to execute a full page screenshot
 * @returns {Promise<void>}
 */
async function pageScreenshot(fullPage= true, interacted_element = null, metadata = null) {
  // indicate we're processing
  
  if (fullPage)
    toggleIndicatorLoader();

  // this stores refs to elements that will be detached for screenshot purposes
  let fixedElements = [];
  let stickyElements = [];

  // save the images in this array
  let screenshotArray = [];
  const imageFilename = window.location.hostname + "-screenshot.png";

  const startingScrollY = window.scrollY;

  // scroll to the top
  if (fullPage)
    window.scroll(0, 0);

  // get the full height of the page
  const pageHeight = Math.max(
    document.body.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.clientHeight,
    document.documentElement.scrollHeight,
    document.documentElement.offsetHeight
  );
  const viewportHeight =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight;

  // not using window.innerWidth because we want to ignore scrollbars
  const viewportWidth =
    document.documentElement.clientWidth || document.body.clientWidth;

  // scroll down by 1 x viewport height each time
  let scrollMaxCount = Math.ceil(pageHeight / viewportHeight);
  console.log(
    `Full page screenshot will scroll the page ${scrollMaxCount} times.`
  );
  // if (scrollMaxCount > 60) {
  //   alert(
  //     "Sorry, this page is too long to be captured in a full page screenshot."
  //   );
  //   window.scroll(0, startingScrollY);
  //   return;
  // }

  try {
    // save current position
    let currentScrollValue = window.scrollY || 0;
    let currentScrollCount = 0;

    // hide the recorder div
    if (fullPage)
      hideShowRecorderPanel();

    // detach fixed-pos and sticky-pos elements
    if (fullPage)
      unStickyElems(fixedElements, stickyElements);

    while (currentScrollCount <= scrollMaxCount) {
      let response = await chrome.runtime.sendMessage({
        message: "command",
        payload: "fullPageScreenshot",
        url: window.location.href,
      });

      console.log("Got response from background script with image.");
      // save the image to the array
      screenshotArray.push([
        response.image,
        currentScrollCount,
        currentScrollValue,
      ]);
      console.log(
        `saved image at scrollY value: ${currentScrollValue}, ` +
          `pageHeight: ${pageHeight}, viewPortHeight: ${viewportHeight}, ` +
          `currentScrollCount: ${currentScrollCount}, ` +
          `scrollMaxCount: ${scrollMaxCount}`
      );

      // scroll down by one viewport height each time
      if (fullPage) {
        window.scroll(0, currentScrollCount * viewportHeight);
        currentScrollCount += 1;
        currentScrollValue = window.scrollY;
      }
      // end loop if not fullpage screenshot
      else {
        scrollMaxCount = -1;
      }
      // wait 250 msec because:
      // https://developer.chrome.com/docs/extensions/reference/tabs/#property-MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND
      await awaitableTimeout(550);
    }

    //
    // done with the loop, we now need to put together the screenshot array into a single image
    //
    
    // console.log("screenshotArray.length: ", screenshotArray.length);

    // if it's a single image, can stop here
    if (screenshotArray.length === 1) {
      
      if (fullPage) {
        const downloadLink = document.createElement("a");
        downloadLink.download = imageFilename;
        downloadLink.rel = "noreferrer noopener";
        // the "data:image/png;base64," bit is already present so no need to add it
        downloadLink.href = screenshotArray[0][0];
        downloadLink.click();
        downloadLink.remove();
        return;
      }
      else {
        // console.log("image base64: ", screenshotArray[0][0]);
        console.log("Got image base64, need to send this to the backend");
        
        
        // Don't send it to backend yet, just add it to local storage
        // let interacted_element = {
        //   "url": window.location.href,
        //   "xpath": abs_xpath,
        //   human_label: getDeepComputedLabel(e.srcElement),
        //   step_num: golden_paths.length+1
        // };
        // let project_api_key = sessionStorage.getItem("qly-project-apiKey")

        // Sending it to the backend immediately causes the problem of linking the image ID to the funnel name
        // As the funnel name is defined later, this can be problematic
        let response = await chrome.runtime.sendMessage({
          message: "command",
          payload: "funnelScreenshot",
          // url: window.location.href,
          image_base64: screenshotArray[0][0],
          element: interacted_element,
          metadata: metadata,
          project_api_key: sessionStorage.getItem("qly-project-apiKey")
        });
        
        
      }
    }

    // otherwise, we have to go through the array, convert each data URI to an image, then paste it into a canvas
    // at its corresponding scrollY
    const cnv = document.createElement("canvas");
    const devicePixelRatio = window.devicePixelRatio;
    cnv.width = viewportWidth * devicePixelRatio;
    cnv.height = pageHeight * devicePixelRatio;

    for (let item of screenshotArray) {
      const [thisImage, thisScrollCount, thisScrollValue] = item;
      let imageObj = new Image();
      imageObj.onload = function () {
        cnv
          .getContext("2d")
          .drawImage(
            imageObj,
            0,
            0,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio,
            0,
            thisScrollValue * devicePixelRatio,
            viewportWidth * devicePixelRatio,
            imageObj.height * devicePixelRatio
          );
      };
      imageObj.src = thisImage;
    }

    // wait for all images to be loaded
    console.log("Waiting for all images to be loaded...");
    await awaitableTimeout(500);

    // save the final image
    const finalImageDataURI = cnv.toDataURL("image/png");
    
    if (fullPage) {
      const downloadLink = document.createElement("a");
      downloadLink.download = imageFilename;
      downloadLink.rel = "noreferrer noopener";
      // the "data:image/png;base64," bit is already present so no need to add it
      downloadLink.href = finalImageDataURI;
      downloadLink.click();
      downloadLink.remove();
    }
    
  } finally {

    if (fullPage) {
      // remove the spinner
      toggleIndicatorLoader();
      // bring the user back to their start Y position
      window.scroll(0, startingScrollY);

      // reattach fixed-pos and sticky-pos elements
      reStickyElems(fixedElements, stickyElements);

      // show the recorder div
      showRecorderPanel();
    }
  }
}
//
// end full page screenshot
//

//#region chrome events
chrome.storage.local.get("activated", (data) => {
  let project_id = sessionStorage.getItem("qly-project-id")
  if (data["activated"]) {
    chrome.storage.local.get("recording", (rec) => {
      chrome.storage.local.get("funnel", (ful) => {
        if (!ful["funnel"]) {
          localStorage.removeItem("qly_funnels")
        }
        let prevUrl = undefined;
        setInterval(() => {
          const currUrl = window.location.href;
          if (currUrl != prevUrl) {
            // URL changed
            prevUrl = currUrl;
            if(ful['funnel']){
              clearGoldenPaths()
              refreshTableFunnel()
            }
            chekheatmap()
          }
        }, 60);
        chrome.storage.local.get("heatmap", (hmap) => {
          renderIndicator(rec["recording"],ful["funnel"],hmap["heatmap"]);
        })
      });
    });
    // showRecorderPanel();
  }
  if (!project_id) {
    chrome.storage.local.get("qly-project-id", idProject => {
      sessionStorage.setItem("qly-project-id",idProject["qly-project-id"])
    })
  }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Got request: ", request);
  if (request.message === "command") {
    // toggleRecord();
    console.log("message is command");
    if (request.payload === "activate") {
      chrome.storage.local.get("activated", (data) => {
        if (data["activated"]) {
          console.log("Showing recorder panel");
          // location.reload();
          // console.log("Reloaded page")

          chrome.runtime.sendMessage(
            { message: "command", payload: "activate" },
            function (response) {
              console.log("Got response: ", response);
              showRecorderPanel();
            }
          );
        } else {
          hideRecorderPanel();
        }
        sendResponse({ message: "success" });
      });
    }
  }
  return true;
});
//#endregion
