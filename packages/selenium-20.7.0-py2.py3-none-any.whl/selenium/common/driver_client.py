"""A module to help with quick testing of the WAL server.

This runs a Selenium webdriver and sends the same information the Java
interceptor sends to the WAL server.

"""

import re
import time
import random
from textwrap import dedent
import logging
import os
import json

import requests

from selenium.common.exceptions import NoSuchElementException
from selenium.common import client

#
# get the logging level
#
set_logging_level = abs(int(os.environ.get("INTERCEPTOR_LOG_LEVEL", "2")))

if set_logging_level == 1:
    loglevel = logging.DEBUG
elif set_logging_level == 2:
    loglevel = logging.INFO
elif set_logging_level == 3:
    loglevel = logging.WARNING
elif set_logging_level == 4:
    loglevel = logging.ERROR

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=loglevel,
    style="{",
    format="[{asctime} TGI-{levelname}] {message}",
    datefmt="%Y-%m-%d %H:%M:%S",
)


#
# utility functions
#

def full_page_dimensions(driver):
    """
    This executes JS to find the full page's dimensions.

    """

    execute_js = dedent(
        """\
        var body = document.body;

        var documentElement = document.documentElement;

        var pageHeight = Math.max(body.scrollHeight,
                                  body.offsetHeight,
                                  documentElement.clientHeight,
                                  documentElement.scrollHeight,
                                  documentElement.offsetHeight);

        var viewportHeight = (window.innerHeight ||
                              documentElement.clientHeight||
                              body.clientHeight);

        var viewportWidth = (window.innerWidth ||
                             documentElement.clientWidth ||
                             body.clientWidth);

        return [pageHeight, viewportHeight, viewportWidth];
        """
    )

    return driver.execute_script(execute_js)


def scroll_to_yoffset(driver, offset):
    """
    Scrolls the webpage to the specified offset in y.

    """

    execute_js = "window.scroll(0, arguments[0]); return [];"
    return driver.execute_script(execute_js, offset)


def get_scroll_yoffset(driver):
    """
    Gets the current y offset.

    """

    execute_js = dedent(
        """\
        var scrY = window.pageYOffset;

        if (scrY) {
          return scrY;
        } else {
          return 0;
        }
        """
    )
    return driver.execute_script(execute_js)


def save_results_to_json(
        request_id,
        original_xpath,
        best_xpath,
        best_element,
        processing_type,
        current_url,
):
    """
    This saves the results for this XPath processing to a JSON file.

    Requires INTERCEPTOR_RESULT_JSON in the environment.

    """

    save_file = os.environ.get("INTERCEPTOR_RESULT_JSON")
    if not save_file:
        return

    save_file = os.path.abspath(save_file)
    save_file = os.path.join(os.path.dirname(save_file),
                             request_id + "-" + os.path.basename(save_file))

    if not os.path.exists(save_file):
        save_object = {
            "requestId": request_id,
            "xpaths": {}
        }

    else:
        with open(save_file, "r") as infd:
            save_object = json.load(infd)

    #
    # update the save_object
    #
    save_object["xpaths"][original_xpath] = {
        "browserUrl": current_url,
        "processingType": processing_type,
    }

    if processing_type in ("heal", "fast-heal"):
        save_object["xpaths"][original_xpath].update({
            "healedXPath": best_xpath,
            "selectedElement": best_element
        })
    else:
        save_object["xpaths"][original_xpath].update({
            "bestSuggestedXPath": best_xpath,
            "bestSuggestedElement": best_element
        })

    #
    # write the updated file
    #
    with open(save_file, "w") as outfd:
        json.dump(save_object, outfd, indent=2)


def get_tag_mutations(tag_mutation_table,
                      walserver_host,
                      walserver_authtoken,
                      xpath_post_req):
    """
    This generates an xpath to select similar webelements to the
    selected element or parses the xpath itself to find similar
    webelements if the target_webelement is None (in case of an
    initial failed selection).

    """

    #
    # parse the xpath no matter what to get the final tag and its mutations
    #
    xpath = xpath_post_req.xpath
    xpath_elems = set({})
    final_element_tag = None

    # figure out the regex to parse the xpath and get the final element tag
    # NOTE: this is the correct version of the previous regex:
    # XPATH_TAG = re.compile(r"/{1,2}[^/]+$")
    # that does not break on the xpath:
    # "//a[@href='/logout' and contains(text(),'Logout')]"
    # see:
    # https://github.com/sshivaji/selenium_tests/commit/
    # 7570b367d1ac8677f7060ba7bc5e0ce7577563b8#commitcomment-42637107

    valid_element_tags = list(tag_mutation_table.keys())
    xpath_frag_regex_str = (
        r"/{1,2}(" + rf"{'|'.join(valid_element_tags)}" + r")[^/]{0,}"
    )
    xpath_frag_regex = re.compile(xpath_frag_regex_str)
    xpath_elem_fragments = xpath_frag_regex.findall(xpath)

    # if the regex succeeds in the getting the final element tag, use that
    if xpath_elem_fragments is not None and len(xpath_elem_fragments) > 0:

        last_frag = xpath_elem_fragments[-1]
        logger.debug(
            f"xpath: {xpath}, element frags: {xpath_elem_fragments}, "
            f"last frag: {last_frag}"
        )

        for tag in tag_mutation_table:
            if f"/{tag}" in last_frag or last_frag == tag:
                final_element_tag = tag
                break

        if final_element_tag is not None:
            xpath_elems.add(final_element_tag)

    # if the regex doesn't work, get all the element tags
    else:
        logger.debug(
            f"Could not get last element tag in xpath: {xpath}, "
            f"using all possible tags in the xpath instead."
        )
        for elem in valid_element_tags:
            if f"/{elem}" in xpath:
                xpath_elems.add(elem)

    # for each of the xpath elems, find their mutation possibilities and add
    # those as well
    xpath_mutation_possibilities = set({})
    for elem in xpath_elems:
        if elem in tag_mutation_table:
            similar_tags = tag_mutation_table[elem]
            for t in similar_tags:
                xpath_mutation_possibilities.add(t)

    xpath_elems = xpath_elems.union(xpath_mutation_possibilities)

    # if this is an "initial request" then current_elements will have an element
    # in it. use it to get the target element's tag for generating the xpath to
    # select elements on the current page that are mutations of the target
    # element.
    if xpath_post_req.current_elements:
        target_tag = xpath_post_req.current_elements[0]["tag"]
        logger.debug("Initial target tag is %s" % target_tag)

    # if not, we'll hit the WAL server to find the initial tag.
    else:

        # hit the WAL server to find the initial element tag
        initial_elem_resp = requests.get(
            f"{walserver_host}/xpath/v1?xPathId={xpath_post_req.xpathid}",
            headers={"Authorization": f"Bearer {walserver_authtoken}"},
            timeout=5.0
        )
        if initial_elem_resp.status_code == 200:

            target_tag = initial_elem_resp.json()["response"]
            logger.debug(
                f"Retrieved initial element "
                f"tag: {target_tag} for xpath: {xpath_post_req.xpath} "
                f"from WAL server."
            )

        else:

            logger.debug(f"Could not find initial element tag "
                         f"request for xpath: {xpath_post_req.xpath}")
            target_tag = None

    #
    # now, add in mutations for the target tag if possible
    #
    if target_tag:
        for mutated_tag in tag_mutation_table.get(target_tag, []):
            xpath_elems.add(mutated_tag)

        # add the target tag
        xpath_elems.add(target_tag)

    if len(xpath_elems) > 0:
        xpath_elem_selector = " | ".join('//%s' % x for x in xpath_elems)
        logger.debug(
            "will use generated xpath: '%s' to select "
            "possible tag mutations for target xpath: '%s'" %
            (xpath_elem_selector, xpath_post_req.xpath)
        )
    else:
        xpath_elems = set(valid_element_tags)
        xpath_elem_selector = "/html/body//*"
        logger.debug("no tag mutation possibilities found for "
                     "xpath: '%s', using fallback xpath: '%s' "
                     "to select all body elements instead." %
                     (xpath_post_req.xpath, xpath_elem_selector))

    return xpath_elem_selector


#
# xpath POST function
#
def xpath_select(driver,
                 url,
                 xpath,
                 walserver_username,
                 walserver_host,
                 walserver_authtoken,
                 walserver_requestid,
                 tag_mutation_table,
                 interceptor_filter_displayed=False,
                 interceptor_filter_enabled=False,
                 driver_refetch_url=False,
                 return_elements=False):
    """This attempts to select an element on the page given the xpath.

    If it succeeds, it will send a POST to /interceptor/xpath/v1 with
    requestType = "initial".

    If it fails, it will send a POST to /interceptor/xpath/v1 with requestType =
    "followup".

    driver_refetch_url = False tells the function not to refetch the URL. This
    is useful if the passed-in driver object already has the URL loaded and in
    the correct state to try the xpath select. If a refetch is needed, set this
    to True.

    Returns the response of the server in either case.

    """

    # get the URL
    if driver_refetch_url:
        driver.get(url)

    # try the xpath select
    try:
        if not return_elements:
            elem = driver.find_element_by_xpath_no_interception(xpath)
            selected_elems = [elem]
        else:
            selected_elems = driver.find_elements_by_xpath_no_interception(xpath)
        if not selected_elems:
            raise NoSuchElementException(
                f"Could not find elements using this xpath: {xpath}"
            )
        request_type = "initial"

    except Exception:
        logger.error("Could not select element by xpath: %s" % xpath)
        selected_elems = []
        request_type = "followup"

    # generate the xpath POST request
    # browser properties
    browser_width = driver.get_window_size().get("width")
    browser_height = driver.get_window_size().get("height")

    page_height, viewport_height, viewport_width = full_page_dimensions(driver)
    y_offset = get_scroll_yoffset(driver)

    page_properties = {
        "pageHeight": page_height,
        "viewportHeight": viewport_height,
        "viewportWidth": viewport_width,
        "yOffset": y_offset,
    }

    # HTML for the entire page
    body_html = driver.execute_script(
        "return document.body.parentNode.outerHTML;"
    )

    # page screenshot
    page_screenshot_b64 = driver.get_screenshot_as_base64()

    # init of the XPathPostRequest
    postreq = client.XPathPostRequest(
        xpath, url,
        request_type,
        walserver_requestid,
        walserver_token=walserver_authtoken,
        walserver_host=walserver_host,
        walserver_username=walserver_username
    )

    # add some items to the request
    postreq.add_selected_elements(selected_elems)
    postreq.add_body_html(body_html)
    postreq.add_page_screenshot(page_screenshot_b64)
    postreq.add_browser_properties(browser_width,
                                   browser_height,
                                   other_properties=page_properties)

    # find tag mutations and add them to the allElements item
    tag_mutations_xpath = get_tag_mutations(tag_mutation_table,
                                            walserver_host,
                                            walserver_authtoken,
                                            postreq)

    # apply the tag mutations xpath and add the selected elements
    similar_elements = driver.find_elements_by_xpath_no_interception(
        tag_mutations_xpath
    )

    # filter out all invisible elements if told to do so
    if interceptor_filter_displayed:
        similar_elements = [
            elem for elem in similar_elements if elem.is_displayed()
        ]
    # filter out all disabled elements if told to do so
    if interceptor_filter_enabled:
        similar_elements = [
            elem for elem in similar_elements if elem.is_enabled()
        ]

    selected_indices = []

    logger.debug("found %s similar elements for target xpath: '%s'" %
                 (len(similar_elements), xpath))
    postreq.add_all_elements(similar_elements)

    if request_type == 'initial':
        for elem in selected_elems:
            if elem in similar_elements:
                selected_indices.append(similar_elements.index(elem))
        postreq.add_element_indices(selected_indices)

    # save the request
    postreq.save_request()
    respdict = postreq.send()

    return respdict, request_type


#
# xpath heal function
#
def xpath_heal(url,
               xpath,
               walserver_username,
               walserver_host,
               walserver_authtoken,
               walserver_requestid,
               walserver_timeout=150.0):
    """This attempts to heal the given xpath using the WAL server.

    Sends a GET to /interceptor/heal/v1/{xPathId}.

    Returns the response of the server.

    """

    # generate a heal request
    heal_getreq = client.HealGetRequest(
        xpath,
        url,
        walserver_requestid,
        walserver_host=walserver_host,
        walserver_token=walserver_authtoken,
        walserver_username=walserver_username
    )

    cumulative_wait_time = 0.0
    n_tries = 0
    wait_step = 1.0

    heal_resp, saved_resp_file = None, None

    while cumulative_wait_time < float(walserver_timeout):

        cumulative_wait_time = cumulative_wait_time + wait_step

        logger.warning(
            "Asking for a healed xpath for URL: '%s', xpath: '%s', "
            "waiting %.1f seconds for try %s..." %
            (url, xpath, wait_step, n_tries + 1)
        )

        time.sleep(wait_step)
        heal_resp, saved_resp_file = heal_getreq.send()

        if not heal_resp:
            logger.error(
                "No heal response from the WAL server. Bailing out..."
            )
            break

        if heal_resp["status"] in ("success", "warning"):
            logger.debug("WAL server finished processing the xpath.")
            break

        if heal_resp["status"] == "failed":
            logger.error(
                "WAL server could not heal this xpath. Bailing out..."
            )
            break

        n_tries = n_tries + 1
        wait_step = 1.75**(n_tries - 1) + random.random()
        if wait_step > 25.0:
            wait_step = 25.0 + random.random()

    #
    # at the end, return the response if any. the caller is responsible for
    # retrying the healed xpath
    #
    return heal_resp, saved_resp_file


def xpath_fast_heal(driver,
                    url,
                    xpath,
                    walserver_username,
                    walserver_host,
                    walserver_authtoken,
                    walserver_requestid,
                    walserver_timeout=150.0):
    """This attempts to fastheal the given xpath using the WAL server.

    Sends a POST to /interceptor/heal/v1/{xPathId}.

    Returns the response of the server.

    """

    # generate a heal request
    heal_postreq = client.FastHealPostRequest(
        xpath,
        url,
        walserver_requestid,
        walserver_host=walserver_host,
        walserver_token=walserver_authtoken,
        walserver_username=walserver_username
    )

    body_html = driver.execute_script(
        "return document.body.parentNode.outerHTML;"
    )

    heal_postreq.add_body_html(body_html)

    cumulative_wait_time = 0.0
    n_tries = 0
    wait_step = 1.0

    heal_resp, saved_resp_file = None, None

    while cumulative_wait_time < float(walserver_timeout):

        cumulative_wait_time = cumulative_wait_time + wait_step

        logger.warning(
            "Asking for a fast-healed xpath for URL: '%s', xpath: '%s', "
            "waiting %.1f seconds for try %s..." %
            (url, xpath, wait_step, n_tries + 1)
        )

        time.sleep(wait_step)
        heal_resp, saved_resp_file = heal_postreq.send()

        if not heal_resp:
            logger.error(
                "No heal response from the WAL server. Bailing out..."
            )
            break

        if heal_resp["status"] in ("success", "warning"):
            logger.debug("WAL server finished processing the xpath.")
            break

        if heal_resp["status"] == "failed":
            logger.error(
                "WAL server could not fast-heal this xpath. Bailing out..."
            )
            break

        n_tries = n_tries + 1
        wait_step = 1.75**(n_tries - 1) + random.random()
        if wait_step > 25.0:
            wait_step = 25.0 + random.random()

    #
    # at the end, return the response if any. the caller is responsible for
    # retrying the healed xpath
    #
    return heal_resp, saved_resp_file


def xpath_suggest(
        driver,
        url,
        xpath,
        walserver_username,
        walserver_host,
        walserver_authtoken,
        walserver_requestid,
        tag_mutation_table,
        walserver_timeout=150.0,
        interceptor_filter_enabled=False,
        interceptor_filter_displayed=False,
):
    """This makes suggestions for the given xpath using the WAL server.

    Sends a POST to suggest/v1/

    Returns the response of the server.

    """

    # generate a suggest request
    suggest_postreq = client.SuggestPostRequest(
        xpath,
        url,
        walserver_requestid,
        walserver_host=walserver_host,
        walserver_token=walserver_authtoken,
        walserver_username=walserver_username
    )

    body_html = driver.execute_script(
        "return document.body.parentNode.outerHTML;"
    )
    #
    # body_html = driver.page_source

    page_screenshot_b64 = driver.get_screenshot_as_base64()
    browser_width = driver.get_window_size().get("width")
    browser_height = driver.get_window_size().get("height")
    page_height, viewport_height, viewport_width = full_page_dimensions(driver)
    y_offset = get_scroll_yoffset(driver)

    page_properties = {
        "pageHeight": page_height,
        "viewportHeight": viewport_height,
        "viewportWidth": viewport_width,
        "yOffset": y_offset,
    }

    tag_mutations_xpath = get_tag_mutations(tag_mutation_table,
                                            walserver_host,
                                            walserver_authtoken,
                                            suggest_postreq)

    # apply the tag mutations xpath and add the selected elements
    similar_elements = driver.find_elements_by_xpath_no_interception(
        tag_mutations_xpath
    )

    # filter out all invisible elements if told to do so
    if interceptor_filter_displayed:
        similar_elements = [
            elem for elem in similar_elements if elem.is_displayed()
        ]
    # filter out all disabled elements if told to do so
    if interceptor_filter_enabled:
        similar_elements = [
            elem for elem in similar_elements if elem.is_enabled()
        ]

    logger.debug("found %s similar elements for target xpath: '%s'" %
                 (len(similar_elements), xpath))
    suggest_postreq.add_similar_elements(similar_elements)
    suggest_postreq.add_body_html(body_html)
    suggest_postreq.add_page_screenshot(page_screenshot_b64)
    suggest_postreq.add_browser_properties(browser_width,
                                           browser_height,
                                           other_properties=page_properties)

    cumulative_wait_time = 0.0
    n_tries = 0
    wait_step = 1.0

    suggest_post_resp, saved_post_resp_file = suggest_postreq.send()

    if suggest_post_resp is None:
        logger.error("xpath-suggest flow failed for xpath: %s" % xpath)
        return None, None

    suggest_getreq = client.SuggestGetRequest(
        xpath,
        url,
        walserver_requestid,
        walserver_host=walserver_host,
        walserver_token=walserver_authtoken,
        walserver_username=walserver_username
    )

    suggest_resp, saved_resp_file = None, None

    try:

        while cumulative_wait_time < float(walserver_timeout):

            cumulative_wait_time = cumulative_wait_time + wait_step

            logger.warning(
                "Asking for a suggested xpaths for URL: '%s', xpath: '%s', "
                "waiting %.1f seconds for try %s..." %
                (url, xpath, wait_step, n_tries + 1)
            )

            time.sleep(wait_step)
            suggest_resp, saved_resp_file = suggest_getreq.send()

            if not suggest_resp:
                logger.error(
                    "No suggested xpaths available from the WAL server."
                )
                break

            if suggest_resp["status"] in ("success", "warning"):
                logger.debug("WAL server finished processing the xpath.")
                break

            if suggest_resp["status"] == "failed":
                logger.error(
                    "WAL server could not suggest any xpaths. "
                    "This xpath needs to be trained with a working "
                    "version of the webpage. Bailing out..."
                )
                break

            n_tries = n_tries + 1
            wait_step = 1.75**(n_tries - 1) + random.random()
            if wait_step > 25.0:
                wait_step = 25.0 + random.random()

        #
        # at the end, return the response if any. the caller is responsible for
        # retrying the suggested xpath
        #
    except Exception:
        logger.exception(
            "Suggest GET request encountered an error. Bailing out..."
        )

    return suggest_resp, saved_resp_file


def process_xpath(driver,
                  url,
                  xpath,
                  walserver_username,
                  walserver_host,
                  walserver_authtoken,
                  walserver_requestid,
                  tag_mutation_table,
                  use_interceptor=True,
                  interceptor_filter_enabled=False,
                  interceptor_filter_displayed=False,
                  interceptor_fast_heal=False,
                  interceptor_handle_failure="suggest-xpaths",
                  driver_refetch_url=False,
                  walserver_timeout=150.0,
                  warnings_are_errors=False,
                  return_webelement=True,
                  return_elements=True):
    """This runs a heal-cycle for a single xpath.

    """

    if use_interceptor:
        logger.info(f"Processing xpath: {xpath}...")

    # first, try the xpath select, and post the xpath to the WAL server
    walserver_post_resp, request_type = xpath_select(
        driver,
        url,
        xpath,
        walserver_username,
        walserver_host,
        walserver_authtoken,
        walserver_requestid,
        tag_mutation_table,
        interceptor_filter_enabled=interceptor_filter_enabled,
        interceptor_filter_displayed=interceptor_filter_displayed,
        driver_refetch_url=driver_refetch_url,
        return_elements=return_elements
    )

    if request_type == "initial":

        logger.debug("xpath: '%s' for URL: '%s' does not require healing." %
                     (xpath, url))
        if driver_refetch_url:
            driver.get(url)
        if return_elements:
            selected_elem = (
                driver.find_elements_by_xpath_no_interception(xpath)
            )
        else:
            selected_elem = (
                driver.find_element_by_xpath_no_interception(xpath)
            )

        if return_webelement:
            return selected_elem
        else:
            return True

    elif not use_interceptor:

        raise NoSuchElementException(
            f"Could not find elements using "
            f"xpath: {xpath} and USE_INTERCEPTOR=0."
        )

    else:

        try:

            if interceptor_fast_heal:

                logger.debug(
                    "Fast-Heal option is turned on. "
                    "Will attempt to fast-heal before normal healing"
                )

                fast_heal_resp, saved_resp_file = xpath_fast_heal(
                    driver,
                    url,
                    xpath,
                    walserver_username,
                    walserver_host,
                    walserver_authtoken,
                    walserver_requestid,
                    walserver_timeout=walserver_timeout
                )

                if fast_heal_resp:

                    # if healing succeeds
                    if fast_heal_resp["status"] == "success":

                        logger.debug(
                            "retrying fast-healed xpath: '%s' on URL: '%s'. "
                            "previously failed xpath was: '%s'" %
                            (fast_heal_resp["bestXPath"], url, xpath)
                        )

                        try:

                            if driver_refetch_url:
                                driver.get(url)
                            if return_elements:
                                selected_elem = (
                                    driver.find_elements_by_xpath_no_interception(
                                        fast_heal_resp["bestXPath"]
                                    )
                                )
                            else:
                                selected_elem = (
                                    driver.find_element_by_xpath_no_interception(
                                        fast_heal_resp["bestXPath"]
                                    )
                                )
                            logger.debug(
                                "fast-healed xpath: '%s' worked successfully" %
                                fast_heal_resp["bestXPath"]
                            )

                            #
                            # log the processing result and save it to JSON
                            #
                            log_message = dedent(
                                f"""The TestGold API successfully healed this xpath.

                                Browser URL: {driver.current_url}
                                Original XPath: {xpath}
                                Healed XPath: {fast_heal_resp['bestXPath']}
                                Selected element: {fast_heal_resp['bestElementHtml']}
                                """
                            )
                            logger.warning(log_message)
                            save_results_to_json(
                                walserver_requestid,
                                xpath,
                                fast_heal_resp['bestXPath'],
                                fast_heal_resp['bestElementHtml'],
                                "fast-heal",
                                driver.current_url,
                            )

                            if return_webelement:
                                return selected_elem
                            else:
                                return fast_heal_resp

                        except Exception:

                            logger.warning(
                                "fast-healed xpath: '%s' for URL: '%s' "
                                "does not work. Will have to do normal healing" %
                                (fast_heal_resp["bestXPath"], url)
                            )
                            raise

                    # handle new warning status
                    elif fast_heal_resp["status"] == "warning":

                        #
                        # log the processing result and save it to JSON
                        #
                        log_message = dedent(
                            f"""The TestGold API successfully healed this xpath.

                            Browser URL: {driver.current_url}
                            Original XPath: {xpath}
                            Healed XPath: {fast_heal_resp['bestXPath']}
                            Selected element: {fast_heal_resp['bestElementHtml']}
                            """
                        )
                        logger.warning(log_message)
                        save_results_to_json(
                            walserver_requestid,
                            xpath,
                            fast_heal_resp['bestXPath'],
                            fast_heal_resp['bestElementHtml'],
                            "fast-heal",
                            driver.current_url,
                        )

                        if fast_heal_resp["warnings"]:
                            for k, v in fast_heal_resp["warnings"].items():
                                logger.warning("%s: %s" %
                                               (k.upper(), v["message"]))

                        if warnings_are_errors:
                            raise NoSuchElementException(
                                "The WAL server could not fast-heal this xpath."
                            )

                        if return_webelement:
                            if return_elements:
                                selected_elem = (
                                    driver.find_elements_by_xpath_no_interception(
                                        fast_heal_resp["bestXPath"]
                                    )
                                )
                            else:
                                selected_elem = (
                                    driver.find_element_by_xpath_no_interception(
                                        fast_heal_resp["bestXPath"]
                                    )
                                )
                            logger.debug(
                                "fast-healed xpath: '%s' worked successfully" %
                                fast_heal_resp["bestXPath"]
                            )
                            return selected_elem
                        else:
                            return fast_heal_resp

                    # if the healing status is anything other than "success" or
                    # "warning"
                    else:

                        raise NoSuchElementException(
                            "The WAL server could not fast-heal this xpath."
                        )

                else:
                    logger.debug(
                        "The WAL server did not respond to a fast-heal request."
                        " Will continue with normal healing"
                    )

            #
            # normal healing
            #

            if use_interceptor:
                heal_resp, saved_resp_file = xpath_heal(
                    url,
                    xpath,
                    walserver_username,
                    walserver_host,
                    walserver_authtoken,
                    walserver_requestid,
                    walserver_timeout=walserver_timeout,
                )
            else:
                heal_resp = False

            if heal_resp:

                # if healing succeeds
                if heal_resp["status"] == "success":

                    logger.debug("retrying healed xpath: '%s' on URL: '%s'. "
                                 "previously failed xpath was: '%s'" %
                                 (heal_resp["bestXPath"], url, xpath))

                    try:

                        if driver_refetch_url:
                            driver.get(url)
                        if return_elements:
                            selected_elem = (
                                driver.find_elements_by_xpath_no_interception(
                                    heal_resp["bestXPath"]
                                )
                            )
                        else:
                            selected_elem = (
                                driver.find_element_by_xpath_no_interception(
                                    heal_resp["bestXPath"]
                                )
                            )
                        logger.debug("healed xpath: '%s' worked successfully" %
                                     heal_resp["bestXPath"])

                        #
                        # log the processing result and save it to JSON
                        #
                        log_message = dedent(
                            f"""The TestGold API successfully healed this xpath.

                            Browser URL: {driver.current_url}
                            Original XPath: {xpath}
                            Healed XPath: {heal_resp['bestXPath']}
                            Selected element: {heal_resp['bestElementHtml']}
                            """
                        )
                        logger.warning(log_message)
                        save_results_to_json(
                            walserver_requestid,
                            xpath,
                            heal_resp['bestXPath'],
                            heal_resp['bestElementHtml'],
                            "heal",
                            driver.current_url,
                        )

                        if return_webelement:
                            return selected_elem
                        else:
                            return heal_resp

                    except Exception:

                        logger.error(
                            "healed xpath: '%s' for URL: '%s' does not work." %
                            (heal_resp["bestXPath"], url)
                        )
                        raise

                # handle new warning status
                elif heal_resp["status"] == "warning":

                    #
                    # log the processing result and save it to JSON
                    #
                    log_message = dedent(
                        f"""The TestGold API successfully healed this xpath.

                        Browser URL: {driver.current_url}
                        Original XPath: {xpath}
                        Healed XPath: {heal_resp['bestXPath']}
                        Selected element: {heal_resp['bestElementHtml']}
                        """
                    )
                    logger.warning(log_message)
                    save_results_to_json(
                        walserver_requestid,
                        xpath,
                        heal_resp['bestXPath'],
                        heal_resp['bestElementHtml'],
                        "heal",
                        driver.current_url,
                    )

                    if heal_resp["warnings"]:
                        for k, v in heal_resp["warnings"].items():
                            logger.warning("%s: %s" %
                                           (k.upper(), v["message"]))

                    if warnings_are_errors:
                        raise NoSuchElementException(
                            "The WAL server could not heal this xpath."
                        )

                    if return_webelement:
                        if return_elements:
                            selected_elem = (
                                driver.find_elements_by_xpath_no_interception(
                                    heal_resp["bestXPath"]
                                )
                            )
                        else:
                            selected_elem = (
                                driver.find_element_by_xpath_no_interception(
                                    heal_resp["bestXPath"]
                                )
                            )
                        logger.debug("healed xpath: '%s' worked successfully" %
                                     heal_resp["bestXPath"])
                        return selected_elem
                    else:
                        return heal_resp

                # if the healing status is anything other than "success" or
                # "warning"
                else:

                    raise NoSuchElementException(
                        "The WAL server could not heal this xpath."
                    )

            else:

                logger.error("The WAL server did not respond to a heal request.")
                raise NoSuchElementException(
                    f"Could not heal xpath: {xpath}"
                )

        except Exception:

            if use_interceptor and interceptor_handle_failure == 'suggest-xpaths':

                logger.warning(
                    "executing xpath-suggest flow for xpath: '%s' "
                    "because healing didn't work and "
                    "INTERCEPTOR_HANDLE_FAILURE=%s" %
                    (xpath, interceptor_handle_failure)
                )

                if driver_refetch_url:
                    driver.get(url)

                suggest_resp, save_resp_file = xpath_suggest(
                    driver,
                    url,
                    xpath,
                    walserver_username,
                    walserver_host,
                    walserver_authtoken,
                    walserver_requestid,
                    tag_mutation_table,
                    walserver_timeout=walserver_timeout,
                    interceptor_filter_enabled=interceptor_filter_enabled,
                    interceptor_filter_displayed=interceptor_filter_displayed
                )

                if suggest_resp:

                    suggestedFixes = suggest_resp["suggestedFixes"]
                    suggestedXPaths = suggestedFixes["candidateXPaths"]
                    suggestedElements = suggestedFixes["candidateElements"]

                    # if suggesting succeeds
                    if suggest_resp["status"] == "success":

                        #
                        # log the processing result and save it to JSON
                        #
                        log_message = dedent(
                            f"""The TestGold API generated alternative suggestions for this xpath.

                            Browser URL: {driver.current_url}
                            Original XPath: {xpath}
                            Best suggested XPath: {suggestedXPaths[0]}
                            Best suggested selected element: {suggestedElements[0]['element']}

                            Please check if this is the element you intended to
                            select with your original xpath.
                            """
                        )
                        logger.warning(log_message)
                        save_results_to_json(
                            walserver_requestid,
                            xpath,
                            suggestedXPaths[0],
                            suggestedElements[0]['element'],
                            "suggest",
                            driver.current_url,
                        )

                        logger.debug(
                            "retrying suggested xpath: '%s' on URL: '%s'. "
                            "previously failed xpath was: '%s'" %
                            (suggestedXPaths[0], url, xpath)
                        )

                        try:

                            if driver_refetch_url:
                                driver.get(url)
                            if return_elements:
                                selected_elem = (
                                    driver.find_elements_by_xpath_no_interception(
                                        suggestedXPaths[0]
                                    )
                                )
                            else:
                                selected_elem = (
                                    driver.find_element_by_xpath_no_interception(
                                        suggestedXPaths[0]
                                    )
                                )
                            logger.debug(
                                "suggested xpath: '%s' worked successfully" %
                                suggestedXPaths[0]
                            )

                            if return_webelement:
                                return selected_elem
                            else:
                                return suggest_resp

                        except Exception:

                            logger.error(
                                "suggested xpath: '%s' for "
                                "URL: '%s' does not work." %
                                (suggestedXPaths[0], url)
                            )
                            raise

                    # handle new warning status
                    elif suggest_resp["status"] == "warning":

                        #
                        # log the processing result and save it to JSON
                        #
                        log_message = dedent(
                            f"""The TestGold API generated alternative suggestions for this xpath.

                            Browser URL: {driver.current_url}
                            Original XPath: {xpath}
                            Best suggested XPath: {suggestedXPaths[0]}
                            Best suggested selected element: {suggestedElements[0]['element']}

                            Please check if this is the element you intended to
                            select with your original xpath.

                            """
                        )
                        logger.warning(log_message)
                        save_results_to_json(
                            walserver_requestid,
                            xpath,
                            suggestedXPaths[0],
                            suggestedElements[0]['element'],
                            "suggest",
                            driver.current_url,
                        )

                        if suggest_resp.get("warnings"):
                            for k, v in suggest_resp["warnings"].items():
                                logger.warning("%s: %s" %
                                               (k.upper(), v["message"]))

                        if warnings_are_errors:
                            raise NoSuchElementException(
                                f"The WAL server could not suggest"
                                f" an alternative xpath to: {xpath}"
                            )

                        if return_webelement:
                            if return_elements:
                                selected_elem = (
                                    driver.find_elements_by_xpath_no_interception(
                                        suggestedXPaths[0]
                                    )
                                )
                            else:
                                selected_elem = (
                                    driver.find_element_by_xpath_no_interception(
                                        suggestedXPaths[0]
                                    )
                                )
                            logger.debug(
                                "suggested xpath: '%s' worked successfully" %
                                suggestedXPaths[0]
                            )
                            return selected_elem
                        else:
                            return suggest_resp

                    # if the suggest status is anything other than "success" or
                    # "warning"
                    else:

                        raise NoSuchElementException(
                            f"The WAL server could not suggest any "
                            f"alternatives for xpath: {xpath}. "
                            f"This xpath will need to be trained on a working "
                            f"version of the webpage."
                        )

                else:
                    logger.error(
                        "The WAL server did not respond to a suggest request."
                    )
                    raise NoSuchElementException(
                        f"XPath {xpath} does not work and cannot be "
                        f"fixed."
                    )

            else:
                raise NoSuchElementException(
                    f"XPath {xpath} does not work and cannot be "
                    f"fixed because USE_INTERCEPTOR=0."
                )
