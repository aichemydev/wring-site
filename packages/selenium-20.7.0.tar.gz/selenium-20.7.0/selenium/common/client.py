"""
This is a client module for the WAL server.

"""

import json
import hashlib
from datetime import date
import os.path
import urllib.parse
import time

import requests

import logging

#
# get the logging level
#
set_logging_level = abs(int(os.environ.get("INTERCEPTOR_LOG_LEVEL", "2")))

if set_logging_level == 1:
    loglevel = logging.DEBUG
elif set_logging_level == 2:
    loglevel = logging.INFO
elif set_logging_level == 3:
    loglevel = logging.WARNING
elif set_logging_level == 4:
    loglevel = logging.ERROR

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=loglevel,
    style="{",
    format="[{asctime} TGI-{levelname}] {message}",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def serialize_webelement(webelement, tojson=False):
    """
    This turns a WebElement returned from Selenium into a dict.

    """

    # items from the webelement
    elementId = webelement.id
    text = webelement.text
    tag = webelement.tag_name
    width = int(webelement.rect["width"])
    height = int(webelement.rect["height"])
    x = int(webelement.rect["x"])
    y = int(webelement.rect["y"])
    is_enabled = webelement.is_enabled()
    is_displayed = webelement.is_displayed()
    css_class = webelement.get_attribute("class")
    html_name = webelement.get_attribute("name")
    html_id = webelement.get_attribute("id")
    outer_html = webelement.get_attribute("outerHTML")
    inner_html = webelement.get_attribute("innerHTML")

    webelement_dict = {
        "elementId": elementId,
        "text": text,
        "tag": tag,
        "width": width,
        "height": height,
        "x": x,
        "y": y,
        "isEnabled": is_enabled,
        "isDisplayed": is_displayed,
        "cssClass": css_class,
        "htmlName": html_name,
        "htmlId": html_id,
        "outerHtml": outer_html,
        "innerHtml": inner_html,
    }

    if tojson:
        return json.dumps(webelement_dict)
    else:
        return webelement_dict


class XPathPostRequest:
    """This encapsulates the interface to the WAL server's POST /xpath endpoint.

    This handles:

    1. the "initial" POST request with a correct webpage and a good xpath
    2. a "followup" POST request with the broken webpage and a now-broken xpath

    In each of these cases, we send all the info so the WAL server has the
    information needed to process the xpath.

    """

    def __init__(
            self,
            xpath,
            url,
            request_type,
            walserver_requestid,
            walserver_token='wal-server-authtoken',
            walserver_host='http://localhost:9090/interceptor',
            walserver_username='anonymous'
    ):
        """This makes a XpathPostRequest object.

        xpath is the xpath to upload

        url is the full URL of the webpage we're processing (including hostname)

        request_type is either:

        "initial" -> if this is the first POST request that contains a working
                     xpath and correct webpage structure

        "followup" -> if this is any other POST request that now contains the
                      same xpath that does not work any more and the
                      now-changed webpage structure

        """

        self.xpath = xpath
        self.url = url
        self.walserver_host = walserver_host
        self.walserver_token = walserver_token
        self.walserver_username = walserver_username
        self.request_type = request_type

        self.walserver_requestid = walserver_requestid
        if not walserver_requestid:
            raise ValueError("A request ID is required.")

        # generate the URL for the WAL server's xpath POST endpoint
        self.walserver_xpath_url = (
            "{walserver_host}/xpath/v1".format(
                walserver_host=self.walserver_host,
            )
        )

        # generate the header dict for the WAL server requests
        self.walserver_headers = {
            "Authorization": "Bearer %s" % self.walserver_token
        }

        # this is now required for history matching of POST requests
        self.sent_at = int(time.time())

        # break apart the provided webpage URL to its fragment and the hostname.

        # we need to do this because we should not use the full URL to construct
        # the xPathId, but we should use the URL fragment (e.g. use only
        # "/some/url/path" from a website address of
        # http://some.website.com/some/url/path). This is because we can have
        # the same URL structure and the same webpage but want to test it on
        # separate host names (e.g. http://dev.website.com/some/url/path and
        # http://some.website.com/some/url/path), so the xPathIds should remain
        # the same between these two.

        # here, self.parsed_url.netloc is the hostname
        # and self.parsed_url.path is the URL fragment we want

        self.parsed_url = urllib.parse.urlsplit(self.url)

        # generate our session ID
        week_number = date.today().isocalendar()[1]
        session_hash = "{url}|{week_number}|{walserver_username}".format(
            url=self.parsed_url.path,
            week_number=week_number,
            walserver_username=self.walserver_username
        )
        self.sessionid = hashlib.sha256(
            session_hash.encode("utf-8")
        ).hexdigest()

        # generate our xpath ID
        xpathid_hash = "{xpath}|{url}".format(
            xpath=self.xpath,
            url=self.parsed_url.path,
        )
        self.xpathid = hashlib.sha256(xpathid_hash.encode("utf-8")).hexdigest()

        # make the cache directory
        self.cachedir = self.make_cache_dir()

        # empty serialized POST request on init
        self.serialized_post_request = {
            "walServerRequestId": self.walserver_requestid,
            "requestType": self.request_type,
            "xPathId": self.xpathid,
            "sessionId": self.sessionid,
            "sentAt": self.sent_at,
            "currentElements": [],
            "xpath": self.xpath,
            "bodyHTML": None,
            "allElements": [],
            "pageScreenshot": None,
            "browserProperties": {
                "browserWidth": None,
                "browserHeight": None,
                "currentURL": self.url
            }
        }

        self.other_properties = None

    def make_cache_dir(self):
        """
        Makes the cache directory.

        """

        cache_dir = os.path.abspath(
            os.path.join(
                os.path.expanduser('~'),
                ".testgold",
                self.sessionid,
            )
        )
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def save_to_file(self, local_path=None):
        """This saves the request's JSON to the specified local path
        or the default .testgold cache directory if none is specified.

        """

        if local_path:
            self.saved_req_file = local_path

        if local_path is None:

            self.saved_req_file = os.path.join(
                self.cachedir,
                "%s-%s-post-request.json" % (self.xpathid, self.request_type)
            )

        with open(self.saved_req_file, 'w') as outfd:
            outfd.write(json.dumps(self.serialized_post_request, indent=2))

        return os.path.abspath(self.saved_req_file)

    def add_selected_elements(self, selected_elements):
        """
        This adds a list of WebElements that were selected
        by the xpath selector.

        The selected elements are dicts.

        """

        self.current_elements = [
            serialize_webelement(x) for x in selected_elements
        ]

    def add_body_html(self, body_html):
        """
        This adds the body HTML of the page as a string.

        """

        self.body_html = body_html

    def add_all_elements(self, all_elements):
        """
        This adds a list of all elements.

        List of elements are a list of Selenium WebElements.

        """

        self.all_page_elements = [
            serialize_webelement(x) for x in all_elements
        ]

    def add_element_indices(self,
                            indices):
        """
        This adds indices of selected elements in a list of all similar elements
        :param indices:
        :return:
        """
        for i in range(len(self.current_elements)):
            self.current_elements[i]['index'] = indices[i]

    def add_page_screenshot(self, page_screenshot_b64):
        """
        This adds a page screenshot in base64.

        """
        self.page_screenshot_b64 = page_screenshot_b64

    def add_browser_properties(self,
                               browser_width,
                               browser_height,
                               other_properties=None):
        """
        This adds the browser properties.

        """

        self.browser_width = browser_width
        self.browser_height = browser_height
        self.other_properties = other_properties

    def serialize(self, tojson=False):
        """This turns the full request into a dict, and optionally
        dumps it to a JSON string.

        """

        self.serialized_post_request = {
            "walServerRequestId": self.walserver_requestid,
            "requestType": self.request_type,
            "xPathId": self.xpathid,
            "sessionId": self.sessionid,
            "sentAt": self.sent_at,
            "currentElements": self.current_elements,
            "xpath": self.xpath,
            "bodyHTML": self.body_html,
            "allElements": self.all_page_elements,
            "pageScreenshot": self.page_screenshot_b64,
            "browserProperties": {
                "browserWidth": self.browser_width,
                "browserHeight": self.browser_height,
                "currentURL": self.url
            }
        }

        if self.other_properties is not None:
            self.serialized_post_request["browserProperties"].update(
                self.other_properties
            )

        if tojson:
            return json.dumps(self.serialized_post_request, indent=2)
        else:
            return self.serialized_post_request

    def send(self,
             timeout=10.0,
             save_response=True):
        """Send the request to the WAL server.

        Returns the response as a dict deserialized from the JSON the WAL server
        sends back.

        """

        try:

            resp = requests.post(
                self.walserver_xpath_url,
                timeout=timeout,
                headers=self.walserver_headers,
                json=self.serialize(),
            )
            resp.raise_for_status()

            resp_dict = resp.json()

            if save_response:

                local_path = os.path.join(
                    self.cachedir,
                    "%s-%s-response.json" % (
                        self.xpathid,
                        "%s-post" % self.request_type
                    )
                )

                with open(local_path, 'w') as outfd:
                    outfd.write(json.dumps(resp_dict, indent=2))

            return resp_dict

        except Exception:

            logger.error(
                "Could not POST xpath request to the WAL server."
            )
            return None

    def save_request(self):
        """
        This saves the request to a file.

        """

        self.serialized_post_request = self.serialize()
        return self.save_to_file()


class HealGetRequest:
    """This encapsulates the interface to the WAL server's GET /heal/v1 endpoint.

    This handles the GET request to get a healed xpath based on the URL and
    xpath sent previously in the POST requests.

    """

    def __init__(
            self,
            xpath,
            url,
            walserver_requestid,
            walserver_token='wal-server-authtoken',
            walserver_host='http://localhost:9090/interceptor',
            walserver_username='anonymous'
    ):
        """
        This makes a XpathPostRequest object.

        """

        self.xpath = xpath
        self.url = url
        self.walserver_host = walserver_host
        self.walserver_token = walserver_token
        self.walserver_username = walserver_username

        self.walserver_requestid = walserver_requestid
        if not walserver_requestid:
            raise ValueError("A WAL server request ID is required.")

        # generate the header dict for the WAL server requests
        self.walserver_headers = {
            "Authorization": "Bearer %s" % self.walserver_token
        }

        # break apart the provided webpage URL to its fragment and the hostname.

        # we need to do this because we should not use the full URL to construct
        # the xPathId, but we should use the URL fragment (e.g. use only
        # "/some/url/path" from a website address of
        # http://some.website.com/some/url/path). This is because we can have
        # the same URL structure and the same webpage but want to test it on
        # separate host names (e.g. http://dev.website.com/some/url/path and
        # http://some.website.com/some/url/path), so the xPathIds should remain
        # the same between these two.

        # here, self.parsed_url.netloc is the hostname
        # and self.parsed_url.path is the URL fragment we want
        self.parsed_url = urllib.parse.urlsplit(self.url)

        # generate our session ID
        week_number = date.today().isocalendar()[1]
        session_hash = "{url}|{week_number}|{walserver_username}".format(
            url=self.parsed_url.path,
            week_number=week_number,
            walserver_username=self.walserver_username
        )
        self.sessionid = hashlib.sha256(
            session_hash.encode("utf-8")
        ).hexdigest()

        # generate our xpath ID
        xpathid_hash = "{xpath}|{url}".format(
            xpath=self.xpath,
            url=self.parsed_url.path,
        )
        self.xpathid = hashlib.sha256(xpathid_hash.encode("utf-8")).hexdigest()

        self.cachedir = self.make_cache_dir()

        # generate the URL for the WAL server's /heal GET endpoint
        self.walserver_heal_url = (
            f"{self.walserver_host}/heal/v1/{self.xpathid}"
        )

    def make_cache_dir(self):
        """
        Makes the cache directory.

        """

        cache_dir = os.path.abspath(
            os.path.join(
                os.path.expanduser('~'),
                ".testgold",
                self.sessionid,
            )
        )
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def send(self,
             timeout=10.0,
             save_response=True):
        """Sends the GET /heal/v1/{xpathid} request to the WAL server.

        Returns the response as a dict deserialized from the JSON the WAL server
        sends back.

        """

        self.saved_req_file = None

        try:

            resp = requests.get(
                self.walserver_heal_url,
                timeout=timeout,
                headers=self.walserver_headers,
            )
            resp.raise_for_status()

            resp_dict = resp.json()

            if save_response:

                self.saved_req_file = os.path.join(
                    self.cachedir,
                    "%s-%s-get-response.json" % (self.xpathid, "heal")
                )

                with open(self.saved_req_file, 'w') as outfd:
                    outfd.write(json.dumps(resp_dict, indent=2))

            return resp_dict, self.saved_req_file

        except Exception:

            logger.error(
                "Could not GET healed xpath from the WAL server."
            )
            return None, self.saved_req_file


class FastHealPostRequest:
    """This encapsulates the interface to the WAL server's POST /heal/v1 endpoint.

    This handles the POST request to get a fasthealed xpath based on the healing
    history of given xpathid.

    """

    def __init__(
            self,
            xpath,
            url,
            walserver_requestid,
            walserver_token='walserver-authtoken',
            walserver_host='http://localhost:9090/interceptor',
            walserver_username="anonymous"
    ):
        """
        This makes a XpathPostRequest object.

        """

        self.xpath = xpath
        self.url = url
        self.bodyHTML = None
        self.walserver_host = walserver_host
        self.walserver_token = walserver_token
        self.walserver_username = walserver_username

        self.walserver_requestid = walserver_requestid
        if not walserver_requestid:
            raise ValueError("A WAL server request ID is required.")

        # generate the header dict for the WAL server requests
        self.walserver_headers = {
            "Authorization": "Bearer %s" % self.walserver_token
        }

        # break apart the provided webpage URL to its fragment and the hostname.

        # we need to do this because we should not use the full URL to construct
        # the xPathId, but we should use the URL fragment (e.g. use only
        # "/some/url/path" from a website address of
        # http://some.website.com/some/url/path). This is because we can have
        # the same URL structure and the same webpage but want to test it on
        # separate host names (e.g. http://dev.website.com/some/url/path and
        # http://some.website.com/some/url/path), so the xPathIds should remain
        # the same between these two.

        # here, self.parsed_url.netloc is the hostname
        # and self.parsed_url.path is the URL fragment we want
        self.parsed_url = urllib.parse.urlsplit(self.url)

        # generate our session ID
        week_number = date.today().isocalendar()[1]
        session_hash = "{url}|{week_number}|{walserver_username}".format(
            url=self.parsed_url.path,
            week_number=week_number,
            walserver_username=self.walserver_username,
        )
        self.sessionid = hashlib.sha256(
            session_hash.encode("utf-8")
        ).hexdigest()

        # generate our xpath ID
        xpathid_hash = "{xpath}|{url}".format(
            xpath=self.xpath,
            url=self.parsed_url.path,
        )
        self.xpathid = hashlib.sha256(xpathid_hash.encode("utf-8")).hexdigest()

        self.cachedir = self.make_cache_dir()

        # generate the URL for the WAL server's /heal GET endpoint
        self.walserver_heal_url = (
            f"{self.walserver_host}/heal/v1/{self.xpathid}"
        )

    def make_cache_dir(self):
        """
        Makes the cache directory.

        """

        cache_dir = os.path.abspath(
            os.path.join(
                os.path.expanduser('~'),
                ".testgold",
                self.sessionid,
            )
        )
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def add_body_html(self, body_html):
        """
        This adds the body HTML of the page as a string.

        """

        self.bodyHTML = body_html

    def serialize(self, tojson=False):
        """This turns the full request into a dict, and optionally
        dumps it to a JSON string.

        """

        self.serialized_post_request = {
            "walServerRequestId": self.walserver_requestid,
            "xPathId": self.xpathid,
            "sessionId": self.sessionid,
            "xpath": self.xpath,
            "bodyHTML": self.bodyHTML,
        }

        if tojson:
            return json.dumps(self.serialized_post_request, indent=2)
        else:
            return self.serialized_post_request

    def send(self,
             timeout=10.0,
             save_response=True):
        """Sends the POST /heal/v1/{xpathid} request to the WAL server.

        Returns the response as a dict deserialized from the JSON the WAL server
        sends back.

        """

        self.saved_req_file = None

        try:

            resp = requests.post(
                self.walserver_heal_url,
                timeout=timeout,
                headers=self.walserver_headers,
                json=self.serialize(tojson=False)
            )
            resp.raise_for_status()

            resp_dict = resp.json()

            if save_response:

                self.saved_req_file = os.path.join(
                    self.cachedir,
                    "%s-%s-post-response.json" % (self.xpathid, "fastheal")
                )

                with open(self.saved_req_file, 'w') as outfd:
                    outfd.write(json.dumps(resp_dict, indent=2))

            return resp_dict, self.saved_req_file

        except Exception:

            logger.error(
                "Could not POST fasthealed xpath from the WAL server."
            )
            return None, self.saved_req_file


class SuggestPostRequest:
    """This encapsulates the interface to the WAL server's POST /suggest/v1 endpoint.

    This handles the POST request to get suggested xpaths.

    """

    def __init__(
            self,
            xpath,
            url,
            walserver_requestid,
            walserver_token='wal-server-authtoken',
            walserver_host='http://localhost:9090/interceptor',
            walserver_username='anonymous'
    ):
        """
        This makes a SuggestPostRequest object.

        """

        self.xpath = xpath
        self.url = url
        self.walserver_host = walserver_host
        self.walserver_token = walserver_token
        self.walserver_username = walserver_username

        self.walserver_requestid = walserver_requestid
        if not walserver_requestid:
            raise ValueError("A WAL server request ID is required.")

        # generate the header dict for the WAL server requests
        self.walserver_headers = {
            "Authorization": "Bearer %s" % self.walserver_token
        }

        self.current_elements = []
        self.bodyHTML = None
        self.allElements = []
        self.pageScreenshot = None
        self.browserProperties = None

        # break apart the provided webpage URL to its fragment and the hostname.

        # we need to do this because we should not use the full URL to construct
        # the xPathId, but we should use the URL fragment (e.g. use only
        # "/some/url/path" from a website address of
        # http://some.website.com/some/url/path). This is because we can have
        # the same URL structure and the same webpage but want to test it on
        # separate host names (e.g. http://dev.website.com/some/url/path and
        # http://some.website.com/some/url/path), so the xPathIds should remain
        # the same between these two.

        # here, self.parsed_url.netloc is the hostname
        # and self.parsed_url.path is the URL fragment we want
        self.parsed_url = urllib.parse.urlsplit(self.url)

        # generate our session ID
        week_number = date.today().isocalendar()[1]
        session_hash = "{url}|{week_number}|{walserver_username}".format(
            url=self.parsed_url.path,
            week_number=week_number,
            walserver_username=self.walserver_username
        )
        self.sessionid = hashlib.sha256(
            session_hash.encode("utf-8")
        ).hexdigest()

        # generate our xpath ID
        xpathid_hash = "{xpath}|{url}".format(
            xpath=self.xpath,
            url=self.parsed_url.path,
        )
        self.xpathid = hashlib.sha256(xpathid_hash.encode("utf-8")).hexdigest()

        self.cachedir = self.make_cache_dir()

        self.serialized_post_request = {
            "walServerRequestId": self.walserver_requestid,
            "xPathId": self.xpathid,
            "sessionId": self.sessionid,
            "sentAt": int(time.time()),
            "currentElements": self.current_elements,
            "xpath": self.xpath,
            "bodyHTML": self.bodyHTML,
            "allElements": self.allElements,
            "pageScreenshot": self.pageScreenshot,
            "browserProperties": self.browserProperties
        }

    def make_cache_dir(self):
        """
        Makes the cache directory.

        """

        cache_dir = os.path.abspath(
            os.path.join(
                os.path.expanduser('~'),
                ".testgold",
                self.sessionid,
            )
        )
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def add_body_html(self, body_html):
        """
        This adds the body HTML of the page as a string.

        """

        self.bodyHTML = body_html

    def add_similar_elements(self, similar_elements):
        """
        Adds an array of similar SerializedWebElements to this request object.

        """

        self.allElements = [
            serialize_webelement(x) for x in similar_elements
        ]

    def add_browser_properties(self,
                               browser_width,
                               browser_height,
                               other_properties=None):
        """
        This adds the browser properties.

        """

        self.browserProperties = {
            "browserHeight": browser_height,
            "browserWidth": browser_width,
            "currentURL": self.url
        }

    def add_page_screenshot(self, screenshotB64):
        """
        Adds the page screenshot to this request object.

        """

        self.pageScreenshot = screenshotB64

    def serialize(self, tojson=False):
        """This turns the full request into a dict, and optionally
        dumps it to a JSON string.

        """

        self.serialized_post_request = {
            "walServerRequestId": self.walserver_requestid,
            "xPathId": self.xpathid,
            "sessionId": self.sessionid,
            "sentAt": int(time.time()),
            "currentElements": self.current_elements,
            "xpath": self.xpath,
            "bodyHTML": self.bodyHTML,
            "allElements": self.allElements,
            "pageScreenshot": self.pageScreenshot,
            "browserProperties": self.browserProperties
        }

        if tojson:
            return json.dumps(self.serialized_post_request, indent=2)
        else:
            return self.serialized_post_request

    def send(self,
             timeout=10.0,
             save_response=True):
        """Sends the POST /suggest/v1/{xpathid} request to the WAL server.

        Returns the response as a dict deserialized from the JSON the WAL server
        sends back.

        """

        self.saved_req_file = None

        try:

            resp = requests.post(
                self.walserver_host + "/suggest/v1",
                timeout=timeout,
                headers=self.walserver_headers,
                json=self.serialize(tojson=False)
            )
            resp.raise_for_status()

            resp_dict = resp.json()

            if save_response:

                self.saved_req_file = os.path.join(
                    self.cachedir,
                    "%s-%s-post-response.json" % (self.xpathid, "suggest")
                )

                with open(self.saved_req_file, 'w') as outfd:
                    outfd.write(json.dumps(resp_dict, indent=2))

            return resp_dict, self.saved_req_file

        except requests.HTTPError as err:

            if err.response.status_code == 401:
                logger.error(
                    "WAL server at %s did not"
                    "accept our auth token. Check the WAL_SERVER_AUTHTOKEN "
                    "environment variable." % self.walserver_host
                )
            elif err.response.status_code == 400:
                logger.error(
                    "WAL server at %s rejected this request because of "
                    "invalid request parameters. Is the xpath ID correct?"
                    % self.walserver_host
                )
            elif err.response.status_code == 500:
                logger.error(
                    "WAL server at %s rejected this request because of "
                    "an internal server error."
                    % self.walserver_host
                )
            else:
                logger.error(
                    "Could not POST suggest request to the WAL server."
                )

            return None, self.saved_req_file


class SuggestGetRequest:
    """This encapsulates the interface to the WAL server's GET /suggest/v1 endpoint.

    This handles the GET request to get suggested xpaths based on the URL and
    xpath sent previously in the POST requests.

    """

    def __init__(
            self,
            xpath,
            url,
            walserver_requestid,
            walserver_token='wal-server-authtoken',
            walserver_host='http://localhost:9090/interceptor',
            walserver_username='anonymous'
    ):
        """
        This makes a SuggestGetRequest object.

        """

        self.xpath = xpath
        self.url = url
        self.walserver_host = walserver_host
        self.walserver_token = walserver_token
        self.walserver_username = walserver_username

        self.walserver_requestid = walserver_requestid
        if not walserver_requestid:
            raise ValueError("A WAL server request ID is required.")

        # generate the header dict for the WAL server requests
        self.walserver_headers = {
            "Authorization": "Bearer %s" % self.walserver_token
        }

        # break apart the provided webpage URL to its fragment and the hostname.

        # we need to do this because we should not use the full URL to construct
        # the xPathId, but we should use the URL fragment (e.g. use only
        # "/some/url/path" from a website address of
        # http://some.website.com/some/url/path). This is because we can have
        # the same URL structure and the same webpage but want to test it on
        # separate host names (e.g. http://dev.website.com/some/url/path and
        # http://some.website.com/some/url/path), so the xPathIds should remain
        # the same between these two.

        # here, self.parsed_url.netloc is the hostname
        # and self.parsed_url.path is the URL fragment we want
        self.parsed_url = urllib.parse.urlsplit(self.url)

        # generate our session ID
        week_number = date.today().isocalendar()[1]
        session_hash = "{url}|{week_number}|{walserver_username}".format(
            url=self.parsed_url.path,
            week_number=week_number,
            walserver_username=self.walserver_username
        )
        self.sessionid = hashlib.sha256(
            session_hash.encode("utf-8")
        ).hexdigest()

        # generate our xpath ID
        xpathid_hash = "{xpath}|{url}".format(
            xpath=self.xpath,
            url=self.parsed_url.path,
        )
        self.xpathid = hashlib.sha256(xpathid_hash.encode("utf-8")).hexdigest()

        self.cachedir = self.make_cache_dir()

        # generate the URL for the WAL server's /heal GET endpoint
        self.walserver_suggest_url = (
            f"{self.walserver_host}/suggest/v1/{self.xpathid}"
        )

    def make_cache_dir(self):
        """
        Makes the cache directory.

        """

        cache_dir = os.path.abspath(
            os.path.join(
                os.path.expanduser('~'),
                ".testgold",
                self.sessionid,
            )
        )
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def send(self,
             timeout=10.0,
             save_response=True):
        """Sends the GET /heal/v1/{xpathid} request to the WAL server.

        Returns the response as a dict deserialized from the JSON the WAL server
        sends back.

        """

        self.saved_req_file = None

        try:

            resp = requests.get(
                self.walserver_suggest_url,
                timeout=timeout,
                headers=self.walserver_headers,
            )
            resp.raise_for_status()

            resp_dict = resp.json()

            if save_response:

                self.saved_req_file = os.path.join(
                    self.cachedir,
                    "%s-%s-get-response.json" % (self.xpathid, "suggest")
                )

                with open(self.saved_req_file, 'w') as outfd:
                    outfd.write(json.dumps(resp_dict, indent=2))

            return resp_dict, self.saved_req_file

        except Exception:

            if resp.status_code == 401:
                logger.error(
                    "WAL server at %s did not"
                    "accept our auth token. Check the WAL_SERVER_AUTHTOKEN "
                    "environment variable." % self.walserver_host
                )
            elif resp.status_code == 400:
                logger.error(
                    "WAL server at %s rejected this request because it's "
                    "still processing the xpath. Will try again..."
                    % self.walserver_host
                )
            elif resp.status_code == 500:
                logger.error(
                    "WAL server at %s rejected this request because of "
                    "an internal server error."
                    % self.walserver_host
                )
            else:
                logger.error(
                    "Could not GET xpath-suggest results from the WAL server."
                )
            return None, self.saved_req_file
